﻿namespace Search
{
    partial class SearchBox
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.chbSearchEnabled = new System.Windows.Forms.CheckBox();
            this.txtSearchValue = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // chbSearchEnabled
            // 
            this.chbSearchEnabled.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.chbSearchEnabled.AutoSize = true;
            this.chbSearchEnabled.Location = new System.Drawing.Point(3, 9);
            this.chbSearchEnabled.Name = "chbSearchEnabled";
            this.chbSearchEnabled.Size = new System.Drawing.Size(15, 14);
            this.chbSearchEnabled.TabIndex = 0;
            this.chbSearchEnabled.UseVisualStyleBackColor = true;
            this.chbSearchEnabled.CheckedChanged += new System.EventHandler(this.chbSearchEnabled_CheckedChanged);
            // 
            // txtSearchValue
            // 
            this.txtSearchValue.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchValue.Enabled = false;
            this.txtSearchValue.Location = new System.Drawing.Point(24, 3);
            this.txtSearchValue.MaxLength = 15;
            this.txtSearchValue.Name = "txtSearchValue";
            this.txtSearchValue.ShortcutsEnabled = false;
            this.txtSearchValue.Size = new System.Drawing.Size(123, 27);
            this.txtSearchValue.TabIndex = 1;
            // 
            // SearchBox
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.txtSearchValue);
            this.Controls.Add(this.chbSearchEnabled);
            this.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "SearchBox";
            this.Size = new System.Drawing.Size(150, 32);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chbSearchEnabled;
        private System.Windows.Forms.TextBox txtSearchValue;
    }
}
