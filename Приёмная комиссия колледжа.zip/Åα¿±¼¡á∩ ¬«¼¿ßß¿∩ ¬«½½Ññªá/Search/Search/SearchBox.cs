﻿/*
 * Admission committee of college.
 * This component was developed specifically for the search panel in the software.
 * Copyright (C) 2017 Sagaydak Danil
 * email: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Search
{
    public partial class SearchBox : UserControl
    {
        public override bool Focused
        {
            get { return txtSearchValue.Focused; }
        }

        public SearchBox()
        {
            InitializeComponent();
        }

        private void chbSearchEnabled_CheckedChanged(object sender, EventArgs e)
        {
            txtSearchValue.Enabled = chbSearchEnabled.Checked;
            if (!chbSearchEnabled.Checked)
                txtSearchValue.Text = String.Empty;
        }

        [Category("Appearance"), Description("Текст, по которому будет производиться поиск.")]
        public string SearchValue
        {
            get { return txtSearchValue.Text; }
            set { txtSearchValue.Text = value; }
        }

        [Category("Behavior"), Description("Указывает, включено ли поле для поиска.")]
        public bool SearchEnabled
        {
            get { return chbSearchEnabled.Checked; }
            set { chbSearchEnabled.Checked = value; }
        }
    }
}
