﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace Приёмная_комиссия_колледжа
{
    public partial class Registration_form : Form
    {
        public Navigation_panel F1;             //Переменная класса для взаимодействия с родительской формой
        private List_editor F3;                 //Переменная класса для взаимодействия с дочерней формой
        private byte enum_type;                 //Переменная для определения вида перечня
        private bool for_lang;                  //Переменная иностранных языков (кроме Англ.(США))  
        private bool txt_er;                    //Переменная наличия некорректного ввода
        private string txt_name;                //Переменная для имён полей с некорректным вводом данных
        private string value;                   //Переменная значения ключа выбранной записи в Navigation panel
        public bool Update_err;                 //Переменная наличия попытки произвести обновление изменённой(удалённой) записи
        public Byte en_t { get { return this.enum_type; } }

        //Перечень специальностей по умолчанию
        string[] en_sp = { "", "БУЭ", "ДОУ", "ЗЧС", "МЭО", "ПКС", "ПРП", "ТМС", "ТЭО" };
        //Перечень обязательных предметов по умолчанию
        string[] en_comp = { "", "Русский язык", "Украинский язык" };
        //Перечень профильных предметов по умолчанию
        string[] en_prof = { "", "Математика", "История" };

        //***********************************************
        // Блоки инициализации и предварительной загрузки
        //***********************************************
        public Registration_form()
        {
            InitializeComponent();
        }

        private void Registration_form_Load(object sender, EventArgs e)
        {
            if (F1 != null)
            {
                enum_type = 0;
                txt_er = false;
                Update_err = false;
                if ((ab_Spec1ComboBox.Items.Count == 0) && (cs_Com_subComboBox.Items.Count == 0) && (cs_Prof_subComboBox.Items.Count == 0))
                    //Cчитываем перечни из файлов
                    this.LoadEnum();
                if (F1.st_fl == true)
                {
                    try
                    {
                        value = Convert.ToString(F1.dg[1, F1.dg.CurrentRow.Index].Value);
                        this.view_FormTableAdapter.FillDataTable(this.bD_AbiturientDataSet.View_Form, value);
                        if (ItogoLabel.Visible == false)
                        {
                            ItogoLabel.Visible = true;
                            cs_Comp_scoreLabel.Visible = true;
                        }
                        //Перемещаемся по вкладкам программно, чтобы данные автоматически загрузились в текстовые поля
                        //Это необходимо для корректной работы системы корректного ввода
                        tabControl.SelectedIndex = 0;
                        tabControl.SelectedIndex = 1;
                        tabControl.SelectedIndex = 2;
                        tabControl.SelectedIndex = 3;
                        tabControl.SelectedIndex = 0;    //возвращаемся на первую вкладку
                    }
                    finally { this.view_FormTableAdapter.Dispose(); GC.SuppressFinalize(view_FormTableAdapter); }
                }
                else
                {
                    cs_GPATextBox.Text = "0";
                    cs_Com_sub_markTextBox.Text = "0";
                    cs_Prof_sub_markTextBox.Text = "0";
                    cs_Extra_pointsTextBox.Text = "0";
                    cs_TestTextBox.Text = "0";
                    ItogoLabel.Visible = false;
                    cs_Comp_scoreLabel.Visible = false;
                    if (tabControl.SelectedIndex != 0)
                        tabControl.SelectedIndex = 0;
                }
            }
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Registration_form_Layout(object sender, LayoutEventArgs e)
        {
            if (F1.F0 != null)
            {
                if (!F1.F0.chb_Main_menu.Checked)
                    timerShow.Start();
                else
                {
                    this.Show();
                    this.Opacity = 1.0;
                }
            }
        }

        //**************************
        // Блоки обработчиков кнопок                           
        //**************************
        private void btn_Confirm_Click(object sender, EventArgs e)
        {
            try
            {
                //Анализируем нажатую кнопку в родительском окне
                if (F1.st_fl == false)  //Добавляем
                {  //Если поле с кодом непустое
                    if (!String.IsNullOrEmpty(IDTextBox_txt.Text))
                    {   //Если записи с таким кодом нет
                        if (Convert.ToUInt16(view_FormTableAdapter.Exists(IDTextBox_txt.Text)) == 0)
                        {
                            if (String.IsNullOrEmpty(PrivTextBox_txt.Text))
                                PrivTextBox_txt.Text = "Нет";
                            this.view_FormTableAdapter.InsertData(IDTextBox_txt.Text, pers_LastnameTextBox_txt.Text, pers_FirstnameTextBox_txt.Text, pers_PatronymicTextBox_txt.Text, pers_SexComboBox.Text, pers_BirthdayDateTimePicker.Value, pers_PhoneMaskedTextBox.Text, pers_DKComboBox.Text, pers_DSTextBox_txt.Text, pers_DNTextBox_num.Text, pers_DDateDateTimePicker.Value, DWhoTextBox_txt.Text, pers_INNTextBox_num.Text, CountryTextBox_txt.Text, CityTextBox_txt.Text, ad_IndexTextBox_num.Text, StreetTextBox_txt.Text, ad_HouseTextBox_num.Text, ad_FlatTextBox_num.Text, ab_EDKComboBox.Text, ab_EDSTextBox_txt.Text, ab_EDNTextBox_num.Text, ab_ED_DateDateTimePicker.Value, ED_WhoTextBox_txt.Text, ab_ED_ExcComboBox.Text, ab_MedCert1ComboBox.Text, ab_MedCert2ComboBox.Text, ab_MedCert3ComboBox.Text, ab_ForLangComboBox.Text, ab_Spec1ComboBox.Text, ab_Spec2ComboBox.Text, ab_Spec3ComboBox.Text, ab_EFComboBox.Text, ab_EBComboBox.Text, PrivTextBox_txt.Text, Convert.ToDouble(cs_GPATextBox.Text), cs_Com_subComboBox.Text, Convert.ToDouble(cs_Com_sub_markTextBox.Text), cs_Prof_subComboBox.Text, Convert.ToDouble(cs_Prof_sub_markTextBox.Text), Convert.ToDouble(cs_Extra_pointsTextBox.Text), Convert.ToDouble(cs_TestTextBox.Text));
                            this.Close();
                        }
                        else
                            Goto_IDTextBox_txt("Данные с кодом \"" + IDTextBox_txt.Text + "\" уже существуют в базе данных. Пожалуйста, внесите другое значение в поле \"Код абитуриента\".");
                    }
                    else
                        Goto_IDTextBox_txt("Поле \"Код абитуриента\" должно быть заполнено.");
                }
                else    //Обновляем
                {
                    if (!String.IsNullOrEmpty(IDTextBox_txt.Text))
                    {   //Запись с таким кодом существует в базе данных
                        if (Convert.ToUInt16(view_FormTableAdapter.Exists(IDTextBox_txt.Text)) != 0)
                        {   //и её код абитуриента не был изменён
                            if (IDTextBox_txt.Text == value)
                            {
                                if (String.IsNullOrEmpty(PrivTextBox_txt.Text))
                                    PrivTextBox_txt.Text = "Нет";
                                this.view_FormTableAdapter.UpdateData(value, IDTextBox_txt.Text, pers_LastnameTextBox_txt.Text, pers_FirstnameTextBox_txt.Text, pers_PatronymicTextBox_txt.Text, pers_SexComboBox.Text, pers_BirthdayDateTimePicker.Value, pers_PhoneMaskedTextBox.Text, pers_DKComboBox.Text, pers_DSTextBox_txt.Text, pers_DNTextBox_num.Text, pers_DDateDateTimePicker.Value, DWhoTextBox_txt.Text, pers_INNTextBox_num.Text, CountryTextBox_txt.Text, CityTextBox_txt.Text, ad_IndexTextBox_num.Text, StreetTextBox_txt.Text, ad_HouseTextBox_num.Text, ad_FlatTextBox_num.Text, ab_EDKComboBox.Text, ab_EDSTextBox_txt.Text, ab_EDNTextBox_num.Text, ab_ED_DateDateTimePicker.Value, ED_WhoTextBox_txt.Text, ab_ED_ExcComboBox.Text, ab_MedCert1ComboBox.Text, ab_MedCert2ComboBox.Text, ab_MedCert3ComboBox.Text, ab_ForLangComboBox.Text, ab_Spec1ComboBox.Text, ab_Spec2ComboBox.Text, ab_Spec3ComboBox.Text, ab_EFComboBox.Text, ab_EBComboBox.Text, PrivTextBox_txt.Text, Convert.ToDouble(cs_GPATextBox.Text), cs_Com_subComboBox.Text, Convert.ToDouble(cs_Com_sub_markTextBox.Text), cs_Prof_subComboBox.Text, Convert.ToDouble(cs_Prof_sub_markTextBox.Text), Convert.ToDouble(cs_Extra_pointsTextBox.Text), Convert.ToDouble(cs_TestTextBox.Text));
                            }
                            else   //Пользователь ввёл в поле с кодом абитуриента другое, но уже существующее значение
                            {
                                Goto_IDTextBox_txt("Данные с кодом \"" + IDTextBox_txt.Text + "\" уже существуют в базе данных. Пожалуйста, внесите другое значение в поле \"Код абитуриента\".");
                                return;
                            }
                        }
                        //Пользователь изменил код абитуриента на несуществующий
                        else if (Convert.ToUInt16(view_FormTableAdapter.Exists(IDTextBox_txt.Text)) == 0)
                        {   //а эта запись с её первоначальным кодом ещё существует в базе данных
                            if (Convert.ToUInt16(view_FormTableAdapter.Exists(value)) != 0)
                            {
                                if (String.IsNullOrEmpty(PrivTextBox_txt.Text))
                                    PrivTextBox_txt.Text = "Нет";
                                this.view_FormTableAdapter.UpdateData(value, IDTextBox_txt.Text, pers_LastnameTextBox_txt.Text, pers_FirstnameTextBox_txt.Text, pers_PatronymicTextBox_txt.Text, pers_SexComboBox.Text, pers_BirthdayDateTimePicker.Value, pers_PhoneMaskedTextBox.Text, pers_DKComboBox.Text, pers_DSTextBox_txt.Text, pers_DNTextBox_num.Text, pers_DDateDateTimePicker.Value, DWhoTextBox_txt.Text, pers_INNTextBox_num.Text, CountryTextBox_txt.Text, CityTextBox_txt.Text, ad_IndexTextBox_num.Text, StreetTextBox_txt.Text, ad_HouseTextBox_num.Text, ad_FlatTextBox_num.Text, ab_EDKComboBox.Text, ab_EDSTextBox_txt.Text, ab_EDNTextBox_num.Text, ab_ED_DateDateTimePicker.Value, ED_WhoTextBox_txt.Text, ab_ED_ExcComboBox.Text, ab_MedCert1ComboBox.Text, ab_MedCert2ComboBox.Text, ab_MedCert3ComboBox.Text, ab_ForLangComboBox.Text, ab_Spec1ComboBox.Text, ab_Spec2ComboBox.Text, ab_Spec3ComboBox.Text, ab_EFComboBox.Text, ab_EBComboBox.Text, PrivTextBox_txt.Text, Convert.ToDouble(cs_GPATextBox.Text), cs_Com_subComboBox.Text, Convert.ToDouble(cs_Com_sub_markTextBox.Text), cs_Prof_subComboBox.Text, Convert.ToDouble(cs_Prof_sub_markTextBox.Text), Convert.ToDouble(cs_Extra_pointsTextBox.Text), Convert.ToDouble(cs_TestTextBox.Text));
                            }
                            /*else    //а эта запись с её первоначальным кодом была изменена или удалена другим пользователем
                            {   расскоментировать после реализации клиент-серверной архитектуры
                                MessageBox.Show("Данные, которые вы пытаетесь изменить, не обнаружены в базе данных. Возможно, они были изменены или удалены другим пользователем.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                Update_err = true;
                            }*/
                        }
                        this.Close();
                    }
                    else
                        Goto_IDTextBox_txt("Поле \"Код абитуриента\" должно быть заполнено.");
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("База данных доступна только для чтения. У Вас нет разрешения \"Полный доступ\" для папки с приложением.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.view_FormTableAdapter.Dispose(); GC.SuppressFinalize(view_FormTableAdapter); }
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //*************************************************
        // Блоки обработчиков кнопок для работы со спиcками
        //*************************************************
        private void btn_Spec_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["Reports"] != null)
            {
                MessageBox.Show("Окно \"Отчёты\" будет закрыто, так как в данный момент будет редактироваться перечень специальностей.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                F1.F0.rp.Close();
            }
            this.LoadEnum(@"\Specialties.dat", 1, ab_Spec1ComboBox, en_sp, "специальностей");
        }

        private void btn_Comp_Click(object sender, EventArgs e)
        {
            this.LoadEnum(@"\Comp. subjects.dat", 2, cs_Com_subComboBox, en_comp, "обязательных предметов");
        }

        private void btn_Prof_Click(object sender, EventArgs e)
        {
            this.LoadEnum(@"\Prof. subjects.dat", 3, cs_Prof_subComboBox, en_prof, "профильных предметов");
        }

        //************************************************
        // Блоки обработчиков анализа раскладки клавиатуры
        //************************************************
        private void Registration_form_Shown(object sender, EventArgs e)
        {
            //Анализируем текущую раскладку клавиатуры
            if ((InputLanguage.CurrentInputLanguage.LayoutName != "Русская") && (InputLanguage.CurrentInputLanguage.LayoutName != "США"))
            {
                for_lang = true;
                //Анализируем нажатую кнопку в родительском окне
                if (F1.st_fl == true)
                    MessageBox.Show("Редактирование данных в этом окне возможно только на определённых раскладках клавиатуры: \"Русский(Россия) и \"Английский(США)\".", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show("Ввод данных в этом окне возможен только на определённых раскладках клавиатуры: \"Русский(Россия) и \"Английский(США)\".", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
                for_lang = false;
        }

        private void Registration_form_InputLanguageChanged(object sender, InputLanguageChangedEventArgs e)
        {
            if ((InputLanguage.CurrentInputLanguage.LayoutName != "Русская") && (InputLanguage.CurrentInputLanguage.LayoutName != "США"))
                for_lang = true;
            else if ((InputLanguage.CurrentInputLanguage.LayoutName == "США"))
            {
                for_lang = false;
                MessageBox.Show("На раскладке клавиатуры \"Английский(США)\" доступен только символ \"I\". Его можно ввести лишь в определённые поля: \"Серия\" и \"Наличие льготы\".", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
                for_lang = false;
        }

        //**********************************
        // Блоки обработчиков нажатия клавиш
        //**********************************
        private void TextBox_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (InputLanguage.CurrentInputLanguage.LayoutName == "США")
            {
                //Заменяем обработчик русских символов на англоязычный
                (sender as TextBox).KeyDown -= new KeyEventHandler(Control_KeyDown);
                (sender as TextBox).KeyDown += new KeyEventHandler(Control_en_KeyDown);
            }
            else if (InputLanguage.CurrentInputLanguage.LayoutName == "Русская")
            {
                //Обратная операция
                (sender as TextBox).KeyDown -= new KeyEventHandler(Control_en_KeyDown);
                (sender as TextBox).KeyDown += new KeyEventHandler(Control_KeyDown);
            }
        }

        private void Control_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (for_lang == true)   //Любая иностранная раскладка клавиатуры, кроме Английской(США)
                e.SuppressKeyPress = true;  //Подавляем передачу сигнала нажатой клавишы
            else
            {
                //Подавляем передачу сигнала нажатой клавишы
                e.SuppressKeyPress = true;
                //Индивидуальная настройка отдельных textbox
                if ((sender as TextBox).Name.Contains("num") || (sender as TextBox).Name == "IDTextBox_txt" || (sender as TextBox).Name == "PrivTextBox_txt" || (sender as TextBox).Name == "StreetTextBox_txt" || (sender as TextBox).Name.Contains("cs") || (sender as TextBox).Name == "ED_WhoTextBox_txt" || (sender as TextBox).Name == "DWhoTextBox_txt" || (sender as TextBox).Name == "CountryTextBox_txt" || (sender as TextBox).Name == "CityTextBox_txt" || (sender as TextBox).Name == "DWhoTextBox_txt")
                {
                    if ((sender as TextBox).Name.Contains("num") || (sender as TextBox).Name == "IDTextBox_txt" || (sender as TextBox).Name == "PrivTextBox_txt" || (sender as TextBox).Name == "StreetTextBox_txt" || (sender as TextBox).Name.Contains("cs") || (sender as TextBox).Name == "ED_WhoTextBox_txt")
                    {
                        //Разрешаем обработку циферного блока клавиш Numpad
                        if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
                            e.SuppressKeyPress = false;
                        //Разрешаем обработку цифер, если клавиша Shift не нажата
                        if (e.Shift != true)
                        {
                            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
                                e.SuppressKeyPress = false;
                            //Для улицы допустима "."
                            if ((sender as TextBox).Name == "StreetTextBox_txt")
                            {
                                if (e.KeyCode == Keys.OemQuestion)
                                    e.SuppressKeyPress = false;
                            }
                        }
                    }
                    //Для дробных чисел
                    if ((sender as TextBox).Name.Contains("cs"))
                    {
                        //Разрешаем обработку только запятой
                        if ((e.Shift == true) && (e.KeyCode == Keys.OemQuestion) || e.KeyCode == Keys.Decimal)
                            e.SuppressKeyPress = false;
                    }
                    //Пробел для группы полей
                    if ((sender as TextBox).Name == "StreetTextBox_txt" || (sender as TextBox).Name == "PrivTextBox_txt" || (sender as TextBox).Name == "ED_WhoTextBox_txt" || (sender as TextBox).Name == "DWhoTextBox_txt" || (sender as TextBox).Name == "CountryTextBox_txt" || (sender as TextBox).Name == "CityTextBox_txt")
                    {
                        if (e.KeyCode == Keys.Space)
                            e.SuppressKeyPress = false;
                    }
                    //Символ "№"
                    if ((sender as TextBox).Name == "ED_WhoTextBox_txt")
                    {
                        if (e.Shift && e.KeyCode == Keys.D3)
                            e.SuppressKeyPress = false;
                    }
                    //Точка для одного из полей "Кем выдан"
                    if ((sender as TextBox).Name == "DWhoTextBox_txt")
                    {
                        if (e.KeyCode == Keys.OemQuestion)
                            e.SuppressKeyPress = false;
                    }
                }
                if ((sender as TextBox).Name.Contains("txt"))
                {
                    //Разрешаем стандартной клавиши "-", если клавиша Shift не нажата
                    if (e.Shift != true)
                    {
                        if ((e.KeyCode == Keys.OemMinus) || (e.KeyCode == Keys.Subtract))
                            e.SuppressKeyPress = false;
                    }
                    //Разрешаем обработку всех клавиш с буквами
                    if ((e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z) || (e.KeyCode == Keys.Oemtilde) || (e.KeyCode == Keys.OemSemicolon) || (e.KeyCode == Keys.OemQuotes) || (e.KeyCode == Keys.OemOpenBrackets) || (e.KeyCode == Keys.OemCloseBrackets) || (e.KeyCode == Keys.Oemcomma) || (e.KeyCode == Keys.OemPeriod))
                        e.SuppressKeyPress = false;
                }
                //Разрешаем обработку клавиш Delete, Backspace, Home, End и перемещение стрелок вправо, влево
                if ((e.KeyCode == Keys.Delete) || (e.KeyCode == Keys.Back) || (e.KeyCode == Keys.Right) || (e.KeyCode == Keys.Left) || (e.KeyCode == Keys.Home) || (e.KeyCode == Keys.End))
                    e.SuppressKeyPress = false;
            }
        }

        private void Control_en_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (for_lang == true)
                e.SuppressKeyPress = true;  //Подавляем передачу сигнала нажатой клавишы
            else
            {
                //Подавляем передачу сигнала нажатой клавишы
                e.SuppressKeyPress = true;
                //Настройка ввода "I" только для определённых полей ввода
                if ((sender as TextBox).Name == "pers_DSTextBox_txt" || (sender as TextBox).Name == "ab_EDSTextBox_txt" || (sender as TextBox).Name == "PrivTextBox_txt")
                {
                    if (e.Shift == true && e.KeyCode == Keys.I)
                        e.SuppressKeyPress = false;
                }
                //Разрешаем обработку клавиш Delete, Backspace, Home, End и перемещение стрелок вправо, влево
                if ((e.KeyCode == Keys.Delete) || (e.KeyCode == Keys.Back) || (e.KeyCode == Keys.Right) || (e.KeyCode == Keys.Left) || (e.KeyCode == Keys.Home) || (e.KeyCode == Keys.End))
                    e.SuppressKeyPress = false;
            }
        }

        //*****************************
        // Обработчик корректного ввода
        //*****************************
        private void Control_of_symbols_TextChanged(object sender, EventArgs e)
        {   //разбить сложные условия на более простые и добавить несколько переменных для различия сообщений да и вообще ошибок
            //отдельно (сугубо индивидуально) доработать проверку таких полей: Кем выдан (лич. данные), Улица, Кем выдан (данные для поступления) (сложные условия)
            //Страна, Город и Наличие льготы
            toolTip.Active = false;     //Деактивируем подсказку
            if (String.IsNullOrEmpty((sender as TextBox).Text))    //Если текста нет
            {
                if ((sender as TextBox).Name.Contains("cs"))
                {
                    errorProvider.SetError((sender as TextBox), "Внимание");
                    toolTip.Active = true;
                    toolTip.SetToolTip((sender as TextBox), "Это поле не должно быть пустым.");
                    btn_Confirm.Enabled = false;
                    txt_er = true;
                    txt_name = (sender as TextBox).Name;    //записываем имя поля
                    El_en_false();
                    (sender as TextBox).Enabled = true;
                    (sender as TextBox).Focus();
                }
                else
                {
                    errorProvider.Clear();                  //сбрасываем текст, а заодно и видимость элемента (сам исчезает)
                    (sender as TextBox).ForeColor = Color.Black;
                    btn_Confirm.Enabled = true;
                    txt_er = false;
                    El_en_true();
                    return;
                }
            }
            else if (((sender as TextBox).Name == txt_name) || (txt_er == false))
            {
                int l, t, km, kp, kc, kn, n; bool a = true; bool b = true; /*bool c = true;*/ string str;
                str = (sender as TextBox).Text;     //Строка
                l = str.Length;                     //Длина строки
                t = 0;                              //Индекс первого символа строки
                //Допустимое кол-во "-" по умолчанию
                n = 1;
                //Колличество "-", ".", "," и "№" в строке
                km = 0; kp = 0; kc = 0; kn = 0;
                //Меняем для поля "Код абитуриента" допустимое кол-во "-"
                if ((sender as TextBox).Name == "IDTextBox_txt")
                    n = 2;
                //Проверка кол-ва символов и их расположения
                for (int i = 0; i <= l - 1; i++)
                {
                    if (str[i] == '-')
                        km++;
                    if (str[i] == '.')
                        kp++;
                    if (str[i] == ',')
                        kc++;
                    if (str[i] == '№')
                        kn++;
                    //Проверка стоят ли два "-" рядом
                    if (((sender as TextBox).Name == "IDTextBox_txt") && (l >= 2) && (i != 0) && (str[i] == '-') && (str[i] == str[i - 1]))
                    { a = false; b = false; }
                    //доработать отдельно для каждого (есть разница)
                    //Проверка стоят ли "." и "," рядом
                    if (((sender as TextBox).Name == "StreetTextBox_txt" || (sender as TextBox).Name == "DWhoTextBox_txt") && (l >= 2) && (i != 0) && ((str[i] == '.') && ((str[i - 1] == ',')) || ((str[i] == ',') && (str[i - 1] == '.'))))
                    {
                        a = false; b = false;
                    }
                    //Проверка стоят ли "-" и "№" рядом
                    if (((sender as TextBox).Name == "ED_WhoTextBox_txt") && (l >= 2) && (i != 0) && ((str[i] == '-') && ((str[i - 1] == '№')) || ((str[i] == '№') && (str[i - 1] == '-'))))
                    { a = false; b = false; }
                }
                //Проверка корректности формата десятичного числа (удаление 0, которые могут стоять перед любой цифрой без запятой)
                if (((sender as TextBox).Name.Contains("cs")) && (l >= 2) && (str[t] == '0') && (str[t + 1] != ','))
                {
                    l--;                            //Уменьшаем длину
                    str = str.Substring(1, l);      //Удаляем один символ слева
                    (sender as TextBox).Text = str;
                }
                //Колличество "-", "." и "," в строке
                if ((km > n) || (kp > 1) || (kc > 1) || (kn > 1))
                    a = false;
                //Проверка стоят ли "-", ".", "№", "," и пробелы в начале или в конце
                if ((str[t] == '-') || (str[t] == '.') || (str[t] == ' ') || (str[t] == '№') || (str[t] == ',') || (str[l - 1] == '-') || (str[l - 1] == '.') || (str[l - 1] == ' ') || (str[l - 1] == '№') || (str[l - 1] == ','))
                    a = false;
                //Если есть некорректный ввод
                if (a == false)
                {
                    errorProvider.SetError((sender as TextBox), "Внимание");
                    //Активируем подсказку
                    toolTip.Active = true;
                    //Устанавливаем нужный текст во всплывающую подсказку
                    if ((sender as TextBox).Name.Contains("pers") || (sender as TextBox).Name.Contains("ab") || (sender as TextBox).Name.Contains("ad"))
                        toolTip.SetToolTip((sender as TextBox), "Ввод символа \"-\" допускается 1 раз и только\nмежду другими символами.");
                    else if ((sender as TextBox).Name == "IDTextBox_txt")
                    {
                        if (b == true)
                            toolTip.SetToolTip((sender as TextBox), "Ввод символа \"-\" допускается 2 раза и только\nмежду другими символами.");
                        else
                            toolTip.SetToolTip((sender as TextBox), "Два символа \"-\" не должны стоять рядом.");
                    }
                    //доработать отдельно для каждого (есть разница)
                    else if ((sender as TextBox).Name == "StreetTextBox_txt" || (sender as TextBox).Name == "DWhoTextBox_txt")
                    {
                        if (b == true)
                            toolTip.SetToolTip((sender as TextBox), "Ввод символов \".\" и \"-\" допускается 1 раз и только между другими\nсимволами. Пробелы в начале или в конце недопустимы.");
                        else
                            toolTip.SetToolTip((sender as TextBox), "Cимволы \".\" и \",\" не должны стоять рядом.");
                    }
                    else if ((sender as TextBox).Name.Contains("cs"))
                    {
                        toolTip.SetToolTip((sender as TextBox), "Ввод символа \",\" допускается только 1 раз и\nтолько между другими символами.");
                    }
                    else if ((sender as TextBox).Name == "CountryTextBox_txt" || (sender as TextBox).Name == "CityTextBox_txt" || (sender as TextBox).Name == "PrivTextBox_txt")
                        toolTip.SetToolTip((sender as TextBox), "Ввод символа \"-\" допускается 1 раз и только между другими\nсимволами. Пробелы в начале или в конце недопустимы.");
                    else if ((sender as TextBox).Name == "ED_WhoTextBox_txt")
                    {
                        if (b == true)
                            toolTip.SetToolTip((sender as TextBox), "Ввод символов \"-\" и \"№\" допускается 1 раз и только между другими\nсимволами. Пробелы в начале или в конце недопустимы.");
                        else
                            toolTip.SetToolTip((sender as TextBox), "Cимволы \"-\" и \"№\" не должны стоять рядом.");
                    }
                    (sender as TextBox).ForeColor = Color.Red;
                    btn_Confirm.Enabled = false;
                    txt_er = true;
                    txt_name = (sender as TextBox).Name;    //записываем имя поля, в котором возник некорректный ввод
                    El_en_false();
                    (sender as TextBox).Enabled = true;
                    (sender as TextBox).Focus();
                }
                else
                {
                    errorProvider.Clear();
                    (sender as TextBox).ForeColor = Color.Black;
                    btn_Confirm.Enabled = true;
                    txt_er = false;
                    El_en_true();
                }
            }
        }

        //****************************
        // Блоки обработчиков таймеров
        //****************************
        private void Show(object sender, EventArgs e)
        {
            this.Enabled = true;
            this.Show();
            this.Opacity += 0.15;
            if (this.Opacity == 1)
            {
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        private void Hide(object sender, EventArgs e)
        {
            this.Enabled = false;
            if (!F1.F0.chb_Main_menu.Checked)
            {
                this.Opacity -= 0.15;
                if (this.Opacity == 0.7)
                {
                    timerHide.Stop();
                    timerHide.Dispose();
                }
            }
            else
            {
                timerHide.Stop();
                timerHide.Dispose();
            }
        }

        //*************************************
        // Oбработчик закрытия Редактора списка
        //*************************************
        private void F3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (F3.DialogResult == DialogResult.OK)
                this.LoadEnum();
            this.Activate();
            timerShow.Start();
        }

        //*******************************
        // Обработчик закрытия этой формы
        //*******************************
        private void Registration_form_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
        }

        //***************************************
        // Блоки обработчиков, оптимизирующих код
        //***************************************
        private void El_en_true()
        {
            //Активируем текстовые поля
            foreach (TextBox tb in tabPage2.Controls.OfType<TextBox>())
                tb.Enabled = true;
            foreach (TextBox tb in tabPage3.Controls.OfType<TextBox>())
                tb.Enabled = true;
            foreach (TextBox tb in tabPage1.Controls.OfType<TextBox>())
                tb.Enabled = true;
            foreach (TextBox tb in tabPage4.Controls.OfType<TextBox>())
                tb.Enabled = true;
            //Активируем списки
            foreach (ComboBox cb in tabPage2.Controls.OfType<ComboBox>())
                cb.Enabled = true;
            foreach (ComboBox cb in tabPage3.Controls.OfType<ComboBox>())
                cb.Enabled = true;
            foreach (ComboBox cb in tabPage1.Controls.OfType<ComboBox>())
                cb.Enabled = true;
            foreach (ComboBox cb in tabPage4.Controls.OfType<ComboBox>())
                cb.Enabled = true;
            //Активируем кнопки 
            btn_Spec.Enabled = true;
            btn_Comp.Enabled = true;
            btn_Prof.Enabled = true;
            //Активируем оставшиеся компоненты
            pers_BirthdayDateTimePicker.Enabled = true;
            pers_DDateDateTimePicker.Enabled = true;
            pers_PhoneMaskedTextBox.Enabled = true;
            ab_ED_DateDateTimePicker.Enabled = true;
        }

        private void El_en_false()
        {
            //Деактивируем текстовые поля
            foreach (TextBox tb in tabPage2.Controls.OfType<TextBox>())
                tb.Enabled = false;
            foreach (TextBox tb in tabPage3.Controls.OfType<TextBox>())
                tb.Enabled = false;
            foreach (TextBox tb in tabPage1.Controls.OfType<TextBox>())
                tb.Enabled = false;
            foreach (TextBox tb in tabPage4.Controls.OfType<TextBox>())
                tb.Enabled = false;
            //Деактивируем списки
            foreach (ComboBox cb in tabPage2.Controls.OfType<ComboBox>())
                cb.Enabled = false;
            foreach (ComboBox cb in tabPage3.Controls.OfType<ComboBox>())
                cb.Enabled = false;
            foreach (ComboBox cb in tabPage1.Controls.OfType<ComboBox>())
                cb.Enabled = false;
            foreach (ComboBox cb in tabPage4.Controls.OfType<ComboBox>())
                cb.Enabled = false;
            //Деактивируем кнопки 
            btn_Spec.Enabled = false;
            btn_Comp.Enabled = false;
            btn_Prof.Enabled = false;
            //Активируем оставшиеся компоненты
            pers_BirthdayDateTimePicker.Enabled = false;
            pers_DDateDateTimePicker.Enabled = false;
            pers_PhoneMaskedTextBox.Enabled = false;
            ab_ED_DateDateTimePicker.Enabled = false;
        }

        private void Goto_IDTextBox_txt(string txtMsg)
        {
            MessageBox.Show(txtMsg, "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //Открываем 3 вкладку
            tabControl.SelectedIndex = 2;
            //Задаём фокус
            this.IDTextBox_txt.Focus();
        }

        private void LoadEnum()
        {
            if (en_t == 1)
            {   //Проверяем существование файла
                if (File.Exists(Application.StartupPath + @"\Specialties.dat"))
                {
                    //Очищаем списки от старых данных
                    ab_Spec1ComboBox.Items.Clear();
                    ab_Spec2ComboBox.Items.Clear();
                    ab_Spec3ComboBox.Items.Clear();
                    //Загружаем новые данные в списки
                    ab_Spec1ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                    ab_Spec2ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                    ab_Spec3ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                }
            }
            else if (en_t == 2)
            {
                if (File.Exists(Application.StartupPath + @"\Comp. subjects.dat"))
                {
                    cs_Com_subComboBox.Items.Clear();
                    cs_Com_subComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Comp. subjects.dat"));
                }
            }
            else if (en_t == 3)
            {
                if (File.Exists(Application.StartupPath + @"\Prof. subjects.dat"))
                {
                    cs_Prof_subComboBox.Items.Clear();
                    cs_Prof_subComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Prof. subjects.dat"));
                }
            }
            else
            {   //Проверяем существование файлов
                if (File.Exists(Application.StartupPath + @"\Specialties.dat"))
                {
                    //Загружаем данные в списки при загрузке формы
                    ab_Spec1ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                    ab_Spec2ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                    ab_Spec3ComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                }
                if (File.Exists(Application.StartupPath + @"\Comp. subjects.dat"))
                    cs_Com_subComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Comp. subjects.dat"));
                if (File.Exists(Application.StartupPath + @"\Prof. subjects.dat"))
                    cs_Prof_subComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Prof. subjects.dat"));
            }
        }

        private void LoadEnum(string fileName, byte value, object sender, string[] myEnum, string txtMsg)
        {
            //Проверяем существование файла
            if (File.Exists(Application.StartupPath + fileName))
                this.LoadEnum(value);
            else
            {
                DialogResult r1 = MessageBox.Show("Файл с перечнем " + txtMsg + " отсутствует. Загрузить перечень " + txtMsg + " по умолчанию?", "Создание перечня по умолчанию", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                if (r1 == DialogResult.Yes)
                {
                    //Заполнение списка
                    (sender as ComboBox).Items.AddRange(myEnum);
                    if (value == 1)
                    {
                        ab_Spec2ComboBox.Items.AddRange(myEnum);
                        ab_Spec3ComboBox.Items.AddRange(myEnum);
                    }
                    try
                    {
                        File.WriteAllLines(Application.StartupPath + fileName, myEnum);
                    }
                    catch (UnauthorizedAccessException)
                    {
                        MessageBox.Show("Процедура создания файла не была выполнена, так как у Вас нет разрешения \"Запись\" для папки с приложением.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    DialogResult r2 = MessageBox.Show("Вы хотите изменить загруженный перечень?", "Редактирования перечня", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                    if (r2 == DialogResult.Yes)
                        this.LoadEnum(value);
                }
                else
                {
                    //Создаём файл, записывая в него пустую строку (для реализации очистки ComboBox-ов)
                    using (StreamWriter sr = new StreamWriter(Application.StartupPath + fileName))
                        sr.WriteLine(String.Empty);
                    MessageBox.Show("Был создан пустой файл для перечня " + txtMsg + ". Сейчас будет открыто окно для его редактирования.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.LoadEnum(value);
                }
            }
        }

        private void LoadEnum(byte value)
        {
            timerHide.Start();
            enum_type = value;
            if ((F3 == null) || (F3.IsDisposed))
                F3 = new List_editor();
            F3.FormClosing += new FormClosingEventHandler(F3_FormClosing);
            F3.Show(F3.F2 = this);
        }
    }
}