﻿namespace Приёмная_комиссия_колледжа
{
    partial class Navigation_panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label19;
            System.Windows.Forms.Label label18;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Navigation_panel));
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.lFPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.persIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_AbiturientDataSet = new Приёмная_комиссия_колледжа.Database.BD_AbiturientDataSet();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.chb_Clear = new System.Windows.Forms.CheckBox();
            this.grbSearch = new System.Windows.Forms.GroupBox();
            this.sb_Code = new Search.SearchBox();
            this.sb_LFP = new Search.SearchBox();
            this.rb_Filter2 = new System.Windows.Forms.RadioButton();
            this.rb_Filter1 = new System.Windows.Forms.RadioButton();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_ClearDB = new System.Windows.Forms.Button();
            this.btn_Connection = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.btn_Last = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_Previous = new System.Windows.Forms.Button();
            this.btn_First = new System.Windows.Forms.Button();
            this.btn_Sidebar = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Change = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.lbGeneralCount = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbEF = new System.Windows.Forms.Label();
            this.lbDF = new System.Windows.Forms.Label();
            this.lbContractCount = new System.Windows.Forms.Label();
            this.lbBudgetCount = new System.Windows.Forms.Label();
            this.timerHide = new System.Windows.Forms.Timer(this.components);
            this.timerShow = new System.Windows.Forms.Timer(this.components);
            this.viewTableAdapter = new Приёмная_комиссия_колледжа.Database.BD_AbiturientDataSetTableAdapters.ViewTableAdapter();
            this.timerConnect = new System.Windows.Forms.Timer(this.components);
            label12 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_AbiturientDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.grbSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label12
            // 
            label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label12.AutoSize = true;
            label12.BackColor = System.Drawing.Color.Transparent;
            label12.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label12.ForeColor = System.Drawing.Color.White;
            label12.Location = new System.Drawing.Point(18, 13);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(115, 19);
            label12.TabIndex = 129;
            label12.Text = "Общее кол-во:";
            // 
            // label2
            // 
            label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Century Schoolbook", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label2.Location = new System.Drawing.Point(27, 90);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(141, 18);
            label2.TabIndex = 14;
            label2.Text = "Код абитуриента";
            // 
            // label19
            // 
            label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label19.AutoSize = true;
            label19.BackColor = System.Drawing.Color.Transparent;
            label19.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label19.ForeColor = System.Drawing.Color.White;
            label19.Location = new System.Drawing.Point(155, 13);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(99, 19);
            label19.TabIndex = 138;
            label19.Text = "Контракт:";
            // 
            // label18
            // 
            label18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label18.AutoSize = true;
            label18.BackColor = System.Drawing.Color.Transparent;
            label18.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label18.ForeColor = System.Drawing.Color.White;
            label18.Location = new System.Drawing.Point(29, 13);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(82, 19);
            label18.TabIndex = 137;
            label18.Text = "Бюджет:";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(27, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 18);
            this.label1.TabIndex = 14;
            this.label1.Text = "ФИО";
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToResizeColumns = false;
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lFPDataGridViewTextBoxColumn,
            this.persIDDataGridViewTextBoxColumn});
            this.dataGridView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView.DataSource = this.viewBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.dataGridView.Location = new System.Drawing.Point(95, 48);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView.MultiSelect = false;
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView.RowTemplate.ReadOnly = true;
            this.dataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.ShowCellErrors = false;
            this.dataGridView.ShowRowErrors = false;
            this.dataGridView.Size = new System.Drawing.Size(400, 249);
            this.dataGridView.StandardTab = true;
            this.dataGridView.TabIndex = 0;
            this.dataGridView.TabStop = false;
            this.dataGridView.Visible = false;
            this.dataGridView.SelectionChanged += new System.EventHandler(this.dataGridView_SelectionChanged);
            this.dataGridView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            this.dataGridView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView_MouseDoubleClick);
            // 
            // lFPDataGridViewTextBoxColumn
            // 
            this.lFPDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.lFPDataGridViewTextBoxColumn.DataPropertyName = "LFP";
            this.lFPDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.lFPDataGridViewTextBoxColumn.Name = "lFPDataGridViewTextBoxColumn";
            this.lFPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // persIDDataGridViewTextBoxColumn
            // 
            this.persIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.persIDDataGridViewTextBoxColumn.DataPropertyName = "Pers_ID";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.persIDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.persIDDataGridViewTextBoxColumn.HeaderText = "Код абитуриента";
            this.persIDDataGridViewTextBoxColumn.Name = "persIDDataGridViewTextBoxColumn";
            this.persIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewBindingSource
            // 
            this.viewBindingSource.AllowNew = true;
            this.viewBindingSource.DataMember = "View";
            this.viewBindingSource.DataSource = this.bD_AbiturientDataSet;
            // 
            // bD_AbiturientDataSet
            // 
            this.bD_AbiturientDataSet.DataSetName = "BD_AbiturientDataSet";
            this.bD_AbiturientDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer2.Panel1.Controls.Add(this.chb_Clear);
            this.splitContainer2.Panel1.Controls.Add(this.grbSearch);
            this.splitContainer2.Panel1.Controls.Add(this.btn_ClearDB);
            this.splitContainer2.Panel1.Controls.Add(this.btn_Connection);
            this.splitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer2.Panel2.Controls.Add(this.pictureBox);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Last);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Next);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Previous);
            this.splitContainer2.Panel2.Controls.Add(this.btn_First);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Sidebar);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Delete);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Add);
            this.splitContainer2.Panel2.Controls.Add(this.btn_Change);
            this.splitContainer2.Panel2.Controls.Add(this.dataGridView);
            this.splitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.Size = new System.Drawing.Size(794, 374);
            this.splitContainer2.SplitterDistance = 196;
            this.splitContainer2.TabIndex = 0;
            this.splitContainer2.TabStop = false;
            // 
            // chb_Clear
            // 
            this.chb_Clear.AutoSize = true;
            this.chb_Clear.Enabled = false;
            this.chb_Clear.ForeColor = System.Drawing.Color.White;
            this.chb_Clear.Location = new System.Drawing.Point(15, 345);
            this.chb_Clear.Name = "chb_Clear";
            this.chb_Clear.Size = new System.Drawing.Size(15, 14);
            this.chb_Clear.TabIndex = 12;
            this.chb_Clear.TabStop = false;
            this.chb_Clear.UseVisualStyleBackColor = true;
            this.chb_Clear.CheckedChanged += new System.EventHandler(this.chb_Clear_CheckedChanged);
            // 
            // grbSearch
            // 
            this.grbSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbSearch.BackColor = System.Drawing.Color.Transparent;
            this.grbSearch.Controls.Add(this.sb_Code);
            this.grbSearch.Controls.Add(this.sb_LFP);
            this.grbSearch.Controls.Add(label2);
            this.grbSearch.Controls.Add(this.label1);
            this.grbSearch.Controls.Add(this.rb_Filter2);
            this.grbSearch.Controls.Add(this.rb_Filter1);
            this.grbSearch.Controls.Add(this.btn_Reset);
            this.grbSearch.Controls.Add(this.btn_Find);
            this.grbSearch.Enabled = false;
            this.grbSearch.ForeColor = System.Drawing.Color.White;
            this.grbSearch.Location = new System.Drawing.Point(8, 8);
            this.grbSearch.Name = "grbSearch";
            this.grbSearch.Size = new System.Drawing.Size(176, 210);
            this.grbSearch.TabIndex = 3;
            this.grbSearch.TabStop = false;
            this.grbSearch.Text = "Панель поиска";
            // 
            // sb_Code
            // 
            this.sb_Code.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.sb_Code.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sb_Code.ForeColor = System.Drawing.SystemColors.WindowText;
            this.sb_Code.Location = new System.Drawing.Point(5, 110);
            this.sb_Code.Name = "sb_Code";
            this.sb_Code.SearchEnabled = false;
            this.sb_Code.SearchValue = "";
            this.sb_Code.Size = new System.Drawing.Size(164, 32);
            this.sb_Code.TabIndex = 12;
            this.sb_Code.TabStop = false;
            // 
            // sb_LFP
            // 
            this.sb_LFP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.sb_LFP.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sb_LFP.ForeColor = System.Drawing.SystemColors.WindowText;
            this.sb_LFP.Location = new System.Drawing.Point(5, 50);
            this.sb_LFP.Name = "sb_LFP";
            this.sb_LFP.SearchEnabled = false;
            this.sb_LFP.SearchValue = "";
            this.sb_LFP.Size = new System.Drawing.Size(164, 32);
            this.sb_LFP.TabIndex = 12;
            this.sb_LFP.TabStop = false;
            // 
            // rb_Filter2
            // 
            this.rb_Filter2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rb_Filter2.AutoSize = true;
            this.rb_Filter2.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rb_Filter2.Location = new System.Drawing.Point(82, 142);
            this.rb_Filter2.Name = "rb_Filter2";
            this.rb_Filter2.Size = new System.Drawing.Size(78, 21);
            this.rb_Filter2.TabIndex = 10;
            this.rb_Filter2.Text = "\"... a ...\"";
            this.rb_Filter2.UseVisualStyleBackColor = true;
            // 
            // rb_Filter1
            // 
            this.rb_Filter1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rb_Filter1.AutoSize = true;
            this.rb_Filter1.Checked = true;
            this.rb_Filter1.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rb_Filter1.Location = new System.Drawing.Point(16, 142);
            this.rb_Filter1.Name = "rb_Filter1";
            this.rb_Filter1.Size = new System.Drawing.Size(62, 21);
            this.rb_Filter1.TabIndex = 9;
            this.rb_Filter1.TabStop = true;
            this.rb_Filter1.Text = "\"a ...\"";
            this.rb_Filter1.UseVisualStyleBackColor = true;
            // 
            // btn_Reset
            // 
            this.btn_Reset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Reset.BackColor = System.Drawing.Color.White;
            this.btn_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reset.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Reset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Reset.Location = new System.Drawing.Point(96, 169);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(67, 28);
            this.btn_Reset.TabIndex = 2;
            this.btn_Reset.Text = "Сброс";
            this.btn_Reset.UseVisualStyleBackColor = false;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Find.BackColor = System.Drawing.Color.White;
            this.btn_Find.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Find.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Find.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Find.Location = new System.Drawing.Point(13, 169);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(77, 28);
            this.btn_Find.TabIndex = 1;
            this.btn_Find.Text = "Найти";
            this.btn_Find.UseVisualStyleBackColor = false;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_ClearDB
            // 
            this.btn_ClearDB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ClearDB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(27)))), ((int)(((byte)(0)))));
            this.btn_ClearDB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ClearDB.Enabled = false;
            this.btn_ClearDB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ClearDB.Font = new System.Drawing.Font("Century Schoolbook", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_ClearDB.ForeColor = System.Drawing.Color.White;
            this.btn_ClearDB.Location = new System.Drawing.Point(36, 337);
            this.btn_ClearDB.Name = "btn_ClearDB";
            this.btn_ClearDB.Size = new System.Drawing.Size(142, 28);
            this.btn_ClearDB.TabIndex = 1;
            this.btn_ClearDB.Text = "Очистить БД";
            this.btn_ClearDB.UseVisualStyleBackColor = false;
            this.btn_ClearDB.Click += new System.EventHandler(this.btn_ClearDB_Click);
            // 
            // btn_Connection
            // 
            this.btn_Connection.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Connection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.btn_Connection.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Connection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Connection.Font = new System.Drawing.Font("Century Schoolbook", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Connection.ForeColor = System.Drawing.Color.White;
            this.btn_Connection.Location = new System.Drawing.Point(8, 291);
            this.btn_Connection.Name = "btn_Connection";
            this.btn_Connection.Size = new System.Drawing.Size(176, 38);
            this.btn_Connection.TabIndex = 0;
            this.btn_Connection.Text = "Обновить БД";
            this.btn_Connection.UseVisualStyleBackColor = false;
            this.btn_Connection.Click += new System.EventHandler(this.btn_Connection_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.Load;
            this.pictureBox.Location = new System.Drawing.Point(260, 137);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(70, 70);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox.TabIndex = 42;
            this.pictureBox.TabStop = false;
            this.pictureBox.Visible = false;
            // 
            // btn_Last
            // 
            this.btn_Last.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Last.BackColor = System.Drawing.Color.White;
            this.btn_Last.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Last.Enabled = false;
            this.btn_Last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Last.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Last.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Last.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.MoveLast;
            this.btn_Last.Location = new System.Drawing.Point(176, 337);
            this.btn_Last.Name = "btn_Last";
            this.btn_Last.Size = new System.Drawing.Size(38, 28);
            this.btn_Last.TabIndex = 5;
            this.btn_Last.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Last.UseVisualStyleBackColor = false;
            this.btn_Last.Click += new System.EventHandler(this.btn_Last_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Next.BackColor = System.Drawing.Color.White;
            this.btn_Next.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Next.Enabled = false;
            this.btn_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Next.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Next.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Next.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.MoveNext;
            this.btn_Next.Location = new System.Drawing.Point(132, 337);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(38, 28);
            this.btn_Next.TabIndex = 4;
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // btn_Previous
            // 
            this.btn_Previous.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Previous.BackColor = System.Drawing.Color.White;
            this.btn_Previous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Previous.Enabled = false;
            this.btn_Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Previous.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Previous.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Previous.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.MovePrevious;
            this.btn_Previous.Location = new System.Drawing.Point(88, 337);
            this.btn_Previous.Name = "btn_Previous";
            this.btn_Previous.Size = new System.Drawing.Size(38, 28);
            this.btn_Previous.TabIndex = 3;
            this.btn_Previous.UseVisualStyleBackColor = false;
            this.btn_Previous.Click += new System.EventHandler(this.btn_Previous_Click);
            // 
            // btn_First
            // 
            this.btn_First.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_First.BackColor = System.Drawing.Color.White;
            this.btn_First.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_First.Enabled = false;
            this.btn_First.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_First.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_First.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_First.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.MoveFirst;
            this.btn_First.Location = new System.Drawing.Point(44, 337);
            this.btn_First.Name = "btn_First";
            this.btn_First.Size = new System.Drawing.Size(38, 28);
            this.btn_First.TabIndex = 2;
            this.btn_First.UseVisualStyleBackColor = false;
            this.btn_First.Click += new System.EventHandler(this.btn_First_Click);
            // 
            // btn_Sidebar
            // 
            this.btn_Sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_Sidebar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_Sidebar.Enabled = false;
            this.btn_Sidebar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Sidebar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_Sidebar.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_sidebar;
            this.btn_Sidebar.Location = new System.Drawing.Point(0, 0);
            this.btn_Sidebar.Name = "btn_Sidebar";
            this.btn_Sidebar.Size = new System.Drawing.Size(38, 370);
            this.btn_Sidebar.TabIndex = 1;
            this.btn_Sidebar.UseVisualStyleBackColor = false;
            this.btn_Sidebar.Click += new System.EventHandler(this.btn_Sidebar_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Delete.BackColor = System.Drawing.Color.White;
            this.btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Delete.Enabled = false;
            this.btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Delete.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Delete.Location = new System.Drawing.Point(487, 337);
            this.btn_Delete.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(95, 28);
            this.btn_Delete.TabIndex = 8;
            this.btn_Delete.Text = "Удалить";
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Add.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_Add.BackColor = System.Drawing.Color.White;
            this.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add.Enabled = false;
            this.btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Add.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Add.Location = new System.Drawing.Point(273, 337);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(99, 28);
            this.btn_Add.TabIndex = 6;
            this.btn_Add.Text = "Добавить";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Change
            // 
            this.btn_Change.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Change.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_Change.BackColor = System.Drawing.Color.White;
            this.btn_Change.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Change.Enabled = false;
            this.btn_Change.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Change.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Change.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(82)))), ((int)(((byte)(154)))));
            this.btn_Change.Location = new System.Drawing.Point(378, 337);
            this.btn_Change.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Change.Name = "btn_Change";
            this.btn_Change.Size = new System.Drawing.Size(103, 28);
            this.btn_Change.TabIndex = 7;
            this.btn_Change.Text = "Изменить";
            this.btn_Change.UseVisualStyleBackColor = false;
            this.btn_Change.Click += new System.EventHandler(this.btn_Change_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(794, 426);
            this.splitContainer1.SplitterDistance = 48;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.TabStop = false;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(label12);
            this.splitContainer3.Panel1.Controls.Add(this.lbGeneralCount);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(794, 48);
            this.splitContainer3.SplitterDistance = 196;
            this.splitContainer3.TabIndex = 0;
            this.splitContainer3.TabStop = false;
            // 
            // lbGeneralCount
            // 
            this.lbGeneralCount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbGeneralCount.AutoSize = true;
            this.lbGeneralCount.BackColor = System.Drawing.Color.Transparent;
            this.lbGeneralCount.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbGeneralCount.ForeColor = System.Drawing.Color.White;
            this.lbGeneralCount.Location = new System.Drawing.Point(129, 13);
            this.lbGeneralCount.Name = "lbGeneralCount";
            this.lbGeneralCount.Size = new System.Drawing.Size(18, 19);
            this.lbGeneralCount.TabIndex = 128;
            this.lbGeneralCount.Text = "0";
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.label5);
            this.splitContainer4.Panel1.Controls.Add(this.label3);
            this.splitContainer4.Panel1.Controls.Add(this.lbEF);
            this.splitContainer4.Panel1.Controls.Add(this.lbDF);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(label19);
            this.splitContainer4.Panel2.Controls.Add(label18);
            this.splitContainer4.Panel2.Controls.Add(this.lbContractCount);
            this.splitContainer4.Panel2.Controls.Add(this.lbBudgetCount);
            this.splitContainer4.Size = new System.Drawing.Size(594, 48);
            this.splitContainer4.SplitterDistance = 290;
            this.splitContainer4.TabIndex = 0;
            this.splitContainer4.TabStop = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(160, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 19);
            this.label5.TabIndex = 135;
            this.label5.Text = "Заочная:";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(37, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 136;
            this.label3.Text = "Дневная:";
            // 
            // lbEF
            // 
            this.lbEF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbEF.AutoSize = true;
            this.lbEF.ForeColor = System.Drawing.Color.White;
            this.lbEF.Location = new System.Drawing.Point(232, 13);
            this.lbEF.Name = "lbEF";
            this.lbEF.Size = new System.Drawing.Size(18, 19);
            this.lbEF.TabIndex = 137;
            this.lbEF.Text = "0";
            // 
            // lbDF
            // 
            this.lbDF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDF.AutoSize = true;
            this.lbDF.ForeColor = System.Drawing.Color.White;
            this.lbDF.Location = new System.Drawing.Point(111, 13);
            this.lbDF.Name = "lbDF";
            this.lbDF.Size = new System.Drawing.Size(18, 19);
            this.lbDF.TabIndex = 138;
            this.lbDF.Text = "0";
            // 
            // lbContractCount
            // 
            this.lbContractCount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbContractCount.AutoSize = true;
            this.lbContractCount.BackColor = System.Drawing.Color.Transparent;
            this.lbContractCount.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbContractCount.ForeColor = System.Drawing.Color.White;
            this.lbContractCount.Location = new System.Drawing.Point(249, 13);
            this.lbContractCount.Name = "lbContractCount";
            this.lbContractCount.Size = new System.Drawing.Size(18, 19);
            this.lbContractCount.TabIndex = 136;
            this.lbContractCount.Text = "0";
            // 
            // lbBudgetCount
            // 
            this.lbBudgetCount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbBudgetCount.AutoSize = true;
            this.lbBudgetCount.BackColor = System.Drawing.Color.Transparent;
            this.lbBudgetCount.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBudgetCount.ForeColor = System.Drawing.Color.White;
            this.lbBudgetCount.Location = new System.Drawing.Point(106, 13);
            this.lbBudgetCount.Name = "lbBudgetCount";
            this.lbBudgetCount.Size = new System.Drawing.Size(18, 19);
            this.lbBudgetCount.TabIndex = 135;
            this.lbBudgetCount.Text = "0";
            // 
            // timerHide
            // 
            this.timerHide.Tick += new System.EventHandler(this.Hide);
            // 
            // timerShow
            // 
            this.timerShow.Tick += new System.EventHandler(this.Show);
            // 
            // viewTableAdapter
            // 
            this.viewTableAdapter.ClearBeforeFill = true;
            // 
            // timerConnect
            // 
            this.timerConnect.Interval = 250;
            this.timerConnect.Tick += new System.EventHandler(this.Connect);
            // 
            // Navigation_panel
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(794, 426);
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Navigation_panel";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Панель навигации";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Navigation_panel_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Navigation_panel_KeyDown);
            this.Layout += new System.Windows.Forms.LayoutEventHandler(this.Navigation_panel_Layout);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_AbiturientDataSet)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.grbSearch.ResumeLayout(false);
            this.grbSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Database.BD_AbiturientDataSet bD_AbiturientDataSet;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.BindingSource viewBindingSource;
        private Database.BD_AbiturientDataSetTableAdapters.ViewTableAdapter viewTableAdapter;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Change;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btn_ClearDB;
        private System.Windows.Forms.Button btn_Connection;
        private System.Windows.Forms.Button btn_Last;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Button btn_Previous;
        private System.Windows.Forms.Button btn_First;
        private System.Windows.Forms.GroupBox grbSearch;
        private System.Windows.Forms.RadioButton rb_Filter2;
        private System.Windows.Forms.RadioButton rb_Filter1;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.DataGridViewTextBoxColumn lFPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn persIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Timer timerHide;
        private System.Windows.Forms.Timer timerShow;
        private System.Windows.Forms.Button btn_Sidebar;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label lbGeneralCount;
        private Search.SearchBox sb_LFP;
        private Search.SearchBox sb_Code;
        private System.Windows.Forms.CheckBox chb_Clear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbEF;
        private System.Windows.Forms.Label lbDF;
        private System.Windows.Forms.Label lbContractCount;
        private System.Windows.Forms.Label lbBudgetCount;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Timer timerConnect;
    }
}