﻿namespace Приёмная_комиссия_колледжа
{
    partial class Main_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_menu));
            this.timerClose = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.показатьСкрытьМенюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.регистрацияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчётыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerHide = new System.Windows.Forms.Timer(this.components);
            this.timerShow = new System.Windows.Forms.Timer(this.components);
            this.прьпToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerText = new System.Windows.Forms.Timer(this.components);
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_About = new System.Windows.Forms.Button();
            this.btn_Rp = new System.Windows.Forms.Button();
            this.btn_Reg = new System.Windows.Forms.Button();
            this.btn_Help = new System.Windows.Forms.Button();
            this.chb_Anim = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // timerClose
            // 
            this.timerClose.Tick += new System.EventHandler(this.Close);
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon.BalloonTipText = "Программа была свёрнута в трей.";
            this.notifyIcon.BalloonTipTitle = "Уведомление";
            this.notifyIcon.ContextMenuStrip = this.contextMenuStrip;
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "Приёмная комиссия колледжа";
            this.notifyIcon.Visible = true;
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.показатьСкрытьМенюToolStripMenuItem,
            this.toolStripSeparator1,
            this.регистрацияToolStripMenuItem,
            this.отчётыToolStripMenuItem,
            this.toolStripSeparator2,
            this.выходToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(153, 104);
            // 
            // показатьСкрытьМенюToolStripMenuItem
            // 
            this.показатьСкрытьМенюToolStripMenuItem.AutoToolTip = true;
            this.показатьСкрытьМенюToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.показатьСкрытьМенюToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.показатьСкрытьМенюToolStripMenuItem.Name = "показатьСкрытьМенюToolStripMenuItem";
            this.показатьСкрытьМенюToolStripMenuItem.ShowShortcutKeys = false;
            this.показатьСкрытьМенюToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.показатьСкрытьМенюToolStripMenuItem.Text = "Показать меню";
            this.показатьСкрытьМенюToolStripMenuItem.Click += new System.EventHandler(this.показатьМенюToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // регистрацияToolStripMenuItem
            // 
            this.регистрацияToolStripMenuItem.AutoToolTip = true;
            this.регистрацияToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.регистрацияToolStripMenuItem.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_reg;
            this.регистрацияToolStripMenuItem.Name = "регистрацияToolStripMenuItem";
            this.регистрацияToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.регистрацияToolStripMenuItem.Text = "Регистрация";
            this.регистрацияToolStripMenuItem.Click += new System.EventHandler(this.регистрацияToolStripMenuItem_Click);
            // 
            // отчётыToolStripMenuItem
            // 
            this.отчётыToolStripMenuItem.AutoToolTip = true;
            this.отчётыToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.отчётыToolStripMenuItem.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_rep;
            this.отчётыToolStripMenuItem.Name = "отчётыToolStripMenuItem";
            this.отчётыToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.отчётыToolStripMenuItem.Text = "Отчёты";
            this.отчётыToolStripMenuItem.Click += new System.EventHandler(this.отчётыToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.AutoToolTip = true;
            this.выходToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.выходToolStripMenuItem.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_exit;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShowShortcutKeys = false;
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // timerHide
            // 
            this.timerHide.Tick += new System.EventHandler(this.Hide);
            // 
            // timerShow
            // 
            this.timerShow.Tick += new System.EventHandler(this.Show);
            // 
            // прьпToolStripMenuItem
            // 
            this.прьпToolStripMenuItem.Name = "прьпToolStripMenuItem";
            this.прьпToolStripMenuItem.ShowShortcutKeys = false;
            this.прьпToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.прьпToolStripMenuItem.Text = "прьп";
            this.прьпToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical270;
            // 
            // timerText
            // 
            this.timerText.Interval = 150;
            this.timerText.Tick += new System.EventHandler(this.timerText_Tick);
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Exit.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Exit.Font = new System.Drawing.Font("Century Schoolbook", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Exit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_Exit.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_exit;
            this.btn_Exit.Location = new System.Drawing.Point(378, 101);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(180, 80);
            this.btn_Exit.TabIndex = 5;
            this.btn_Exit.Text = " Выход ";
            this.btn_Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Exit.UseMnemonic = false;
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            this.btn_Exit.Paint += new System.Windows.Forms.PaintEventHandler(this.btns_Paint);
            this.btn_Exit.MouseLeave += new System.EventHandler(this.btn_Exit_MouseLeave);
            this.btn_Exit.MouseHover += new System.EventHandler(this.btn_Help_MouseHover);
            // 
            // btn_About
            // 
            this.btn_About.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_About.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_About.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_About.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_About.Font = new System.Drawing.Font("Century Schoolbook", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_About.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_About.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_info;
            this.btn_About.Location = new System.Drawing.Point(197, 101);
            this.btn_About.Name = "btn_About";
            this.btn_About.Size = new System.Drawing.Size(180, 80);
            this.btn_About.TabIndex = 4;
            this.btn_About.Text = " О программе ";
            this.btn_About.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_About.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_About.UseMnemonic = false;
            this.btn_About.UseVisualStyleBackColor = false;
            this.btn_About.Click += new System.EventHandler(this.btn_About_Click);
            this.btn_About.Paint += new System.Windows.Forms.PaintEventHandler(this.btns_Paint);
            this.btn_About.MouseLeave += new System.EventHandler(this.btn_About_MouseLeave);
            this.btn_About.MouseHover += new System.EventHandler(this.btn_About_MouseHover);
            // 
            // btn_Rp
            // 
            this.btn_Rp.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Rp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Rp.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Rp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Rp.Font = new System.Drawing.Font("Century Schoolbook", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Rp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_Rp.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_rep;
            this.btn_Rp.Location = new System.Drawing.Point(288, 20);
            this.btn_Rp.Name = "btn_Rp";
            this.btn_Rp.Size = new System.Drawing.Size(180, 80);
            this.btn_Rp.TabIndex = 1;
            this.btn_Rp.Text = " Отчёты ";
            this.btn_Rp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Rp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Rp.UseMnemonic = false;
            this.btn_Rp.UseVisualStyleBackColor = false;
            this.btn_Rp.Click += new System.EventHandler(this.btn_Rp_Click);
            this.btn_Rp.Paint += new System.Windows.Forms.PaintEventHandler(this.btns_Paint);
            this.btn_Rp.MouseLeave += new System.EventHandler(this.btn_Rp_MouseLeave);
            this.btn_Rp.MouseHover += new System.EventHandler(this.btn_Rp_MouseHover);
            // 
            // btn_Reg
            // 
            this.btn_Reg.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Reg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Reg.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Reg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reg.Font = new System.Drawing.Font("Century Schoolbook", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Reg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_Reg.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_reg;
            this.btn_Reg.Location = new System.Drawing.Point(107, 20);
            this.btn_Reg.Name = "btn_Reg";
            this.btn_Reg.Size = new System.Drawing.Size(180, 80);
            this.btn_Reg.TabIndex = 0;
            this.btn_Reg.Text = " Регистрация ";
            this.btn_Reg.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Reg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Reg.UseMnemonic = false;
            this.btn_Reg.UseVisualStyleBackColor = false;
            this.btn_Reg.Click += new System.EventHandler(this.btn_Reg_Click);
            this.btn_Reg.Paint += new System.Windows.Forms.PaintEventHandler(this.btns_Paint);
            this.btn_Reg.MouseLeave += new System.EventHandler(this.btn_Reg_MouseLeave);
            this.btn_Reg.MouseHover += new System.EventHandler(this.btn_Reg_MouseHover);
            // 
            // btn_Help
            // 
            this.btn_Help.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Help.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Help.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Help.Font = new System.Drawing.Font("Century Schoolbook", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Help.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_Help.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.icon_manual;
            this.btn_Help.Location = new System.Drawing.Point(16, 101);
            this.btn_Help.Name = "btn_Help";
            this.btn_Help.Size = new System.Drawing.Size(180, 80);
            this.btn_Help.TabIndex = 3;
            this.btn_Help.Text = " Справка ";
            this.btn_Help.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Help.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Help.UseMnemonic = false;
            this.btn_Help.UseVisualStyleBackColor = false;
            this.btn_Help.Click += new System.EventHandler(this.btn_Help_Click);
            this.btn_Help.Paint += new System.Windows.Forms.PaintEventHandler(this.btns_Paint);
            this.btn_Help.MouseLeave += new System.EventHandler(this.btn_Help_MouseLeave);
            this.btn_Help.MouseHover += new System.EventHandler(this.btn_Help_MouseHover);
            // 
            // chb_Anim
            // 
            this.chb_Anim.AutoSize = true;
            this.chb_Anim.BackColor = System.Drawing.SystemColors.ControlLight;
            this.chb_Anim.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chb_Anim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.chb_Anim.Location = new System.Drawing.Point(16, 206);
            this.chb_Anim.Name = "chb_Anim";
            this.chb_Anim.Size = new System.Drawing.Size(332, 23);
            this.chb_Anim.TabIndex = 6;
            this.chb_Anim.Text = "Отключить анимацию окон и текста";
            this.chb_Anim.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 202);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(574, 30);
            this.panel1.TabIndex = 7;
            // 
            // Main_menu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(574, 232);
            this.Controls.Add(this.chb_Anim);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_About);
            this.Controls.Add(this.btn_Rp);
            this.Controls.Add(this.btn_Reg);
            this.Controls.Add(this.btn_Help);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main_menu";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Приёмная комиссия колледжа";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_menu_FormClosing);
            this.Load += new System.EventHandler(this.Main_menu_Load);
            this.Layout += new System.Windows.Forms.LayoutEventHandler(this.Main_menu_Layout);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Reg;
        private System.Windows.Forms.Button btn_Rp;
        private System.Windows.Forms.Button btn_About;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Help;
        private System.Windows.Forms.Timer timerClose;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.Timer timerHide;
        private System.Windows.Forms.Timer timerShow;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem показатьСкрытьМенюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem прьпToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem регистрацияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчётыToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Timer timerText;
        private System.Windows.Forms.CheckBox chb_Anim;
        private System.Windows.Forms.Panel panel1;




    }
}