﻿namespace Приёмная_комиссия_колледжа
{
    partial class Registration_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label ab_EDSLabel;
            System.Windows.Forms.Label ab_EDNLabel;
            System.Windows.Forms.Label ab_ED_DateLabel;
            System.Windows.Forms.Label ab_ED_WhoLabel;
            System.Windows.Forms.Label ab_ED_ExcLabel;
            System.Windows.Forms.Label ab_PrivLabel;
            System.Windows.Forms.Label ab_EDKLabel;
            System.Windows.Forms.Label pers_LastnameLabel;
            System.Windows.Forms.Label pers_FirstnameLabel;
            System.Windows.Forms.Label pers_PatronymicLabel;
            System.Windows.Forms.Label pers_SexLabel;
            System.Windows.Forms.Label pers_BirthdayLabel;
            System.Windows.Forms.Label pers_PhoneLabel;
            System.Windows.Forms.Label pers_DKLabel;
            System.Windows.Forms.Label pers_DSLabel;
            System.Windows.Forms.Label pers_DNLabel;
            System.Windows.Forms.Label pers_DDateLabel;
            System.Windows.Forms.Label pers_DWhoLabel;
            System.Windows.Forms.Label pers_INNLabel;
            System.Windows.Forms.Label ad_CountryLabel;
            System.Windows.Forms.Label ad_CityLabel;
            System.Windows.Forms.Label ad_IndexLabel;
            System.Windows.Forms.Label ad_StreetLabel;
            System.Windows.Forms.Label ad_HouseLabel;
            System.Windows.Forms.Label ad_FlatLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label ab_MedCertLabel;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label16;
            System.Windows.Forms.Label label17;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label18;
            System.Windows.Forms.Label label21;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration_form));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_Spec = new System.Windows.Forms.Button();
            this.IDLabel = new System.Windows.Forms.Label();
            this.ab_EBComboBox = new System.Windows.Forms.ComboBox();
            this.viewFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_AbiturientDataSet = new Приёмная_комиссия_колледжа.Database.BD_AbiturientDataSet();
            this.ab_EFComboBox = new System.Windows.Forms.ComboBox();
            this.PrivTextBox_txt = new System.Windows.Forms.TextBox();
            this.IDTextBox_txt = new System.Windows.Forms.TextBox();
            this.ab_Spec1ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_Spec2ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_Spec3ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_MedCert1ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_MedCert2ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_MedCert3ComboBox = new System.Windows.Forms.ComboBox();
            this.ab_ForLangComboBox = new System.Windows.Forms.ComboBox();
            this.ab_EDSTextBox_txt = new System.Windows.Forms.TextBox();
            this.ab_EDNTextBox_num = new System.Windows.Forms.TextBox();
            this.ab_ED_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ED_WhoTextBox_txt = new System.Windows.Forms.TextBox();
            this.ab_ED_ExcComboBox = new System.Windows.Forms.ComboBox();
            this.ab_EDKComboBox = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pers_PhoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.pers_DKComboBox = new System.Windows.Forms.ComboBox();
            this.pers_SexComboBox = new System.Windows.Forms.ComboBox();
            this.pers_LastnameTextBox_txt = new System.Windows.Forms.TextBox();
            this.pers_FirstnameTextBox_txt = new System.Windows.Forms.TextBox();
            this.pers_PatronymicTextBox_txt = new System.Windows.Forms.TextBox();
            this.pers_BirthdayDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.pers_DSTextBox_txt = new System.Windows.Forms.TextBox();
            this.pers_DNTextBox_num = new System.Windows.Forms.TextBox();
            this.pers_DDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.DWhoTextBox_txt = new System.Windows.Forms.TextBox();
            this.pers_INNTextBox_num = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CountryTextBox_txt = new System.Windows.Forms.TextBox();
            this.CityTextBox_txt = new System.Windows.Forms.TextBox();
            this.ad_IndexTextBox_num = new System.Windows.Forms.TextBox();
            this.StreetTextBox_txt = new System.Windows.Forms.TextBox();
            this.ad_HouseTextBox_num = new System.Windows.Forms.TextBox();
            this.ad_FlatTextBox_num = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btn_Prof = new System.Windows.Forms.Button();
            this.btn_Comp = new System.Windows.Forms.Button();
            this.ItogoLabel = new System.Windows.Forms.Label();
            this.cs_Comp_scoreLabel = new System.Windows.Forms.Label();
            this.cs_GPATextBox = new System.Windows.Forms.TextBox();
            this.cs_Com_subComboBox = new System.Windows.Forms.ComboBox();
            this.cs_Com_sub_markTextBox = new System.Windows.Forms.TextBox();
            this.cs_Prof_subComboBox = new System.Windows.Forms.ComboBox();
            this.cs_Prof_sub_markTextBox = new System.Windows.Forms.TextBox();
            this.cs_Extra_pointsTextBox = new System.Windows.Forms.TextBox();
            this.cs_TestTextBox = new System.Windows.Forms.TextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btn_Confirm = new System.Windows.Forms.Button();
            this.timerShow = new System.Windows.Forms.Timer(this.components);
            this.view_FormTableAdapter = new Приёмная_комиссия_колледжа.Database.BD_AbiturientDataSetTableAdapters.View_FormTableAdapter();
            this.timerHide = new System.Windows.Forms.Timer(this.components);
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ab_EDSLabel = new System.Windows.Forms.Label();
            ab_EDNLabel = new System.Windows.Forms.Label();
            ab_ED_DateLabel = new System.Windows.Forms.Label();
            ab_ED_WhoLabel = new System.Windows.Forms.Label();
            ab_ED_ExcLabel = new System.Windows.Forms.Label();
            ab_PrivLabel = new System.Windows.Forms.Label();
            ab_EDKLabel = new System.Windows.Forms.Label();
            pers_LastnameLabel = new System.Windows.Forms.Label();
            pers_FirstnameLabel = new System.Windows.Forms.Label();
            pers_PatronymicLabel = new System.Windows.Forms.Label();
            pers_SexLabel = new System.Windows.Forms.Label();
            pers_BirthdayLabel = new System.Windows.Forms.Label();
            pers_PhoneLabel = new System.Windows.Forms.Label();
            pers_DKLabel = new System.Windows.Forms.Label();
            pers_DSLabel = new System.Windows.Forms.Label();
            pers_DNLabel = new System.Windows.Forms.Label();
            pers_DDateLabel = new System.Windows.Forms.Label();
            pers_DWhoLabel = new System.Windows.Forms.Label();
            pers_INNLabel = new System.Windows.Forms.Label();
            ad_CountryLabel = new System.Windows.Forms.Label();
            ad_CityLabel = new System.Windows.Forms.Label();
            ad_IndexLabel = new System.Windows.Forms.Label();
            ad_StreetLabel = new System.Windows.Forms.Label();
            ad_HouseLabel = new System.Windows.Forms.Label();
            ad_FlatLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            ab_MedCertLabel = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewFormBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_AbiturientDataSet)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // ab_EDSLabel
            // 
            ab_EDSLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_EDSLabel.AutoSize = true;
            ab_EDSLabel.BackColor = System.Drawing.Color.Transparent;
            ab_EDSLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_EDSLabel.ForeColor = System.Drawing.Color.White;
            ab_EDSLabel.Location = new System.Drawing.Point(130, 89);
            ab_EDSLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_EDSLabel.Name = "ab_EDSLabel";
            ab_EDSLabel.Size = new System.Drawing.Size(60, 19);
            ab_EDSLabel.TabIndex = 4;
            ab_EDSLabel.Text = "Серия:";
            // 
            // ab_EDNLabel
            // 
            ab_EDNLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_EDNLabel.AutoSize = true;
            ab_EDNLabel.BackColor = System.Drawing.Color.Transparent;
            ab_EDNLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_EDNLabel.ForeColor = System.Drawing.Color.White;
            ab_EDNLabel.Location = new System.Drawing.Point(127, 124);
            ab_EDNLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_EDNLabel.Name = "ab_EDNLabel";
            ab_EDNLabel.Size = new System.Drawing.Size(63, 19);
            ab_EDNLabel.TabIndex = 6;
            ab_EDNLabel.Text = "Номер:";
            // 
            // ab_ED_DateLabel
            // 
            ab_ED_DateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_ED_DateLabel.AutoSize = true;
            ab_ED_DateLabel.BackColor = System.Drawing.Color.Transparent;
            ab_ED_DateLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_ED_DateLabel.ForeColor = System.Drawing.Color.White;
            ab_ED_DateLabel.Location = new System.Drawing.Point(47, 159);
            ab_ED_DateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_ED_DateLabel.Name = "ab_ED_DateLabel";
            ab_ED_DateLabel.Size = new System.Drawing.Size(143, 19);
            ab_ED_DateLabel.TabIndex = 8;
            ab_ED_DateLabel.Text = "Дата получения:";
            // 
            // ab_ED_WhoLabel
            // 
            ab_ED_WhoLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_ED_WhoLabel.AutoSize = true;
            ab_ED_WhoLabel.BackColor = System.Drawing.Color.Transparent;
            ab_ED_WhoLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_ED_WhoLabel.ForeColor = System.Drawing.Color.White;
            ab_ED_WhoLabel.Location = new System.Drawing.Point(94, 194);
            ab_ED_WhoLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_ED_WhoLabel.Name = "ab_ED_WhoLabel";
            ab_ED_WhoLabel.Size = new System.Drawing.Size(96, 19);
            ab_ED_WhoLabel.TabIndex = 10;
            ab_ED_WhoLabel.Text = "Кем выдан:";
            // 
            // ab_ED_ExcLabel
            // 
            ab_ED_ExcLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_ED_ExcLabel.AutoSize = true;
            ab_ED_ExcLabel.BackColor = System.Drawing.Color.Transparent;
            ab_ED_ExcLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_ED_ExcLabel.ForeColor = System.Drawing.Color.White;
            ab_ED_ExcLabel.Location = new System.Drawing.Point(80, 229);
            ab_ED_ExcLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_ED_ExcLabel.Name = "ab_ED_ExcLabel";
            ab_ED_ExcLabel.Size = new System.Drawing.Size(110, 19);
            ab_ED_ExcLabel.TabIndex = 12;
            ab_ED_ExcLabel.Text = "С отличием:";
            // 
            // ab_PrivLabel
            // 
            ab_PrivLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_PrivLabel.AutoSize = true;
            ab_PrivLabel.BackColor = System.Drawing.Color.Transparent;
            ab_PrivLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_PrivLabel.ForeColor = System.Drawing.Color.White;
            ab_PrivLabel.Location = new System.Drawing.Point(47, 299);
            ab_PrivLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_PrivLabel.Name = "ab_PrivLabel";
            ab_PrivLabel.Size = new System.Drawing.Size(143, 19);
            ab_PrivLabel.TabIndex = 24;
            ab_PrivLabel.Text = "Наличие льготы:";
            // 
            // ab_EDKLabel
            // 
            ab_EDKLabel.AutoSize = true;
            ab_EDKLabel.BackColor = System.Drawing.Color.Transparent;
            ab_EDKLabel.ForeColor = System.Drawing.Color.Gold;
            ab_EDKLabel.Location = new System.Drawing.Point(189, -420);
            ab_EDKLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_EDKLabel.Name = "ab_EDKLabel";
            ab_EDKLabel.Size = new System.Drawing.Size(73, 19);
            ab_EDKLabel.TabIndex = 54;
            ab_EDKLabel.Text = "Ab EDK:";
            // 
            // pers_LastnameLabel
            // 
            pers_LastnameLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_LastnameLabel.AutoSize = true;
            pers_LastnameLabel.BackColor = System.Drawing.Color.Transparent;
            pers_LastnameLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_LastnameLabel.ForeColor = System.Drawing.Color.White;
            pers_LastnameLabel.Location = new System.Drawing.Point(70, 38);
            pers_LastnameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_LastnameLabel.Name = "pers_LastnameLabel";
            pers_LastnameLabel.Size = new System.Drawing.Size(88, 19);
            pers_LastnameLabel.TabIndex = 55;
            pers_LastnameLabel.Text = "Фамилия:";
            // 
            // pers_FirstnameLabel
            // 
            pers_FirstnameLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_FirstnameLabel.AutoSize = true;
            pers_FirstnameLabel.BackColor = System.Drawing.Color.Transparent;
            pers_FirstnameLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_FirstnameLabel.ForeColor = System.Drawing.Color.White;
            pers_FirstnameLabel.Location = new System.Drawing.Point(110, 71);
            pers_FirstnameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_FirstnameLabel.Name = "pers_FirstnameLabel";
            pers_FirstnameLabel.Size = new System.Drawing.Size(48, 19);
            pers_FirstnameLabel.TabIndex = 57;
            pers_FirstnameLabel.Text = "Имя:";
            // 
            // pers_PatronymicLabel
            // 
            pers_PatronymicLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_PatronymicLabel.AutoSize = true;
            pers_PatronymicLabel.BackColor = System.Drawing.Color.Transparent;
            pers_PatronymicLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_PatronymicLabel.ForeColor = System.Drawing.Color.White;
            pers_PatronymicLabel.Location = new System.Drawing.Point(66, 104);
            pers_PatronymicLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_PatronymicLabel.Name = "pers_PatronymicLabel";
            pers_PatronymicLabel.Size = new System.Drawing.Size(92, 19);
            pers_PatronymicLabel.TabIndex = 59;
            pers_PatronymicLabel.Text = "Отчество:";
            // 
            // pers_SexLabel
            // 
            pers_SexLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_SexLabel.AutoSize = true;
            pers_SexLabel.BackColor = System.Drawing.Color.Transparent;
            pers_SexLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_SexLabel.ForeColor = System.Drawing.Color.White;
            pers_SexLabel.Location = new System.Drawing.Point(114, 137);
            pers_SexLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_SexLabel.Name = "pers_SexLabel";
            pers_SexLabel.Size = new System.Drawing.Size(44, 19);
            pers_SexLabel.TabIndex = 61;
            pers_SexLabel.Text = "Пол:";
            // 
            // pers_BirthdayLabel
            // 
            pers_BirthdayLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_BirthdayLabel.AutoSize = true;
            pers_BirthdayLabel.BackColor = System.Drawing.Color.Transparent;
            pers_BirthdayLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_BirthdayLabel.ForeColor = System.Drawing.Color.White;
            pers_BirthdayLabel.Location = new System.Drawing.Point(19, 170);
            pers_BirthdayLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_BirthdayLabel.Name = "pers_BirthdayLabel";
            pers_BirthdayLabel.Size = new System.Drawing.Size(139, 19);
            pers_BirthdayLabel.TabIndex = 63;
            pers_BirthdayLabel.Text = "Дата рождения:";
            // 
            // pers_PhoneLabel
            // 
            pers_PhoneLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_PhoneLabel.AutoSize = true;
            pers_PhoneLabel.BackColor = System.Drawing.Color.Transparent;
            pers_PhoneLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_PhoneLabel.ForeColor = System.Drawing.Color.White;
            pers_PhoneLabel.Location = new System.Drawing.Point(79, 203);
            pers_PhoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_PhoneLabel.Name = "pers_PhoneLabel";
            pers_PhoneLabel.Size = new System.Drawing.Size(79, 19);
            pers_PhoneLabel.TabIndex = 65;
            pers_PhoneLabel.Text = "Телефон:";
            // 
            // pers_DKLabel
            // 
            pers_DKLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_DKLabel.AutoSize = true;
            pers_DKLabel.BackColor = System.Drawing.Color.Transparent;
            pers_DKLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_DKLabel.ForeColor = System.Drawing.Color.White;
            pers_DKLabel.Location = new System.Drawing.Point(395, 38);
            pers_DKLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_DKLabel.Name = "pers_DKLabel";
            pers_DKLabel.Size = new System.Drawing.Size(134, 19);
            pers_DKLabel.TabIndex = 69;
            pers_DKLabel.Text = "Вид документа:";
            // 
            // pers_DSLabel
            // 
            pers_DSLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_DSLabel.AutoSize = true;
            pers_DSLabel.BackColor = System.Drawing.Color.Transparent;
            pers_DSLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_DSLabel.ForeColor = System.Drawing.Color.White;
            pers_DSLabel.Location = new System.Drawing.Point(469, 71);
            pers_DSLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_DSLabel.Name = "pers_DSLabel";
            pers_DSLabel.Size = new System.Drawing.Size(60, 19);
            pers_DSLabel.TabIndex = 71;
            pers_DSLabel.Text = "Серия:";
            // 
            // pers_DNLabel
            // 
            pers_DNLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_DNLabel.AutoSize = true;
            pers_DNLabel.BackColor = System.Drawing.Color.Transparent;
            pers_DNLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_DNLabel.ForeColor = System.Drawing.Color.White;
            pers_DNLabel.Location = new System.Drawing.Point(465, 104);
            pers_DNLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_DNLabel.Name = "pers_DNLabel";
            pers_DNLabel.Size = new System.Drawing.Size(63, 19);
            pers_DNLabel.TabIndex = 73;
            pers_DNLabel.Text = "Номер:";
            // 
            // pers_DDateLabel
            // 
            pers_DDateLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_DDateLabel.AutoSize = true;
            pers_DDateLabel.BackColor = System.Drawing.Color.Transparent;
            pers_DDateLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_DDateLabel.ForeColor = System.Drawing.Color.White;
            pers_DDateLabel.Location = new System.Drawing.Point(385, 137);
            pers_DDateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_DDateLabel.Name = "pers_DDateLabel";
            pers_DDateLabel.Size = new System.Drawing.Size(143, 19);
            pers_DDateLabel.TabIndex = 75;
            pers_DDateLabel.Text = "Дата получения:";
            // 
            // pers_DWhoLabel
            // 
            pers_DWhoLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_DWhoLabel.AutoSize = true;
            pers_DWhoLabel.BackColor = System.Drawing.Color.Transparent;
            pers_DWhoLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_DWhoLabel.ForeColor = System.Drawing.Color.White;
            pers_DWhoLabel.Location = new System.Drawing.Point(433, 170);
            pers_DWhoLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_DWhoLabel.Name = "pers_DWhoLabel";
            pers_DWhoLabel.Size = new System.Drawing.Size(96, 19);
            pers_DWhoLabel.TabIndex = 77;
            pers_DWhoLabel.Text = "Кем выдан:";
            // 
            // pers_INNLabel
            // 
            pers_INNLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            pers_INNLabel.AutoSize = true;
            pers_INNLabel.BackColor = System.Drawing.Color.Transparent;
            pers_INNLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            pers_INNLabel.ForeColor = System.Drawing.Color.White;
            pers_INNLabel.Location = new System.Drawing.Point(379, 203);
            pers_INNLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            pers_INNLabel.Name = "pers_INNLabel";
            pers_INNLabel.Size = new System.Drawing.Size(238, 19);
            pers_INNLabel.TabIndex = 79;
            pers_INNLabel.Text = "Идентификационный номер:";
            // 
            // ad_CountryLabel
            // 
            ad_CountryLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_CountryLabel.AutoSize = true;
            ad_CountryLabel.BackColor = System.Drawing.Color.Transparent;
            ad_CountryLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_CountryLabel.ForeColor = System.Drawing.Color.White;
            ad_CountryLabel.Location = new System.Drawing.Point(63, 88);
            ad_CountryLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_CountryLabel.Name = "ad_CountryLabel";
            ad_CountryLabel.Size = new System.Drawing.Size(76, 19);
            ad_CountryLabel.TabIndex = 66;
            ad_CountryLabel.Text = "Страна:";
            // 
            // ad_CityLabel
            // 
            ad_CityLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_CityLabel.AutoSize = true;
            ad_CityLabel.BackColor = System.Drawing.Color.Transparent;
            ad_CityLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_CityLabel.ForeColor = System.Drawing.Color.White;
            ad_CityLabel.Location = new System.Drawing.Point(83, 121);
            ad_CityLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_CityLabel.Name = "ad_CityLabel";
            ad_CityLabel.Size = new System.Drawing.Size(56, 19);
            ad_CityLabel.TabIndex = 68;
            ad_CityLabel.Text = "Город:";
            // 
            // ad_IndexLabel
            // 
            ad_IndexLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_IndexLabel.AutoSize = true;
            ad_IndexLabel.BackColor = System.Drawing.Color.Transparent;
            ad_IndexLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_IndexLabel.ForeColor = System.Drawing.Color.White;
            ad_IndexLabel.Location = new System.Drawing.Point(71, 154);
            ad_IndexLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_IndexLabel.Name = "ad_IndexLabel";
            ad_IndexLabel.Size = new System.Drawing.Size(68, 19);
            ad_IndexLabel.TabIndex = 70;
            ad_IndexLabel.Text = "Индекс:";
            // 
            // ad_StreetLabel
            // 
            ad_StreetLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_StreetLabel.AutoSize = true;
            ad_StreetLabel.BackColor = System.Drawing.Color.Transparent;
            ad_StreetLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_StreetLabel.ForeColor = System.Drawing.Color.White;
            ad_StreetLabel.Location = new System.Drawing.Point(424, 88);
            ad_StreetLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_StreetLabel.Name = "ad_StreetLabel";
            ad_StreetLabel.Size = new System.Drawing.Size(64, 19);
            ad_StreetLabel.TabIndex = 72;
            ad_StreetLabel.Text = "Улица:";
            // 
            // ad_HouseLabel
            // 
            ad_HouseLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_HouseLabel.AutoSize = true;
            ad_HouseLabel.BackColor = System.Drawing.Color.Transparent;
            ad_HouseLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_HouseLabel.ForeColor = System.Drawing.Color.White;
            ad_HouseLabel.Location = new System.Drawing.Point(441, 121);
            ad_HouseLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_HouseLabel.Name = "ad_HouseLabel";
            ad_HouseLabel.Size = new System.Drawing.Size(47, 19);
            ad_HouseLabel.TabIndex = 74;
            ad_HouseLabel.Text = "Дом:";
            // 
            // ad_FlatLabel
            // 
            ad_FlatLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            ad_FlatLabel.AutoSize = true;
            ad_FlatLabel.BackColor = System.Drawing.Color.Transparent;
            ad_FlatLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ad_FlatLabel.ForeColor = System.Drawing.Color.White;
            ad_FlatLabel.Location = new System.Drawing.Point(395, 154);
            ad_FlatLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ad_FlatLabel.Name = "ad_FlatLabel";
            ad_FlatLabel.Size = new System.Drawing.Size(93, 19);
            ad_FlatLabel.TabIndex = 76;
            ad_FlatLabel.Text = "Квартира:";
            // 
            // label1
            // 
            label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.Transparent;
            label1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(56, 54);
            label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(134, 19);
            label1.TabIndex = 28;
            label1.Text = "Вид документа:";
            // 
            // label3
            // 
            label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label3.AutoSize = true;
            label3.BackColor = System.Drawing.Color.Transparent;
            label3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label3.ForeColor = System.Drawing.Color.White;
            label3.Location = new System.Drawing.Point(22, 264);
            label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(168, 19);
            label3.TabIndex = 35;
            label3.Text = "Иностранный язык:";
            // 
            // label2
            // 
            label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.Transparent;
            label2.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(420, 124);
            label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(152, 19);
            label2.TabIndex = 110;
            label2.Text = "Мед. справка 25-ю:";
            // 
            // label4
            // 
            label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.Transparent;
            label4.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(437, 89);
            label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(135, 19);
            label4.TabIndex = 109;
            label4.Text = "Мед. справка 63:";
            // 
            // ab_MedCertLabel
            // 
            ab_MedCertLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            ab_MedCertLabel.AutoSize = true;
            ab_MedCertLabel.BackColor = System.Drawing.Color.Transparent;
            ab_MedCertLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            ab_MedCertLabel.ForeColor = System.Drawing.Color.White;
            ab_MedCertLabel.Location = new System.Drawing.Point(415, 54);
            ab_MedCertLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ab_MedCertLabel.Name = "ab_MedCertLabel";
            ab_MedCertLabel.Size = new System.Drawing.Size(157, 19);
            ab_MedCertLabel.TabIndex = 103;
            ab_MedCertLabel.Text = "Мед. справка 086-у:";
            // 
            // label5
            // 
            label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label5.AutoSize = true;
            label5.BackColor = System.Drawing.Color.Transparent;
            label5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label5.ForeColor = System.Drawing.Color.White;
            label5.Location = new System.Drawing.Point(425, 159);
            label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(147, 19);
            label5.TabIndex = 104;
            label5.Text = "Специальность 1:";
            // 
            // label6
            // 
            label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label6.AutoSize = true;
            label6.BackColor = System.Drawing.Color.Transparent;
            label6.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label6.ForeColor = System.Drawing.Color.White;
            label6.Location = new System.Drawing.Point(425, 194);
            label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(147, 19);
            label6.TabIndex = 105;
            label6.Text = "Специальность 2:";
            // 
            // label7
            // 
            label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label7.AutoSize = true;
            label7.BackColor = System.Drawing.Color.Transparent;
            label7.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label7.ForeColor = System.Drawing.Color.White;
            label7.Location = new System.Drawing.Point(425, 229);
            label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(147, 19);
            label7.TabIndex = 106;
            label7.Text = "Специальность 3:";
            // 
            // label8
            // 
            label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label8.AutoSize = true;
            label8.BackColor = System.Drawing.Color.Transparent;
            label8.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label8.ForeColor = System.Drawing.Color.White;
            label8.Location = new System.Drawing.Point(432, 264);
            label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(140, 19);
            label8.TabIndex = 107;
            label8.Text = "Форма обучения:";
            // 
            // label9
            // 
            label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label9.AutoSize = true;
            label9.BackColor = System.Drawing.Color.Transparent;
            label9.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label9.ForeColor = System.Drawing.Color.White;
            label9.Location = new System.Drawing.Point(428, 299);
            label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(144, 19);
            label9.TabIndex = 108;
            label9.Text = "Финансирование:";
            // 
            // label10
            // 
            label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label10.AutoSize = true;
            label10.BackColor = System.Drawing.Color.Transparent;
            label10.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label10.ForeColor = System.Drawing.Color.White;
            label10.Location = new System.Drawing.Point(145, 138);
            label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(121, 19);
            label10.TabIndex = 103;
            label10.Text = "Средний балл:";
            // 
            // label11
            // 
            label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label11.AutoSize = true;
            label11.BackColor = System.Drawing.Color.Transparent;
            label11.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label11.ForeColor = System.Drawing.Color.White;
            label11.Location = new System.Drawing.Point(454, 68);
            label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(164, 19);
            label11.TabIndex = 104;
            label11.Text = "Количество баллов:";
            // 
            // label13
            // 
            label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label13.AutoSize = true;
            label13.BackColor = System.Drawing.Color.Transparent;
            label13.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label13.ForeColor = System.Drawing.Color.White;
            label13.Location = new System.Drawing.Point(415, 173);
            label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(203, 19);
            label13.TabIndex = 106;
            label13.Text = "Дополнительные баллы:";
            // 
            // label14
            // 
            label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label14.AutoSize = true;
            label14.BackColor = System.Drawing.Color.Transparent;
            label14.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label14.ForeColor = System.Drawing.Color.White;
            label14.Location = new System.Drawing.Point(362, 138);
            label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(256, 19);
            label14.TabIndex = 107;
            label14.Text = "Допополнительное испытание:";
            // 
            // label16
            // 
            label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label16.AutoSize = true;
            label16.BackColor = System.Drawing.Color.Transparent;
            label16.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label16.ForeColor = System.Drawing.Color.White;
            label16.Location = new System.Drawing.Point(64, 68);
            label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(202, 19);
            label16.TabIndex = 109;
            label16.Text = "Обязательный предмет:";
            // 
            // label17
            // 
            label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label17.AutoSize = true;
            label17.BackColor = System.Drawing.Color.Transparent;
            label17.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label17.ForeColor = System.Drawing.Color.White;
            label17.Location = new System.Drawing.Point(79, 103);
            label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(187, 19);
            label17.TabIndex = 110;
            label17.Text = "Профильный предмет:";
            // 
            // label15
            // 
            label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            label15.AutoSize = true;
            label15.BackColor = System.Drawing.Color.Transparent;
            label15.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            label15.ForeColor = System.Drawing.Color.White;
            label15.Location = new System.Drawing.Point(454, 103);
            label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(164, 19);
            label15.TabIndex = 114;
            label15.Text = "Количество баллов:";
            // 
            // label12
            // 
            label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label12.ForeColor = System.Drawing.Color.Black;
            label12.Location = new System.Drawing.Point(709, 166);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(15, 2);
            label12.TabIndex = 112;
            // 
            // label18
            // 
            label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label18.ForeColor = System.Drawing.Color.Black;
            label18.Location = new System.Drawing.Point(709, 237);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(15, 2);
            label18.TabIndex = 112;
            // 
            // label21
            // 
            label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label21.ForeColor = System.Drawing.Color.Black;
            label21.Location = new System.Drawing.Point(708, 202);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(10, 2);
            label21.TabIndex = 112;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.AutoScrollMinSize = new System.Drawing.Size(0, 334);
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.btn_Spec);
            this.tabPage1.Controls.Add(this.IDLabel);
            this.tabPage1.Controls.Add(this.ab_EBComboBox);
            this.tabPage1.Controls.Add(this.ab_EFComboBox);
            this.tabPage1.Controls.Add(this.PrivTextBox_txt);
            this.tabPage1.Controls.Add(this.IDTextBox_txt);
            this.tabPage1.Controls.Add(label2);
            this.tabPage1.Controls.Add(label4);
            this.tabPage1.Controls.Add(ab_MedCertLabel);
            this.tabPage1.Controls.Add(label5);
            this.tabPage1.Controls.Add(label6);
            this.tabPage1.Controls.Add(label7);
            this.tabPage1.Controls.Add(label8);
            this.tabPage1.Controls.Add(label9);
            this.tabPage1.Controls.Add(this.ab_Spec1ComboBox);
            this.tabPage1.Controls.Add(this.ab_Spec2ComboBox);
            this.tabPage1.Controls.Add(this.ab_Spec3ComboBox);
            this.tabPage1.Controls.Add(this.ab_MedCert1ComboBox);
            this.tabPage1.Controls.Add(this.ab_MedCert2ComboBox);
            this.tabPage1.Controls.Add(this.ab_MedCert3ComboBox);
            this.tabPage1.Controls.Add(this.ab_ForLangComboBox);
            this.tabPage1.Controls.Add(this.ab_EDSTextBox_txt);
            this.tabPage1.Controls.Add(this.ab_EDNTextBox_num);
            this.tabPage1.Controls.Add(this.ab_ED_DateDateTimePicker);
            this.tabPage1.Controls.Add(this.ED_WhoTextBox_txt);
            this.tabPage1.Controls.Add(this.ab_ED_ExcComboBox);
            this.tabPage1.Controls.Add(label3);
            this.tabPage1.Controls.Add(this.ab_EDKComboBox);
            this.tabPage1.Controls.Add(label1);
            this.tabPage1.Controls.Add(ab_EDSLabel);
            this.tabPage1.Controls.Add(ab_EDNLabel);
            this.tabPage1.Controls.Add(ab_ED_DateLabel);
            this.tabPage1.Controls.Add(ab_ED_WhoLabel);
            this.tabPage1.Controls.Add(ab_ED_ExcLabel);
            this.tabPage1.Controls.Add(ab_PrivLabel);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(label18);
            this.tabPage1.Controls.Add(label21);
            this.tabPage1.Controls.Add(label12);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.tabPage1.ForeColor = System.Drawing.Color.White;
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(758, 260);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Данные для поступления";
            // 
            // btn_Spec
            // 
            this.btn_Spec.BackColor = System.Drawing.Color.White;
            this.btn_Spec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Spec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Spec.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic);
            this.btn_Spec.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.btn_Spec.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.edit;
            this.btn_Spec.Location = new System.Drawing.Point(715, 195);
            this.btn_Spec.Name = "btn_Spec";
            this.btn_Spec.Size = new System.Drawing.Size(16, 16);
            this.btn_Spec.TabIndex = 111;
            this.btn_Spec.TabStop = false;
            this.btn_Spec.UseVisualStyleBackColor = false;
            this.btn_Spec.Click += new System.EventHandler(this.btn_Spec_Click);
            // 
            // IDLabel
            // 
            this.IDLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.IDLabel.AutoSize = true;
            this.IDLabel.BackColor = System.Drawing.Color.Transparent;
            this.IDLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.IDLabel.ForeColor = System.Drawing.Color.White;
            this.IDLabel.Location = new System.Drawing.Point(216, 17);
            this.IDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.IDLabel.Name = "IDLabel";
            this.IDLabel.Size = new System.Drawing.Size(154, 19);
            this.IDLabel.TabIndex = 10;
            this.IDLabel.Text = "Код абитуриента:";
            // 
            // ab_EBComboBox
            // 
            this.ab_EBComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_EB", true));
            this.ab_EBComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_EBComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_EBComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_EBComboBox.FormattingEnabled = true;
            this.ab_EBComboBox.Items.AddRange(new object[] {
            "",
            "Бюджет",
            "Контракт"});
            this.ab_EBComboBox.Location = new System.Drawing.Point(576, 295);
            this.ab_EBComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_EBComboBox.Name = "ab_EBComboBox";
            this.ab_EBComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_EBComboBox.TabIndex = 16;
            // 
            // viewFormBindingSource
            // 
            this.viewFormBindingSource.DataMember = "View_Form";
            this.viewFormBindingSource.DataSource = this.bD_AbiturientDataSet;
            // 
            // bD_AbiturientDataSet
            // 
            this.bD_AbiturientDataSet.DataSetName = "BD_AbiturientDataSet";
            this.bD_AbiturientDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ab_EFComboBox
            // 
            this.ab_EFComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_EF", true));
            this.ab_EFComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_EFComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_EFComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_EFComboBox.FormattingEnabled = true;
            this.ab_EFComboBox.IntegralHeight = false;
            this.ab_EFComboBox.Items.AddRange(new object[] {
            "",
            "Дневная",
            "Заочная"});
            this.ab_EFComboBox.Location = new System.Drawing.Point(576, 260);
            this.ab_EFComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_EFComboBox.Name = "ab_EFComboBox";
            this.ab_EFComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_EFComboBox.TabIndex = 15;
            // 
            // PrivTextBox_txt
            // 
            this.PrivTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_Priv", true));
            this.PrivTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.PrivTextBox_txt.Location = new System.Drawing.Point(194, 295);
            this.PrivTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.PrivTextBox_txt.MaxLength = 50;
            this.PrivTextBox_txt.Name = "PrivTextBox_txt";
            this.PrivTextBox_txt.ShortcutsEnabled = false;
            this.PrivTextBox_txt.Size = new System.Drawing.Size(176, 27);
            this.PrivTextBox_txt.TabIndex = 8;
            this.PrivTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.PrivTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.PrivTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // IDTextBox_txt
            // 
            this.IDTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_ID", true));
            this.IDTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.IDTextBox_txt.Location = new System.Drawing.Point(374, 13);
            this.IDTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.IDTextBox_txt.MaxLength = 15;
            this.IDTextBox_txt.Name = "IDTextBox_txt";
            this.IDTextBox_txt.ShortcutsEnabled = false;
            this.IDTextBox_txt.Size = new System.Drawing.Size(150, 27);
            this.IDTextBox_txt.TabIndex = 0;
            this.IDTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.IDTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.IDTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ab_Spec1ComboBox
            // 
            this.ab_Spec1ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_Spec1", true));
            this.ab_Spec1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_Spec1ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_Spec1ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_Spec1ComboBox.FormattingEnabled = true;
            this.ab_Spec1ComboBox.IntegralHeight = false;
            this.ab_Spec1ComboBox.Location = new System.Drawing.Point(576, 155);
            this.ab_Spec1ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_Spec1ComboBox.MaxDropDownItems = 4;
            this.ab_Spec1ComboBox.Name = "ab_Spec1ComboBox";
            this.ab_Spec1ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_Spec1ComboBox.Sorted = true;
            this.ab_Spec1ComboBox.TabIndex = 12;
            // 
            // ab_Spec2ComboBox
            // 
            this.ab_Spec2ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_Spec2", true));
            this.ab_Spec2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_Spec2ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_Spec2ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_Spec2ComboBox.FormattingEnabled = true;
            this.ab_Spec2ComboBox.IntegralHeight = false;
            this.ab_Spec2ComboBox.Location = new System.Drawing.Point(576, 190);
            this.ab_Spec2ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_Spec2ComboBox.MaxDropDownItems = 4;
            this.ab_Spec2ComboBox.Name = "ab_Spec2ComboBox";
            this.ab_Spec2ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_Spec2ComboBox.Sorted = true;
            this.ab_Spec2ComboBox.TabIndex = 13;
            // 
            // ab_Spec3ComboBox
            // 
            this.ab_Spec3ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_Spec3", true));
            this.ab_Spec3ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_Spec3ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_Spec3ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_Spec3ComboBox.FormattingEnabled = true;
            this.ab_Spec3ComboBox.IntegralHeight = false;
            this.ab_Spec3ComboBox.Location = new System.Drawing.Point(576, 225);
            this.ab_Spec3ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_Spec3ComboBox.MaxDropDownItems = 4;
            this.ab_Spec3ComboBox.Name = "ab_Spec3ComboBox";
            this.ab_Spec3ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_Spec3ComboBox.Sorted = true;
            this.ab_Spec3ComboBox.TabIndex = 14;
            // 
            // ab_MedCert1ComboBox
            // 
            this.ab_MedCert1ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_MedCert1", true));
            this.ab_MedCert1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_MedCert1ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_MedCert1ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_MedCert1ComboBox.FormattingEnabled = true;
            this.ab_MedCert1ComboBox.IntegralHeight = false;
            this.ab_MedCert1ComboBox.Items.AddRange(new object[] {
            "",
            "Есть",
            "Нет"});
            this.ab_MedCert1ComboBox.Location = new System.Drawing.Point(576, 50);
            this.ab_MedCert1ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_MedCert1ComboBox.Name = "ab_MedCert1ComboBox";
            this.ab_MedCert1ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_MedCert1ComboBox.TabIndex = 9;
            // 
            // ab_MedCert2ComboBox
            // 
            this.ab_MedCert2ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_MedCert2", true));
            this.ab_MedCert2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_MedCert2ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_MedCert2ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_MedCert2ComboBox.FormattingEnabled = true;
            this.ab_MedCert2ComboBox.IntegralHeight = false;
            this.ab_MedCert2ComboBox.Items.AddRange(new object[] {
            "",
            "Есть",
            "Нет"});
            this.ab_MedCert2ComboBox.Location = new System.Drawing.Point(576, 85);
            this.ab_MedCert2ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_MedCert2ComboBox.Name = "ab_MedCert2ComboBox";
            this.ab_MedCert2ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_MedCert2ComboBox.TabIndex = 10;
            // 
            // ab_MedCert3ComboBox
            // 
            this.ab_MedCert3ComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_MedCert3", true));
            this.ab_MedCert3ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_MedCert3ComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_MedCert3ComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_MedCert3ComboBox.FormattingEnabled = true;
            this.ab_MedCert3ComboBox.IntegralHeight = false;
            this.ab_MedCert3ComboBox.Items.AddRange(new object[] {
            "",
            "Есть",
            "Нет"});
            this.ab_MedCert3ComboBox.Location = new System.Drawing.Point(576, 120);
            this.ab_MedCert3ComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_MedCert3ComboBox.Name = "ab_MedCert3ComboBox";
            this.ab_MedCert3ComboBox.Size = new System.Drawing.Size(130, 27);
            this.ab_MedCert3ComboBox.TabIndex = 11;
            // 
            // ab_ForLangComboBox
            // 
            this.ab_ForLangComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_ForLang", true));
            this.ab_ForLangComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_ForLangComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_ForLangComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_ForLangComboBox.FormattingEnabled = true;
            this.ab_ForLangComboBox.IntegralHeight = false;
            this.ab_ForLangComboBox.Items.AddRange(new object[] {
            "",
            "Английский",
            "Немецкий",
            "Французский"});
            this.ab_ForLangComboBox.Location = new System.Drawing.Point(194, 260);
            this.ab_ForLangComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_ForLangComboBox.Name = "ab_ForLangComboBox";
            this.ab_ForLangComboBox.Size = new System.Drawing.Size(176, 27);
            this.ab_ForLangComboBox.TabIndex = 7;
            // 
            // ab_EDSTextBox_txt
            // 
            this.ab_EDSTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_EDS", true));
            this.ab_EDSTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_EDSTextBox_txt.Location = new System.Drawing.Point(194, 85);
            this.ab_EDSTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.ab_EDSTextBox_txt.MaxLength = 5;
            this.ab_EDSTextBox_txt.Name = "ab_EDSTextBox_txt";
            this.ab_EDSTextBox_txt.ShortcutsEnabled = false;
            this.ab_EDSTextBox_txt.Size = new System.Drawing.Size(176, 27);
            this.ab_EDSTextBox_txt.TabIndex = 2;
            this.ab_EDSTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.ab_EDSTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ab_EDSTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ab_EDNTextBox_num
            // 
            this.ab_EDNTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_EDN", true));
            this.ab_EDNTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_EDNTextBox_num.Location = new System.Drawing.Point(194, 120);
            this.ab_EDNTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.ab_EDNTextBox_num.MaxLength = 15;
            this.ab_EDNTextBox_num.Name = "ab_EDNTextBox_num";
            this.ab_EDNTextBox_num.ShortcutsEnabled = false;
            this.ab_EDNTextBox_num.Size = new System.Drawing.Size(176, 27);
            this.ab_EDNTextBox_num.TabIndex = 3;
            this.ab_EDNTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ab_EDNTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ab_ED_DateDateTimePicker
            // 
            this.ab_ED_DateDateTimePicker.CalendarFont = new System.Drawing.Font("Monotype Corsiva", 14F, System.Drawing.FontStyle.Italic);
            this.ab_ED_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.viewFormBindingSource, "Ab_ED_Date", true));
            this.ab_ED_DateDateTimePicker.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_ED_DateDateTimePicker.Location = new System.Drawing.Point(194, 155);
            this.ab_ED_DateDateTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.ab_ED_DateDateTimePicker.Name = "ab_ED_DateDateTimePicker";
            this.ab_ED_DateDateTimePicker.Size = new System.Drawing.Size(176, 27);
            this.ab_ED_DateDateTimePicker.TabIndex = 4;
            // 
            // ED_WhoTextBox_txt
            // 
            this.ED_WhoTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_ED_Who", true));
            this.ED_WhoTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ED_WhoTextBox_txt.Location = new System.Drawing.Point(194, 190);
            this.ED_WhoTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.ED_WhoTextBox_txt.MaxLength = 100;
            this.ED_WhoTextBox_txt.Name = "ED_WhoTextBox_txt";
            this.ED_WhoTextBox_txt.ShortcutsEnabled = false;
            this.ED_WhoTextBox_txt.Size = new System.Drawing.Size(176, 27);
            this.ED_WhoTextBox_txt.TabIndex = 5;
            this.ED_WhoTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.ED_WhoTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ED_WhoTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ab_ED_ExcComboBox
            // 
            this.ab_ED_ExcComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_ED_Exc", true));
            this.ab_ED_ExcComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_ED_ExcComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_ED_ExcComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_ED_ExcComboBox.FormattingEnabled = true;
            this.ab_ED_ExcComboBox.IntegralHeight = false;
            this.ab_ED_ExcComboBox.Items.AddRange(new object[] {
            "",
            "Да",
            "Нет"});
            this.ab_ED_ExcComboBox.Location = new System.Drawing.Point(194, 225);
            this.ab_ED_ExcComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_ED_ExcComboBox.Name = "ab_ED_ExcComboBox";
            this.ab_ED_ExcComboBox.Size = new System.Drawing.Size(176, 27);
            this.ab_ED_ExcComboBox.TabIndex = 6;
            // 
            // ab_EDKComboBox
            // 
            this.ab_EDKComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ab_EDK", true));
            this.ab_EDKComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ab_EDKComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ab_EDKComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ab_EDKComboBox.FormattingEnabled = true;
            this.ab_EDKComboBox.IntegralHeight = false;
            this.ab_EDKComboBox.Items.AddRange(new object[] {
            "",
            "Аттестат",
            "Диплом",
            "Свидетельство"});
            this.ab_EDKComboBox.Location = new System.Drawing.Point(194, 50);
            this.ab_EDKComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.ab_EDKComboBox.Name = "ab_EDKComboBox";
            this.ab_EDKComboBox.Size = new System.Drawing.Size(176, 27);
            this.ab_EDKComboBox.Sorted = true;
            this.ab_EDKComboBox.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(722, 211);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(2, 28);
            this.label20.TabIndex = 113;
            // 
            // label19
            // 
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(722, 167);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(2, 28);
            this.label19.TabIndex = 113;
            // 
            // tabControl
            // 
            this.tabControl.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.tabControl.HotTrack = true;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(766, 292);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage2.Controls.Add(this.pers_PhoneMaskedTextBox);
            this.tabPage2.Controls.Add(this.pers_DKComboBox);
            this.tabPage2.Controls.Add(this.pers_SexComboBox);
            this.tabPage2.Controls.Add(ab_EDKLabel);
            this.tabPage2.Controls.Add(pers_LastnameLabel);
            this.tabPage2.Controls.Add(this.pers_LastnameTextBox_txt);
            this.tabPage2.Controls.Add(pers_FirstnameLabel);
            this.tabPage2.Controls.Add(this.pers_FirstnameTextBox_txt);
            this.tabPage2.Controls.Add(pers_PatronymicLabel);
            this.tabPage2.Controls.Add(this.pers_PatronymicTextBox_txt);
            this.tabPage2.Controls.Add(pers_SexLabel);
            this.tabPage2.Controls.Add(pers_BirthdayLabel);
            this.tabPage2.Controls.Add(this.pers_BirthdayDateTimePicker);
            this.tabPage2.Controls.Add(pers_PhoneLabel);
            this.tabPage2.Controls.Add(pers_DKLabel);
            this.tabPage2.Controls.Add(pers_DSLabel);
            this.tabPage2.Controls.Add(this.pers_DSTextBox_txt);
            this.tabPage2.Controls.Add(pers_DNLabel);
            this.tabPage2.Controls.Add(this.pers_DNTextBox_num);
            this.tabPage2.Controls.Add(pers_DDateLabel);
            this.tabPage2.Controls.Add(this.pers_DDateDateTimePicker);
            this.tabPage2.Controls.Add(pers_DWhoLabel);
            this.tabPage2.Controls.Add(this.DWhoTextBox_txt);
            this.tabPage2.Controls.Add(pers_INNLabel);
            this.tabPage2.Controls.Add(this.pers_INNTextBox_num);
            this.tabPage2.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.tabPage2.ForeColor = System.Drawing.Color.Gold;
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(758, 260);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Личные данные";
            // 
            // pers_PhoneMaskedTextBox
            // 
            this.pers_PhoneMaskedTextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_PhoneMaskedTextBox.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.pers_PhoneMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Phone", true));
            this.pers_PhoneMaskedTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_PhoneMaskedTextBox.Location = new System.Drawing.Point(162, 199);
            this.pers_PhoneMaskedTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.pers_PhoneMaskedTextBox.Mask = "+38 (000) 000-00-00";
            this.pers_PhoneMaskedTextBox.Name = "pers_PhoneMaskedTextBox";
            this.pers_PhoneMaskedTextBox.RejectInputOnFirstFailure = true;
            this.pers_PhoneMaskedTextBox.ShortcutsEnabled = false;
            this.pers_PhoneMaskedTextBox.Size = new System.Drawing.Size(190, 27);
            this.pers_PhoneMaskedTextBox.TabIndex = 5;
            this.pers_PhoneMaskedTextBox.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            // 
            // pers_DKComboBox
            // 
            this.pers_DKComboBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_DKComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_DK", true));
            this.pers_DKComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pers_DKComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pers_DKComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_DKComboBox.FormattingEnabled = true;
            this.pers_DKComboBox.IntegralHeight = false;
            this.pers_DKComboBox.Items.AddRange(new object[] {
            "",
            "Паспорт",
            "Свидетельство"});
            this.pers_DKComboBox.Location = new System.Drawing.Point(533, 34);
            this.pers_DKComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.pers_DKComboBox.Name = "pers_DKComboBox";
            this.pers_DKComboBox.Size = new System.Drawing.Size(190, 27);
            this.pers_DKComboBox.TabIndex = 6;
            // 
            // pers_SexComboBox
            // 
            this.pers_SexComboBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_SexComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Sex", true));
            this.pers_SexComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pers_SexComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pers_SexComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_SexComboBox.FormattingEnabled = true;
            this.pers_SexComboBox.IntegralHeight = false;
            this.pers_SexComboBox.Items.AddRange(new object[] {
            "",
            "Мужской",
            "Женский"});
            this.pers_SexComboBox.Location = new System.Drawing.Point(162, 133);
            this.pers_SexComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.pers_SexComboBox.Name = "pers_SexComboBox";
            this.pers_SexComboBox.Size = new System.Drawing.Size(190, 27);
            this.pers_SexComboBox.TabIndex = 3;
            // 
            // pers_LastnameTextBox_txt
            // 
            this.pers_LastnameTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_LastnameTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Lastname", true));
            this.pers_LastnameTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_LastnameTextBox_txt.Location = new System.Drawing.Point(162, 34);
            this.pers_LastnameTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.pers_LastnameTextBox_txt.MaxLength = 50;
            this.pers_LastnameTextBox_txt.Name = "pers_LastnameTextBox_txt";
            this.pers_LastnameTextBox_txt.ShortcutsEnabled = false;
            this.pers_LastnameTextBox_txt.Size = new System.Drawing.Size(190, 27);
            this.pers_LastnameTextBox_txt.TabIndex = 0;
            this.pers_LastnameTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.pers_LastnameTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_LastnameTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_FirstnameTextBox_txt
            // 
            this.pers_FirstnameTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_FirstnameTextBox_txt.AutoCompleteCustomSource.AddRange(new string[] {
            "Аpтуp",
            "Абакум",
            "Абрам",
            "Абросим",
            "Аввакум",
            "Август",
            "Августа",
            "Августин",
            "Августина",
            "Авдей",
            "Авдий",
            "Авдотья",
            "Авель",
            "Авенир",
            "Аверий",
            "Аверкий",
            "Аверьян",
            "Авигея",
            "Авксентий",
            "Авраам",
            "Авраамий",
            "Аврам",
            "Аврамий",
            "Аврелиан",
            "Аврелия",
            "Аврор",
            "Аврора",
            "Аврорий",
            "Автоном",
            "Агап",
            "Агапий",
            "Агапит",
            "Агапия",
            "Агата",
            "Агафон",
            "Агафья",
            "Аггей",
            "Агей",
            "Агладия",
            "Аглая",
            "Агнеса",
            "Агнесса",
            "Агния",
            "Аграфена",
            "Агрефена",
            "Агриппина",
            "Ада",
            "Адам",
            "Аделаида",
            "Аделина",
            "Аделия",
            "Адель",
            "Адельфина",
            "Адина",
            "Адия",
            "Адольф",
            "Адонис",
            "Адриан",
            "Адриана",
            "Аза",
            "Азалия",
            "Азар",
            "Азарий",
            "Азиза",
            "Аида",
            "Айлин",
            "Айседора",
            "Акакий",
            "Аким",
            "Акиндин",
            "Акинф",
            "Акинфий",
            "Аксён",
            "Аксентий",
            "Аксинья",
            "Акулина",
            "Алeкcaндp",
            "Ала",
            "Алевтин",
            "Алевтина",
            "Александр",
            "Александра",
            "Александрина",
            "Алексей",
            "Алексий",
            "Алена",
            "Алёна",
            "Алеся",
            "Алика",
            "Алина",
            "Алира",
            "Алиса",
            "Алия",
            "Алла",
            "Альберт",
            "Альберта",
            "Альбертина",
            "Альбин",
            "Альбина",
            "Альвиан",
            "Альвина",
            "Альжбета",
            "Альтаир",
            "Альфреа",
            "Альфред",
            "Амалия",
            "Амвросий",
            "Амелия",
            "Амина",
            "Амира",
            "Амос",
            "Амфилохий",
            "Ананий",
            "Анастасий",
            "Анастасия",
            "Анатолий",
            "Ангелина",
            "Ангелия",
            "Андрей",
            "Андриан",
            "Андриана",
            "Андрон",
            "Андроний",
            "Андроник",
            "Анжела",
            "Анжелика",
            "Анжиолетта",
            "Аникей",
            "Аникий",
            "Аникита",
            "Анис",
            "Анисий",
            "Анисим",
            "Анисья",
            "Анита",
            "Анна",
            "Антиох",
            "Антип",
            "Антипа",
            "Антипий",
            "Антон",
            "Антонида",
            "Антоний",
            "Антонин",
            "Антонина",
            "Антроп",
            "Антропий",
            "Антуан",
            "Ануфрий",
            "Анфиса",
            "Анэля",
            "Аполлинарий",
            "Аполлинария",
            "Аполлон",
            "Аполлос",
            "Апраксия",
            "Аргент",
            "Ардалион",
            "Ардальон",
            "Ареф",
            "Арефий",
            "Ариадна",
            "Арий",
            "Арина",
            "Аристарх",
            "Аристид",
            "Аркадий",
            "Аркадия",
            "Арнольд",
            "Арон",
            "Арсен",
            "Арсений",
            "Арсентий",
            "Арсиана",
            "Артамон",
            "Артем",
            "Артём",
            "Артемида",
            "Артемий",
            "Артемия",
            "Артур",
            "Архелия",
            "Архип",
            "Арьяна",
            "Асаф",
            "Асафий",
            "Асель",
            "Асида",
            "Аскольд",
            "Астра",
            "Астрид",
            "Ася",
            "Атеист",
            "Аурелия",
            "Афанасий",
            "Афанасия",
            "Афиноген",
            "Африкан",
            "Афродита",
            "Афсылу",
            "Аэлита",
            "Аэлла",
            "Аюна",
            "Бажен",
            "Бажена",
            "Беата",
            "Беатриса",
            "Белла",
            "Беллатриса",
            "Бенедикт",
            "Береслава",
            "Берта",
            "Бета",
            "Биргит",
            "Богдан",
            "Богдана",
            "Боеслав",
            "Божена",
            "Болеслав",
            "Болеслава",
            "Бонифат",
            "Бонифатий",
            "Бонифаций",
            "Боримир",
            "Борис",
            "Борислав",
            "Борислава",
            "Боян",
            "Бриджет",
            "Бриллиант",
            "Бронислав",
            "Бронислава",
            "Бронслава",
            "Будимир",
            "Булат",
            "Вавила",
            "Вадим",
            "Валентин",
            "Валентина",
            "Валериан",
            "Валерий",
            "Валерия",
            "Валерьян",
            "Вальдемар",
            "Вальтер",
            "Ванда",
            "Ванесса",
            "Варвара",
            "Варлаам",
            "Варлам",
            "Варламий",
            "Варнава",
            "Варсоноф",
            "Варсонофий",
            "Варфоломей",
            "Василий",
            "Василина",
            "Василиса",
            "Василиск",
            "Василько",
            "Васса",
            "Вассиан",
            "Вацлава",
            "Вевея",
            "Велизар",
            "Велимир",
            "Велимира",
            "Велислав",
            "Велислава",
            "Велор",
            "Велорий",
            "Велория",
            "Венедикт",
            "Венера",
            "Вениамин",
            "Венцеслав",
            "Веньямин",
            "Вера",
            "Вереника",
            "Верона",
            "Вероника",
            "Версавия",
            "Веселина",
            "Весняна",
            "Веста",
            "Ветта",
            "Вивиана",
            "Вида",
            "Видана",
            "Викентий",
            "Виктор",
            "Викторий",
            "Викторин",
            "Викторина",
            "Виктория",
            "Викул",
            "Викула",
            "Вилен",
            "Вилена",
            "Вилора",
            "Вильгельм",
            "Вильгельмина",
            "Винетта",
            "Виола",
            "Виоланта",
            "Виолетта",
            "Виргиния",
            "Виринея",
            "Виссарион",
            "Вита",
            "Виталий",
            "Виталина",
            "Виталия",
            "Витольд",
            "Влада",
            "Владилен",
            "Владилена",
            "Владимир",
            "Владимира",
            "Владислав",
            "Владислава",
            "Владлен",
            "Владлена",
            "Влас",
            "Власий",
            "Власта",
            "Властилина",
            "Воислав",
            "Волемир",
            "Володар",
            "Вольдемар",
            "Вольмир",
            "Вонифат",
            "Вонифатий",
            "Всеволод",
            "Всемил",
            "Всеслав",
            "Всеслава",
            "Вукол",
            "Вышеслав",
            "Вячеслав",
            "Габи",
            "Габриэлла",
            "Гавриил",
            "Гаврил",
            "Гаврила",
            "Гаврило",
            "Гайя",
            "Галактион",
            "Гали",
            "Галина",
            "Гамлет",
            "Ганна",
            "Гарри",
            "Гаррий",
            "Гаяна",
            "Гаянэ",
            "Гвинет",
            "Гедеон",
            "Гелана",
            "Геласий",
            "Гелена",
            "Гелиан",
            "Гелианна",
            "Гелий",
            "Гелия",
            "Гелла",
            "Гений",
            "Геннадий",
            "Генриетта",
            "Генрих",
            "Георгий",
            "Георгина",
            "Гера",
            "Герасим",
            "Герда",
            "Герман",
            "Германн",
            "Гермоген",
            "Геронтий",
            "Гертруд",
            "Гертруда",
            "Гиацинт",
            "Глафира",
            "Глеб",
            "Гликерия",
            "Глория",
            "Голуба",
            "Гораций",
            "Горгоний",
            "Гордей",
            "Гордий",
            "Горимир",
            "Горислав",
            "Горислава",
            "Гортензия",
            "Гостомысл",
            "Гражина",
            "Гранит",
            "Гремислав",
            "Грета",
            "Григорий",
            "Гурий",
            "Гурьян",
            "Гюльнара",
            "Гюльчатай",
            "Давид",
            "Давыд",
            "Даздраперма",
            "Дайна",
            "Далмат",
            "Дамир",
            "Дан",
            "Дана",
            "Даниил",
            "Данил",
            "Данила",
            "Данило",
            "Даниэла",
            "Дания",
            "Данна",
            "Данута",
            "Дар",
            "Дарёна",
            "Дарина",
            "Дария",
            "Дарья",
            "Дарьяна",
            "Дебора",
            "Декабрий",
            "Дементий",
            "Демид",
            "Демьян",
            "Денис",
            "Денисий",
            "Денисия",
            "Джема",
            "Джеральд",
            "Джиневра",
            "Джозеф",
            "Джон",
            "Джулия",
            "Джульетта",
            "Диана",
            "Дилия",
            "Дильфуза",
            "Димитрий",
            "Дина",
            "Динара",
            "Диния",
            "Диодора",
            "Диомид",
            "Дионис",
            "Дионисий",
            "Дионисия",
            "Диша",
            "Дмитрий",
            "Добрава",
            "Добромысл",
            "Доброслав",
            "Добрыня",
            "Доля",
            "Доминик",
            "Доминика",
            "Домна",
            "Дональт",
            "Донара",
            "Донат",
            "Дора",
            "Доримедонт",
            "Дормедонт",
            "Дормидонт",
            "Доротея",
            "Дорофей",
            "Дорофея",
            "Досифей",
            "Досифея",
            "Дросида",
            "Дэнна",
            "Ева",
            "Евангелина",
            "Евгений",
            "Евгения",
            "Евграф",
            "Евграфий",
            "Евдоким",
            "Евдокия",
            "Евдоксия",
            "Евлавия",
            "Евлалия",
            "Евлампий",
            "Евлампия",
            "Евлогий",
            "Евмен",
            "Евмений",
            "Евника",
            "Евпраксия",
            "Евсей",
            "Евстафий",
            "Евстахий",
            "Евстигней",
            "Евстолия",
            "Евстрат",
            "Евстратий",
            "Евтихий",
            "Евфалия",
            "Евфимий",
            "Евфимия",
            "Евфроксиния",
            "Евфросиния",
            "Егор",
            "Егорий",
            "Екатерина",
            "Елеконида",
            "Елена",
            "Елизавета",
            "Елизар",
            "Еликонида",
            "Елисей",
            "Елистрат",
            "Елпидифор",
            "Емельян",
            "Епистимия",
            "Епифан",
            "Епифаний",
            "Еремей",
            "Ермий",
            "Ермил",
            "Ермила",
            "Ермилий",
            "Ермиония",
            "Ермолай",
            "Ерофей",
            "Еруслан",
            "Есения",
            "Ефим",
            "Ефимий",
            "Ефимия",
            "Ефрем",
            "Ефремий",
            "Ефросиния",
            "Ефросинья",
            "Жаклин",
            "Жанна",
            "Жасмин",
            "Жасмина",
            "Ждан",
            "Ждана",
            "Женевьева",
            "Жозефа",
            "Жозефина",
            "Жюли",
            "Забава",
            "Заира",
            "Залина",
            "Зара",
            "Зарай",
            "Зарбану",
            "Зарбике",
            "Заргиши",
            "Зарема",
            "Зарина",
            "Зарифа",
            "Зарнигар",
            "Зауре",
            "Захар",
            "Захарий",
            "Звенислава",
            "Земфира",
            "Зенон",
            "Зинаида",
            "Зиновий",
            "Зиновия",
            "Злата",
            "Златослава",
            "Зозан",
            "Зорий",
            "Зоряна",
            "Зосим",
            "Зосима",
            "Зоя",
            "Иаким",
            "Иакинф",
            "Ибрагим",
            "Иван",
            "Иванна",
            "Иветта",
            "Ивона",
            "Ивонна",
            "Игнат",
            "Игнатий",
            "Игорь",
            "Ида",
            "Иероним",
            "Изабелла",
            "Измаил",
            "Изольда",
            "Изосим",
            "Изот",
            "Изяслав",
            "Иларион",
            "Илария",
            "Илена",
            "Илзе",
            "Илиана",
            "Илиодор",
            "Илларион",
            "Илона",
            "Илья",
            "Инара",
            "Инга",
            "Индира",
            "Инесса",
            "Инна",
            "Иннокентий",
            "Иоан",
            "Иоанн",
            "Иоанна",
            "Иов",
            "Иола",
            "Иоланта",
            "Иона",
            "Иосафат",
            "Иосиф",
            "Ипат",
            "Ипатий",
            "Ипатия",
            "Ипполит",
            "Ипполита",
            "Ирада",
            "Ираида",
            "Ираклий",
            "Ираклия",
            "Ирена",
            "Ириада",
            "Ирина",
            "Иринарх",
            "Ириней",
            "Ирма",
            "Ирэна",
            "Исаак",
            "Исаакий",
            "Исай",
            "Исак",
            "Исакий",
            "Исидор",
            "Исидора",
            "Искра",
            "Иустин",
            "Ифигения",
            "Июлий",
            "Ия",
            "Казимир",
            "Калерия",
            "Калиса",
            "Каллиник",
            "Каллист",
            "Каллистрат",
            "Камилла",
            "Капитолина",
            "Капитон",
            "Кара",
            "Карина",
            "Карион",
            "Карл",
            "Кармелитта",
            "Каролина",
            "Карп",
            "Карэн",
            "Касьян",
            "Катарина",
            "Катерина",
            "Келен",
            "Ким",
            "Киприан",
            "Кир",
            "Кира",
            "Кириак",
            "Кирик",
            "Кирил",
            "Кирилл",
            "Кирилла",
            "Кирсан",
            "Кирьяк",
            "Клавдий",
            "Клавдия",
            "Клара",
            "Клариса",
            "Клемент",
            "Клементий",
            "Клементина",
            "Клеопатра",
            "Клим",
            "Климент",
            "Климентий",
            "Коариса",
            "Козьма",
            "Колумбий",
            "Кондрат",
            "Кондратий",
            "Конкордия",
            "Конон",
            "Конрад",
            "Константин",
            "Констанция",
            "Корней",
            "Корнелий",
            "Корнелия",
            "Корнил",
            "Корнилий",
            "Кристиан",
            "Кристина",
            "Ксения",
            "Ксенофонт",
            "Кузьма",
            "Куприян",
            "Лapиca",
            "Лавр",
            "Лаврентий",
            "Лада",
            "Ладимир",
            "Лазарь",
            "Лайма",
            "Лали",
            "Лана",
            "Ландыш",
            "Ларион",
            "Лариса",
            "Лаура",
            "Лев",
            "Лейла",
            "Лениана",
            "Ленина",
            "Леокадия",
            "Леон",
            "Леонард",
            "Леонид",
            "Леонида",
            "Леонила",
            "Леонтий",
            "Леонтия",
            "Леопольд",
            "Леся",
            "Лея",
            "Лиана",
            "Лигия",
            "Лидия",
            "Лиза",
            "Лика",
            "Лили",
            "Лилиана",
            "Лилия",
            "Лилу",
            "Лина",
            "Лира",
            "Лия",
            "Логвин",
            "Логгин",
            "Лола",
            "Лолита",
            "Лолла",
            "Лонгин",
            "Лора",
            "Луарсаб",
            "Луиза",
            "Лука",
            "Лукерья",
            "Лукиан",
            "Лукий",
            "Лукина",
            "Лукия",
            "Лукреция",
            "Лукьян",
            "Лунара",
            "Лучезар",
            "Любава",
            "Любим",
            "Любовь",
            "Любомир",
            "Любомира",
            "Любомысл",
            "Людвиг",
            "Людмила",
            "Люксен",
            "Люциан",
            "Ляля",
            "Мавр",
            "Мавра",
            "Маврикий",
            "Мавродий",
            "Магда",
            "Магдалина",
            "Мадлен",
            "Маеслав",
            "Маина",
            "Май",
            "Майслав",
            "Майя",
            "Макар",
            "Макарий",
            "Максим",
            "Максимиан",
            "Максимилиан",
            "Максимильян",
            "Малания",
            "Маланья",
            "Малика",
            "Мальвина",
            "Мальта",
            "Мануил",
            "Марат",
            "Маргарита",
            "Мардарий",
            "Мариан",
            "Марианна",
            "Мариетта",
            "Марика",
            "Марин",
            "Марина",
            "Мариша",
            "Мария",
            "Марк",
            "Маркел",
            "Маркиан",
            "Марлен",
            "Марлена",
            "Марта",
            "Мартимьян",
            "Мартин",
            "Мартина",
            "Мартиниан",
            "Мартирий",
            "Мартын",
            "Мартьян",
            "Марфа",
            "Марья",
            "Марьяна",
            "Матвей",
            "Матильда",
            "Матрена",
            "Матрёна",
            "Матрона",
            "Медея",
            "Мелания",
            "Мелентий",
            "Мелетий",
            "Мелиана",
            "Мелитина",
            "Мелитта",
            "Мериса",
            "Меркул",
            "Меркурий",
            "Мефодий",
            "Мечислав",
            "Мила",
            "Милан",
            "Милана",
            "Милда",
            "Милен",
            "Милена",
            "Милий",
            "Милиса",
            "Милица",
            "Милолика",
            "Милонег",
            "Милослав",
            "Милослава",
            "Мина",
            "Минай",
            "Мир",
            "Мирдза",
            "Мирон",
            "Мирослав",
            "Мирослава",
            "Мирра",
            "Мисаил",
            "Митрофан",
            "Митрофаний",
            "Михаил",
            "Михей",
            "Мишель",
            "Мия",
            "Модест",
            "Моисей",
            "Мокей",
            "Мокий",
            "Моника",
            "Монолит",
            "Мстислав",
            "Мстислава",
            "Муза",
            "Мэлор",
            "Мэлс",
            "Мэри",
            "Нада",
            "Надежда",
            "Надия",
            "Назар",
            "Назарий",
            "Наина",
            "Нана",
            "Нания",
            "Наоми",
            "Наркис",
            "Настасия",
            "Настасья",
            "Наталия",
            "Наталья",
            "Натан",
            "Наум",
            "Нева",
            "Нега",
            "Нелли",
            "Ненила",
            "Неолина",
            "Неон",
            "Неонил",
            "Неонила",
            "Нестер",
            "Нестор",
            "Нефёд",
            "Ника",
            "Никандр",
            "Никанор",
            "Никита",
            "Никифор",
            "Никки",
            "Никодим",
            "Никола",
            "Николай",
            "Николь",
            "Никон",
            "Нил",
            "Нила",
            "Нина",
            "Нинель",
            "Нинна",
            "Нифонт",
            "Новелла",
            "Номи",
            "Нонна",
            "Нора",
            "Норд",
            "Ноябрина",
            "Овидий",
            "Одиссей",
            "Оксана",
            "Октавиан",
            "Октавия",
            "Октябрин",
            "Октябрина",
            "Олег",
            "Олесь",
            "Олеся",
            "Оливия",
            "Олимпиада",
            "Олимпий",
            "Олимпия",
            "Ольга",
            "Онисим",
            "Онуфрий",
            "Орест",
            "Осип",
            "Оскар",
            "Остап",
            "Павел",
            "Павла",
            "Павлин",
            "Павлина",
            "Паисий",
            "Палладий",
            "Памфил",
            "Памфилий",
            "Панкрат",
            "Панкратий",
            "Пантелей",
            "Пантелеймон",
            "Панфил",
            "Парамон",
            "Параскева",
            "Пармен",
            "Пармён",
            "Парфен",
            "Парфён",
            "Парфений",
            "Парфентий",
            "Патрикей",
            "Патрикий",
            "Патрисия",
            "Пафнутий",
            "Пахом",
            "Пахомий",
            "Пелагея",
            "Пенелопа",
            "Пересвет",
            "Перфилий",
            "Петр",
            "Пётр",
            "Пимен",
            "Питирим",
            "Платон",
            "Платонида",
            "Полианна",
            "Поликарп",
            "Поликарпий",
            "Поликсена",
            "Поликсения",
            "Полина",
            "Порфир",
            "Порфирий",
            "Потап",
            "Потапий",
            "Правдина",
            "Прасковья",
            "Пров",
            "Прокл",
            "Прокоп",
            "Прокопий",
            "Прокофий",
            "Протас",
            "Протасий",
            "Прохор",
            "Пульхерия",
            "Рада",
            "Радий",
            "Радик",
            "Радим",
            "Радислав",
            "Радмила",
            "Радован",
            "Радомир",
            "Радослава",
            "Раиса",
            "Ралина",
            "Рамина",
            "Ратибор",
            "Ратмир",
            "Рафаил",
            "Рафаэль",
            "Рафик",
            "Рахиль",
            "Рая",
            "Раялла",
            "Ревекка",
            "Ревмира",
            "Регина",
            "Рем",
            "Рената",
            "Риана",
            "Римма",
            "Рина",
            "Ринат",
            "Ричард",
            "Роберт",
            "Рогнеда",
            "Родион",
            "Роза",
            "Розалина",
            "Розалия",
            "Розана",
            "Роксалана",
            "Роксана",
            "Роман",
            "Романа",
            "Ростислав",
            "Ростислава",
            "Рубен",
            "Рувим",
            "Рудольф",
            "Руслан",
            "Руслана",
            "Рустам",
            "Руфина",
            "Руфь",
            "Рюрик",
            "Сабина",
            "Сабрина",
            "Сава",
            "Савва",
            "Савватей",
            "Савватий",
            "Савёл",
            "Савелий",
            "Саида",
            "Саломея",
            "Салтанат",
            "Самойла",
            "Самсон",
            "Самсоний",
            "Самуил",
            "Санда",
            "Сандра",
            "Сания",
            "Санта",
            "Сара",
            "Сарра",
            "Сафина",
            "Свет",
            "Светлан",
            "Светлана",
            "Светозар",
            "Светослав",
            "Свирид",
            "Святогор",
            "Святополк",
            "Святослав",
            "Святослава",
            "Себастьян",
            "Севастьян",
            "Север",
            "Севериан",
            "Северин",
            "Северина",
            "Северьян",
            "Северян",
            "Секлетея",
            "Селена",
            "Селиван",
            "Селивёрст",
            "Селифан",
            "Семен",
            "Семён",
            "Серапион",
            "Серафим",
            "Серафима",
            "Сергей",
            "Сигизмунд",
            "Сидор",
            "Сила",
            "Силан",
            "Силантий",
            "Силика",
            "Силуян",
            "Сильва",
            "Сильван",
            "Сильвестр",
            "Сильвия",
            "Сима",
            "Симеон",
            "Симон",
            "Симона",
            "Синклитикия",
            "Снежана",
            "Созон",
            "Созонт",
            "Созонтий",
            "Сократ",
            "Соломон",
            "Соломонида",
            "Соломония",
            "Сосипатр",
            "София",
            "Софон",
            "Софоний",
            "Софрон",
            "Софроний",
            "Софья",
            "Спартак",
            "Спиридон",
            "Спиридоний",
            "Сталий",
            "Сталь",
            "Станислав",
            "Станислава",
            "Стахий",
            "Стелла",
            "Степан",
            "Степанида",
            "Стефан",
            "Стефанида",
            "Стефания",
            "Стратоник",
            "Сусанна",
            "Суссана",
            "Сысой",
            "Сюзанна",
            "Таира",
            "Таисия",
            "Таисья",
            "Тала",
            "Тальяна",
            "Тамара",
            "Тамила",
            "Тамирлан",
            "Тарас",
            "Татьяна",
            "Твердислав",
            "Творимир",
            "Теймураз",
            "Текуса",
            "Теодор",
            "Тереза",
            "Терезия",
            "Терентий",
            "Тертий",
            "Тигран",
            "Тимофей",
            "Тимур",
            "Тит",
            "Тихон",
            "Томила",
            "Тракторина",
            "Триана",
            "Тристан",
            "Трифон",
            "Трофим",
            "Уар",
            "Увар",
            "Улеб",
            "Улита",
            "Ульян",
            "Ульяна",
            "Устин",
            "Устина",
            "Устиния",
            "Устинья",
            "Фабиан",
            "Фаддей",
            "Фадей",
            "Фаиза",
            "Фаина",
            "Фалалей",
            "Фанни",
            "Фаня",
            "Фарид",
            "Фатьян",
            "Фая",
            "Февралин",
            "Феврония",
            "Февронья",
            "Федор",
            "Фёдор",
            "Федора",
            "Федос",
            "Федосей",
            "Федосий",
            "Федосия",
            "Федосья",
            "Федот",
            "Федотий",
            "Федотия",
            "Федотья",
            "Федул",
            "Фекла",
            "Фёкла",
            "Феликс",
            "Фелица",
            "Фелицата",
            "Фелиция",
            "Феогност",
            "Феодора",
            "Феодосий",
            "Феодосия",
            "Феодотия",
            "Феоктист",
            "Феоктиста",
            "Феона",
            "Феофан",
            "Феофания",
            "Феофил",
            "Феофила",
            "Феофилакт",
            "Ферапонт",
            "Фетиния",
            "Фетинья",
            "Филадельфия",
            "Филарет",
            "Филат",
            "Филимон",
            "Филип",
            "Филипий",
            "Филипп",
            "Филофей",
            "Фирс",
            "Фия",
            "Флавия",
            "Флегонт",
            "Флёна",
            "Флор",
            "Флора",
            "Флорентий",
            "Флорентин",
            "Флорентина",
            "Флоренц",
            "Флоренция",
            "Флориан",
            "Флорин",
            "Флюра",
            "Фока",
            "Фома",
            "Фортунат",
            "Фотий",
            "Фотина",
            "Франсуаза",
            "Фрида",
            "Фридерика",
            "Фридрих",
            "Фрол",
            "Фрося",
            "Хаврония",
            "Хана",
            "Харита",
            "Харитина",
            "Харитон",
            "Харитоний",
            "Харлам",
            "Харламп",
            "Харлампий",
            "Хатуна",
            "Хелена",
            "Хельга",
            "Хильда",
            "Хиония",
            "Хлоя",
            "Храбр",
            "Хрисанф",
            "Христина",
            "Христоф",
            "Христофор",
            "Цветана",
            "Цецера",
            "Цецилия",
            "Циала",
            "Чеслава",
            "Шарлотта",
            "Шахмира",
            "Эвелина",
            "Эдвард",
            "Эдгар",
            "Эдда",
            "Эдилия",
            "Эдит",
            "Эдита",
            "Эдуард",
            "Эдуарда",
            "Эжени",
            "Электрон",
            "Элеонора",
            "Элиза",
            "Элизабет",
            "Элина",
            "Элла",
            "Эллада",
            "Эллина",
            "Элоиза",
            "Элона",
            "Эльбрус",
            "Эльвина",
            "Эльвира",
            "Эльга",
            "Эльдар",
            "Эльза",
            "Эльмира",
            "Эмбер",
            "Эмилий",
            "Эмилия",
            "Эмиль",
            "Эмма",
            "Эммануил",
            "Энергий",
            "Эра",
            "Эразм",
            "Эраст",
            "Эрида",
            "Эрик",
            "Эрика",
            "Эрна",
            "Эрнест",
            "Эрнестина",
            "Эрнст",
            "Эстелла",
            "Эсфирь",
            "Эшли",
            "Ювеналий",
            "Юджин",
            "Юдифь",
            "Юзефа",
            "Юланта",
            "Юлиан",
            "Юлиана",
            "Юлиания",
            "Юлий",
            "Юлия",
            "Юна",
            "Юнона",
            "Юрий",
            "Юстин",
            "Юстина",
            "Юфеза",
            "Юхим",
            "Ядвига",
            "Яким",
            "Яков",
            "Якуб",
            "Якун",
            "Ян",
            "Яна",
            "Яника",
            "Янина",
            "Янита",
            "Януарий",
            "Янус",
            "Яромир",
            "Яромира",
            "Ярополк",
            "Ярослав",
            "Ярослава",
            "Ясень",
            "Ясмина"});
            this.pers_FirstnameTextBox_txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pers_FirstnameTextBox_txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pers_FirstnameTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Firstname", true));
            this.pers_FirstnameTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_FirstnameTextBox_txt.Location = new System.Drawing.Point(162, 67);
            this.pers_FirstnameTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.pers_FirstnameTextBox_txt.MaxLength = 50;
            this.pers_FirstnameTextBox_txt.Name = "pers_FirstnameTextBox_txt";
            this.pers_FirstnameTextBox_txt.ShortcutsEnabled = false;
            this.pers_FirstnameTextBox_txt.Size = new System.Drawing.Size(190, 27);
            this.pers_FirstnameTextBox_txt.TabIndex = 1;
            this.pers_FirstnameTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.pers_FirstnameTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_FirstnameTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_PatronymicTextBox_txt
            // 
            this.pers_PatronymicTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_PatronymicTextBox_txt.AutoCompleteCustomSource.AddRange(new string[] {
            "Абакумович",
            "Абакумовна",
            "Абрамович",
            "Абрамовна",
            "Абросимович",
            "Абросимовна",
            "Аввакумович",
            "Аввакумовна",
            "Августович",
            "Августовна",
            "Авдеевич",
            "Авдеевна",
            "Авдиевич",
            "Авдиевна",
            "Авелевич",
            "Авелевна",
            "Авенирович",
            "Авенировна",
            "Авериевич",
            "Авериевна",
            "Аверкиевич",
            "Аверкиевна",
            "Аверьянович",
            "Аверьяновна",
            "Авксентиевич",
            "Авксентиевна",
            "Авксентьевич",
            "Авксентьевна",
            "Авраамиевич",
            "Авраамиевна",
            "Авраамович",
            "Авраамовна",
            "Авраамьевич",
            "Авраамьевна",
            "Аврамиевич",
            "Аврамиевна",
            "Аврамович",
            "Аврамовна",
            "Аврамьевич",
            "Аврамьевна",
            "Аврелианович",
            "Аврелиановна",
            "Автономович",
            "Автономовна",
            "Агапиевич",
            "Агапиевна",
            "Агапитович",
            "Агапитовна",
            "Агапович",
            "Агаповна",
            "Агапьевич",
            "Агапьевна",
            "Агафонович",
            "Агафоновна",
            "Аггеевич",
            "Аггеевна",
            "Адамович",
            "Адрианович",
            "Адриановна",
            "Азариевич",
            "Азариевна",
            "Азарович",
            "Азаровна",
            "Азарьевич",
            "Азарьевна",
            "Акакиевич",
            "Акакиевна",
            "Акимович",
            "Акимовна",
            "Акиндинович",
            "Акиндиновна",
            "Акинфиевич",
            "Акинфиевна",
            "Акинфович",
            "Акинфовна",
            "Акинфьевич",
            "Акинфьевна",
            "Аксёнович",
            "Аксёновна",
            "Аксентиевич",
            "Аксентиевна",
            "Аксентьевич",
            "Аксентьевна",
            "Александрович",
            "Александровна",
            "Алексеевич",
            "Алексеевна",
            "Алексиевич",
            "Алексиевна",
            "Альбертович",
            "Альбертовна",
            "Альвианович",
            "Альвиановна",
            "Альфредович",
            "Альфредовна",
            "Амвросиевич",
            "Амвросиевна",
            "Амвросьевич",
            "Амвросьевна",
            "Амосович",
            "Амосовна",
            "Амфилохиевич",
            "Амфилохиевна",
            "Амфилохьевич",
            "Амфилохьевна",
            "Ананиевич",
            "Ананиевна",
            "Ананьевич",
            "Ананьевна",
            "Анастасиевич",
            "Анастасиевна",
            "Анастасьевич",
            "Анастасьевна",
            "Анатолиевич",
            "Анатолиевна",
            "Анатольевич",
            "Анатольевна",
            "Андреевич",
            "Андреевна",
            "Андрианович",
            "Андриановна",
            "Андрониевич",
            "Андрониевна",
            "Андроникович",
            "Андрониковна",
            "Андронович",
            "Андроновна",
            "Андроньевич",
            "Андроньевна",
            "Аникеевич",
            "Аникеевна",
            "Аникиевич",
            "Аникиевна",
            "Аникитич",
            "Аникитична",
            "Анисиевич",
            "Анисиевна",
            "Анисимович",
            "Анисимовна",
            "Анисьевич",
            "Анисьевна",
            "Антиохович",
            "Антиоховна",
            "Антипиевич",
            "Антипиевна",
            "Антипич",
            "Антипична",
            "Антипович",
            "Антиповна",
            "Антипьевич",
            "Антипьевна",
            "Антонинович",
            "Антониновна",
            "Антонович",
            "Антоновна",
            "Антропиевич",
            "Антропиевна",
            "Антропович",
            "Антроповна",
            "Антропьевич",
            "Антропьевна",
            "Ануфриевич",
            "Ануфриевна",
            "Аполлинариевич",
            "Аполлинариевна",
            "Аполлинарьевич",
            "Аполлинарьевна",
            "Аполлонович",
            "Аполлоновна",
            "Аполлосович",
            "Аполлосовна",
            "Ардалионович",
            "Ардалионовна",
            "Ардальонович",
            "Ардальоновна",
            "Арефиевич",
            "Арефиевна",
            "Арефович",
            "Арефовна",
            "Арефьевич",
            "Арефьевна",
            "Ариевич",
            "Ариевна",
            "Аристархович",
            "Аристарховна",
            "Аристидович",
            "Аристидовна",
            "Аркадиевич",
            "Аркадиевна",
            "Аркадьевич",
            "Аркадьевна",
            "Арнольдович",
            "Арнольдовна",
            "Аронович",
            "Ароновна",
            "Арсениевич",
            "Арсениевна",
            "Арсенович",
            "Арсеновна",
            "Арсентиевич",
            "Арсентиевна",
            "Арсентьевич",
            "Арсентьевна",
            "Арсеньевич",
            "Арсеньевна",
            "Артамонович",
            "Артамоновна",
            "Артемиевич",
            "Артемиевна",
            "Артёмович",
            "Артёмовна",
            "Артемьевич",
            "Артемьевна",
            "Артурович",
            "Артуровна",
            "Архипович",
            "Архиповна",
            "Арьевич",
            "Арьевна",
            "Асафиевич",
            "Асафиевна",
            "Асафович",
            "Асафовна",
            "Асафьевич",
            "Асафьевна",
            "Аскольдович",
            "Аскольдовна",
            "Афанасиевич",
            "Афанасиевна",
            "Афанасьевич",
            "Афанасьевна",
            "Афиногенович",
            "Афиногеновна",
            "Африканович",
            "Африкановна",
            "Бенедиктович",
            "Бенедиктовна",
            "Богданович",
            "Богдановна",
            "Болеславич",
            "Болеславна",
            "Болеславович",
            "Болеславовна",
            "Бонифатиевич",
            "Бонифатиевна",
            "Бонифатович",
            "Бонифатовна",
            "Бонифатьевич",
            "Бонифатьевна",
            "Бориславич",
            "Бориславна",
            "Бориславович",
            "Бориславовна",
            "Борисович",
            "Борисовна",
            "Брониславич",
            "Брониславна",
            "Брониславович",
            "Брониславовна",
            "Вавилич",
            "Вавилична",
            "Вавилович",
            "Вавиловна",
            "Вадимович",
            "Вадимовна",
            "Валентинович",
            "Валентиновна",
            "Валерианович",
            "Валериановна",
            "Валериевич",
            "Валериевна",
            "Валерьевич",
            "Валерьевна",
            "Валерьянович",
            "Валерьяновна",
            "Варламиевич",
            "Варламиевна",
            "Варламович",
            "Варламовна",
            "Варламьевич",
            "Варламьевна",
            "Варнавич",
            "Варнавична",
            "Варсонофиевич",
            "Варсонофиевна",
            "Варсонофович",
            "Варсонофовна",
            "Варсонофьевич",
            "Варсонофьевна",
            "Варфоломеевич",
            "Варфоломеевна",
            "Васильевич",
            "Васильевна",
            "Вассианович",
            "Вассиановна",
            "Велизарович",
            "Велизаровна",
            "Велимирович",
            "Велимировна",
            "Венедиктович",
            "Венедиктовна",
            "Вениаминович",
            "Вениаминовна",
            "Венцеславич",
            "Венцеславна",
            "Венцеславович",
            "Венцеславовна",
            "Веньяминович",
            "Веньяминовна",
            "Викентиевич",
            "Викентиевна",
            "Викентьевич",
            "Викентьевна",
            "Викториевич",
            "Викториевна",
            "Викторович",
            "Викторовна",
            "Викулич",
            "Викулична",
            "Викулович",
            "Викуловна",
            "Виленович",
            "Виленовна",
            "Вильгельмович",
            "Вильгельмовна",
            "Виссарионович",
            "Виссарионовна",
            "Виталиевич",
            "Виталиевна",
            "Витальевич",
            "Витальевна",
            "Витольдович",
            "Витольдовна",
            "Владиленович",
            "Владиленовна",
            "Владимирович",
            "Владимировна",
            "Владиславич",
            "Владиславна",
            "Владиславович",
            "Владиславовна",
            "Владленович",
            "Владленовна",
            "Власиевич",
            "Власиевна",
            "Власович",
            "Власовна",
            "Власьевич",
            "Власьевна",
            "Вонифатиевич",
            "Вонифатиевна",
            "Вонифатович",
            "Вонифатовна",
            "Вонифатьевич",
            "Вонифатьевна",
            "Всеволодович",
            "Всеволодовна",
            "Всеславич",
            "Всеславна",
            "Всеславович",
            "Всеславовна",
            "Вуколович",
            "Вуколовна",
            "Вышеславич",
            "Вышеславна",
            "Вышеславович",
            "Вышеславовна",
            "Вячеславич",
            "Вячеславна",
            "Вячеславович",
            "Вячеславовна",
            "Гpигopьeвич",
            "Гавриилович",
            "Гаврииловна",
            "Гаврилович",
            "Гавриловна",
            "Галактионович",
            "Галактионовна",
            "Гедеонович",
            "Гедеоновна",
            "Геласиевич",
            "Геласиевна",
            "Геласьевич",
            "Геласьевна",
            "Гелиевич",
            "Гелиевна",
            "Геннадиевич",
            "Геннадиевна",
            "Геннадьевич",
            "Геннадьевна",
            "Генрихович",
            "Генриховна",
            "Георгиевич",
            "Георгиевна",
            "Георгьевич",
            "Георгьевна",
            "Герасимович",
            "Герасимовна",
            "Германович",
            "Германовна",
            "Гермогенович",
            "Гермогеновна",
            "Геронтиевич",
            "Геронтиевна",
            "Геронтьевич",
            "Геронтьевна",
            "Гиацинтович",
            "Гиацинтовна",
            "Глебович",
            "Глебовна",
            "Горациевич",
            "Горациевна",
            "Горгониевич",
            "Горгониевна",
            "Горгоньевич",
            "Горгоньевна",
            "Гордеевич",
            "Гордеевна",
            "Григорьевич",
            "Григорьевна",
            "Гуриевич",
            "Гуриевна",
            "Гурьевич",
            "Гурьевна",
            "Гурьянович",
            "Гурьяновна",
            "Давидович",
            "Давидовна",
            "Давыдович",
            "Давыдовна",
            "Далматович",
            "Далматовна",
            "Дамирович",
            "Дамировна",
            "Даниилович",
            "Данииловна",
            "Данилович",
            "Даниловна",
            "Дементиевич",
            "Дементиевна",
            "Дементьевич",
            "Дементьевна",
            "Демидович",
            "Демидовна",
            "Демьянович",
            "Демьяновна",
            "Денисиевич",
            "Денисиевна",
            "Денисович",
            "Денисовна",
            "Денисьевич",
            "Денисьевна",
            "Димитриевич",
            "Димитриевна",
            "Диомидович",
            "Диомидовна",
            "Дионисиевич",
            "Дионисиевна",
            "Дионисьевич",
            "Дионисьевна",
            "Дмитриевич",
            "Дмитриевна",
            "Добромыслович",
            "Добромысловна",
            "Добрынич",
            "Добрынична",
            "Доминикович",
            "Доминиковна",
            "Донатович",
            "Донатовна",
            "Доримедонтович",
            "Доримедонтовна",
            "Дормедонтович",
            "Дормедонтовна",
            "Дормидонтович",
            "Дормидонтовна",
            "Дорофеевич",
            "Дорофеевна",
            "Досифеевич",
            "Досифеевна",
            "Евгениевич",
            "Евгениевна",
            "Евгеньевич",
            "Евгеньевна",
            "Евграфиевич",
            "Евграфиевна",
            "Евграфович",
            "Евграфовна",
            "Евграфьевич",
            "Евграфьевна",
            "Евдокимович",
            "Евдокимовна",
            "Евлампиевич",
            "Евлампиевна",
            "Евлампьевич",
            "Евлампьевна",
            "Евлогиевич",
            "Евлогиевна",
            "Евмениевич",
            "Евмениевна",
            "Евменович",
            "Евменовна",
            "Евменьевич",
            "Евменьевна",
            "Евсеевич",
            "Евсеевна",
            "Евстафиевич",
            "Евстафиевна",
            "Евстафьевич",
            "Евстафьевна",
            "Евстахиевич",
            "Евстахиевна",
            "Евстахьевич",
            "Евстахьевна",
            "Евстигнеевич",
            "Евстигнеевна",
            "Евстратиевич",
            "Евстратиевна",
            "Евстратович",
            "Евстратовна",
            "Евстратьевич",
            "Евстратьевна",
            "Евтихиевич",
            "Евтихиевна",
            "Евтихьевич",
            "Евтихьевна",
            "Евфимиевич",
            "Евфимиевна",
            "Евфимьевич",
            "Евфимьевна",
            "Егориевич",
            "Егориевна",
            "Егорович",
            "Егоровна",
            "Егорьевич",
            "Егорьевна",
            "Елизарович",
            "Елизаровна",
            "Елисеевич",
            "Елисеевна",
            "Елистратович",
            "Елистратовна",
            "Елпидифорович",
            "Елпидифоровна",
            "Емельянович",
            "Емельяновна",
            "Епифаниевич",
            "Епифаниевна",
            "Епифанович",
            "Епифановна",
            "Епифаньевич",
            "Епифаньевна",
            "Еремеевич",
            "Еремеевна",
            "Ермиевич",
            "Ермиевна",
            "Ермилиевич",
            "Ермилиевна",
            "Ермилич",
            "Ермилична",
            "Ермилович",
            "Ермиловна",
            "Ермильевич",
            "Ермильевна",
            "Ермолаевич",
            "Ермолаевна",
            "Ерофеевич",
            "Ерофеевна",
            "Ефимиевич",
            "Ефимиевна",
            "Ефимович",
            "Ефимовна",
            "Ефимьевич",
            "Ефимьевна",
            "Ефремиевич",
            "Ефремиевна",
            "Ефремович",
            "Ефремовна",
            "Ефремьевич",
            "Ефремьевна",
            "Жданович",
            "Ждановна",
            "Захариевич",
            "Захариевна",
            "Захарович",
            "Захаровна",
            "Захарьевич",
            "Захарьевна",
            "Зенонович",
            "Зеноновна",
            "Зиновиевич",
            "Зиновиевна",
            "Зиновьевич",
            "Зиновьевна",
            "Зосимич",
            "Зосимична",
            "Зосимович",
            "Зосимовна",
            "зяславович",
            "Иакимович",
            "Иакимовна",
            "Иакинфович",
            "Иакинфовна",
            "Иванович",
            "Ивановна",
            "Игнатиевич",
            "Игнатиевна",
            "Игнатович",
            "Игнатовна",
            "Игнатьевич",
            "Игнатьевна",
            "Игоревич",
            "Игоревна",
            "Иеронимович",
            "Иеронимовна",
            "Измаилович",
            "Измаиловна",
            "Измайлович",
            "Измайловна",
            "Изосимович",
            "Изосимовна",
            "Изотович",
            "Изотовна",
            "Изяславич",
            "Изяславна",
            "Изяславовна",
            "Иларионович",
            "Иларионовна",
            "Илиодорович",
            "Илиодоровна",
            "Илларионович",
            "Илларионовна",
            "Ильинична",
            "Ильич",
            "Иннокентиевич",
            "Иннокентиевна",
            "Иннокентьевич",
            "Иннокентьевна",
            "Иоаннович",
            "Иоанновна",
            "Иович",
            "Иовна",
            "Ионич",
            "Ионична",
            "Иосафатович",
            "Иосафатовна",
            "Иосифович",
            "Иосифовна",
            "Ипатиевич",
            "Ипатиевна",
            "Ипатович",
            "Ипатовна",
            "Ипатьевич",
            "Ипатьевна",
            "Ипполитович",
            "Ипполитовна",
            "Ираклиевич",
            "Ираклиевна",
            "Иринархович",
            "Иринарховна",
            "Иринеевич",
            "Иринеевна",
            "Исаакиевич",
            "Исаакиевна",
            "Исаакович",
            "Исааковна",
            "Исаевич",
            "Исаевна",
            "Исакиевич",
            "Исакиевна",
            "Исакович",
            "Исаковна",
            "Исидорович",
            "Исидоровна",
            "Иустинович",
            "Иустиновна",
            "Казимирович",
            "Казимировна",
            "Каллиникович",
            "Каллиниковна",
            "Каллистратович",
            "Каллистратовна",
            "Капитонович",
            "Капитоновна",
            "Карионович",
            "Карионовна",
            "Карлович",
            "Карловна",
            "Карпович",
            "Карповна",
            "Касьянович",
            "Касьяновна",
            "Кимович",
            "Кимовна",
            "Киприанович",
            "Киприановна",
            "Кириакович",
            "Кириаковна",
            "Кирикович",
            "Кириковна",
            "Кириллович",
            "Кирилловна",
            "Кирович",
            "Кировна",
            "Кирсанович",
            "Кирсановна",
            "Кирьякович",
            "Кирьяковна",
            "Клавдиевич",
            "Клавдиевна",
            "Климентиевич",
            "Климентиевна",
            "Климентович",
            "Климентовна",
            "Климентьевич",
            "Климентьевна",
            "Климович",
            "Климовна",
            "Кондратиевич",
            "Кондратиевна",
            "Кондратович",
            "Кондратовна",
            "Кондратьевич",
            "Кондратьевна",
            "Кононович",
            "Кононовна",
            "Конрадович",
            "Конрадовна",
            "Константинович",
            "Константиновна",
            "Корнеевич",
            "Корнеевна",
            "Корнелиевич",
            "Корнелиевна",
            "Корнельевич",
            "Корнельевна",
            "Корнилиевич",
            "Корнилиевна",
            "Корнилович",
            "Корниловна",
            "Корнильевич",
            "Корнильевна",
            "Ксенофонтович",
            "Ксенофонтовна",
            "Кузьминична",
            "Кузьмич",
            "Куприянович",
            "Куприяновна",
            "Лаврентиевич",
            "Лаврентиевна",
            "Лаврентьевич",
            "Лаврентьевна",
            "Лаврович",
            "Лавровна",
            "Лазаревич",
            "Лазаревна",
            "Ларионович",
            "Ларионовна",
            "Леонардович",
            "Леонардовна",
            "Леонидович",
            "Леонидовна",
            "Леонович",
            "Леоновна",
            "Леонтиевич",
            "Леонтиевна",
            "Леонтьевич",
            "Леонтьевна",
            "Леопольдович",
            "Леопольдовна",
            "Логвинович",
            "Логвиновна",
            "Логгинович",
            "Логгиновна",
            "Лонгинович",
            "Лонгиновна",
            "Луарсабович",
            "Луарсабовна",
            "Лукианович",
            "Лукиановна",
            "Лукинична",
            "Лукич",
            "Лукьевич",
            "Лукьевна",
            "Лукьянович",
            "Лукьяновна",
            "Львович",
            "Львовна",
            "Любимович",
            "Любимовна",
            "Любомирович",
            "Любомировна",
            "Люцианович",
            "Люциановна",
            "Маврикиевич",
            "Маврикиевна",
            "Маврикьевич",
            "Маврикьевна",
            "Маврович",
            "Мавровна",
            "Мавродиевич",
            "Мавродиевна",
            "Мавродьевич",
            "Мавродьевна",
            "Макариевич",
            "Макариевна",
            "Макарович",
            "Макаровна",
            "Макарьевич",
            "Макарьевна",
            "Максимианович",
            "Максимиановна",
            "Максимилианович",
            "Максимилиановна",
            "Максимильянович",
            "Максимильяновна",
            "Максимович",
            "Максимовна",
            "Мануилович",
            "Мануиловна",
            "Маратович",
            "Маратовна",
            "Мардариевич",
            "Мардариевна",
            "Мардарьевич",
            "Мардарьевна",
            "Марианович",
            "Мариановна",
            "Маринович",
            "Мариновна",
            "Маркелович",
            "Маркеловна",
            "Маркианович",
            "Маркиановна",
            "Маркович",
            "Марковна",
            "Марленович",
            "Марленовна",
            "Мартимьянович",
            "Мартимьяновна",
            "Мартинианович",
            "Мартиниановна",
            "Мартинович",
            "Мартиновна",
            "Мартириевич",
            "Мартириевна",
            "Мартирьевич",
            "Мартирьевна",
            "Мартынович",
            "Мартыновна",
            "Мартьянович",
            "Мартьяновна",
            "Матвеевич",
            "Матвеевна",
            "Мелентиевич",
            "Мелентиевна",
            "Мелентьевич",
            "Мелентьевна",
            "Мелетиевич",
            "Мелетиевна",
            "Мелетьевич",
            "Мелетьевна",
            "Меркулович",
            "Меркуловна",
            "Меркуриевич",
            "Меркуриевна",
            "Меркурьевич",
            "Меркурьевна",
            "Мефодиевич",
            "Мефодиевна",
            "Мефодьевич",
            "Мефодьевна",
            "Мечиславич",
            "Мечиславна",
            "Мечиславович",
            "Мечиславовна",
            "Милиевич",
            "Милиевна",
            "Минаевич",
            "Минаевна",
            "Минич",
            "Минична",
            "Миронович",
            "Мироновна",
            "Мирославич",
            "Мирославна",
            "Мирославович",
            "Мирославовна",
            "Мисаилович",
            "Мисаиловна",
            "Митрофаниевич",
            "Митрофаниевна",
            "Митрофанович",
            "Митрофановна",
            "Митрофаньевич",
            "Митрофаньевна",
            "Михайлович",
            "Михайловна",
            "Михеевич",
            "Михеевна",
            "Модестович",
            "Модестовна",
            "Моисеевич",
            "Моисеевна",
            "Мокеевич",
            "Мокеевна",
            "Мокиевич",
            "Мокиевна",
            "Мстиславович",
            "Мстиславовна",
            "Мэлорович",
            "Мэлоровна",
            "Мэлсович",
            "Мэлсовна",
            "Назариевич",
            "Назариевна",
            "Назарович",
            "Назаровна",
            "Назарьевич",
            "Назарьевна",
            "Наркисович",
            "Наркисовна",
            "Натанович",
            "Натановна",
            "Наумович",
            "Наумовна",
            "Нестерович",
            "Нестеровна",
            "Несторович",
            "Несторовна",
            "Нефёдович",
            "Нефёдовна",
            "Никандрович",
            "Никандровна",
            "Никанорович",
            "Никаноровна",
            "Никитевич",
            "Никитич",
            "Никитична",
            "Никифорович",
            "Никифоровна",
            "Никодимович",
            "Никодимовна",
            "Николаевич",
            "Николаевна",
            "Никонович",
            "Никоновна",
            "Нилович",
            "Ниловна",
            "Нифонтович",
            "Нифонтовна",
            "Октавианович",
            "Октовиановна",
            "Олегович",
            "Олеговна",
            "Олимпиевич",
            "Олимпиевна",
            "Онисимович",
            "Онисимовна",
            "Онуфриевич",
            "Онуфриевна",
            "Орестович",
            "Орестовна",
            "Осипович",
            "Осиповна",
            "Оскарович",
            "Оскаровна",
            "Остапович",
            "Остаповна",
            "Павлинович",
            "Павлиновна",
            "Павлович",
            "Павловна",
            "Паисиевич",
            "Паисиевна",
            "Паисьевич",
            "Паисьевна",
            "Палладиевич",
            "Палладиевна",
            "Палладьевич",
            "Палладьевна",
            "Памфилиевич",
            "Памфилиевна",
            "Памфилович",
            "Памфиловна",
            "Памфильевич",
            "Памфильевна",
            "Панкратиевич",
            "Панкратиевна",
            "Панкратович",
            "Панкратовна",
            "Панкратьевич",
            "Панкратьевна",
            "Пантелеевич",
            "Пантелеевна",
            "Пантелеймонович",
            "Пантелеймоновна",
            "Панфилович",
            "Панфиловна",
            "Парамонович",
            "Парамоновна",
            "Парменович",
            "Пармёнович",
            "Парменовна",
            "Пармёновна",
            "Парфениевич",
            "Парфениевна",
            "Парфёнович",
            "Парфёновна",
            "Парфентиевич",
            "Парфентиевна",
            "Парфентьевич",
            "Парфентьевна",
            "Парфеньевич",
            "Парфеньевна",
            "Патрикеевич",
            "Патрикеевна",
            "Патрикиевич",
            "Патрикиевна",
            "Пафнутиевич",
            "Пафнутиевна",
            "Пафнутьевич",
            "Пафнутьевна",
            "Пахомиевич",
            "Пахомиевна",
            "Пахомович",
            "Пахомовна",
            "Пахомьевич",
            "Пахомьевна",
            "Перфилиевич",
            "Перфилиевна",
            "Перфильевич",
            "Перфильевна",
            "Петрович",
            "Петровна",
            "Пименович",
            "Пименовна",
            "Питиримович",
            "Питиримовна",
            "Платонович",
            "Платоновна",
            "Поликарпиевич",
            "Поликарпиевна",
            "Поликарпович",
            "Поликарповна",
            "Поликарпьевич",
            "Поликарпьевна",
            "Порфириевич",
            "Порфириевна",
            "Порфирович",
            "Порфировна",
            "Порфирьевич",
            "Порфирьевна",
            "Потапиевич",
            "Потапиевна",
            "Потапович",
            "Потаповна",
            "Потапьевич",
            "Потапьевна",
            "Прович",
            "Провна",
            "Проклович",
            "Прокловна",
            "Прокопиевич",
            "Прокопиевна",
            "Прокопович",
            "Прокоповна",
            "Прокопьевич",
            "Прокопьевна",
            "Прокофиевич",
            "Прокофиевна",
            "Прокофьевич",
            "Прокофьевна",
            "Протасиевич",
            "Протасиевна",
            "Протасович",
            "Протасовна",
            "Протасьевич",
            "Протасьевна",
            "Прохорович",
            "Прохоровна",
            "Радиевич",
            "Радиевна",
            "Ратмирович",
            "Ратмировна",
            "Рафаилович",
            "Рафаиловна",
            "Ремович",
            "Ремовна",
            "Робертович",
            "Робертовна",
            "Родионович",
            "Родионовна",
            "Романович",
            "Романовна",
            "Ростиславич",
            "Ростиславна",
            "Ростиславович",
            "Ростиславовна",
            "Рубенович",
            "Рубеновна",
            "Рувимович",
            "Рувимовна",
            "Рудольфович",
            "Рудольфовна",
            "Русланович",
            "Руслановна",
            "Рюрикович",
            "Рюриковна",
            "Савватеевич",
            "Савватеевна",
            "Савватиевич",
            "Савватиевна",
            "Савватьевич",
            "Савватьевна",
            "Саввична",
            "Савелиевич",
            "Савелиевна",
            "Савёлович",
            "Савёловна",
            "Савельевич",
            "Савельевна",
            "Савич",
            "Самойлович",
            "Самойловна",
            "Самсониевич",
            "Самсониевна",
            "Самсонович",
            "Самсоновна",
            "Самсоньевич",
            "Самсоньевна",
            "Самуилович",
            "Самуиловна",
            "Свиридович",
            "Свиридовна",
            "Святополкович",
            "Святополковна",
            "Святославич",
            "Святославна",
            "Святославович",
            "Святославовна",
            "Себастьянович",
            "Себастьяновна",
            "Севастьянович",
            "Севастьяновна",
            "Северинович",
            "Севериновна",
            "Северьянович",
            "Северьяновна",
            "Селиванович",
            "Селивановна",
            "Селивёрстович",
            "Селивёрстовна",
            "Селифанович",
            "Селифановна",
            "Семёнович",
            "Семёновна",
            "Серапионович",
            "Серапионовна",
            "Серафимович",
            "Серафимовна",
            "Сергеевич",
            "Сергеевна",
            "Сигизмундович",
            "Сигизмундовна",
            "Сидорович",
            "Сидоровна",
            "Силанович",
            "Силановна",
            "Силантиевич",
            "Силантиевна",
            "Силантьевич",
            "Силантьевна",
            "Силич",
            "Силовна",
            "Силуянович",
            "Силуяновна",
            "Сильванович",
            "Сильвановна",
            "Сильвестрович",
            "Сильвестровна",
            "Симеонович",
            "Симеоновна",
            "Симонович",
            "Симоновна",
            "Созонович",
            "Созоновна",
            "Созонтиевич",
            "Созонтиевна",
            "Созонтович",
            "Созонтовна",
            "Созонтьевич",
            "Созонтьевна",
            "Сократович",
            "Сократовна",
            "Соломонович",
            "Соломоновна",
            "Сосипатрович",
            "Сосипатровна",
            "Софониевич",
            "Софониевна",
            "Софонович",
            "Софоновна",
            "Софоньевич",
            "Софоньевна",
            "Софрониевич",
            "Софрониевна",
            "Софронович",
            "Софроновна",
            "Софроньевич",
            "Софроньевна",
            "Спартакович",
            "Спартаковна",
            "Спиридониевич",
            "Спиридониевна",
            "Спиридонович",
            "Спиридоновна",
            "Спиридоньевич",
            "Спиридоньевна",
            "Станиславич",
            "Станиславна",
            "Станиславович",
            "Станиславовна",
            "Стахиевич",
            "Стахиевна",
            "Степанович",
            "Степановна",
            "Стратоникович",
            "Стратониковна",
            "Сысоевич",
            "Сысоевна",
            "Тарасович",
            "Тарасовна",
            "Терентиевич",
            "Терентиевна",
            "Терентьевич",
            "Терентьевна",
            "Тертиевич",
            "Тертиевна",
            "Тимофеевич",
            "Тимофеевна",
            "Тимурович",
            "Тимуровна",
            "Титович",
            "Титовна",
            "Тихонович",
            "Тихоновна",
            "Трифонович",
            "Трифоновна",
            "Трофимович",
            "Трофимовна",
            "Уарович",
            "Уаровна",
            "Уварович",
            "Уваровна",
            "Улебович",
            "Улебовна",
            "Ульянович",
            "Ульяновна",
            "Устинович",
            "Устиновна",
            "Фабианович",
            "Фабиановна",
            "Фаддеевич",
            "Фаддеевна",
            "Фадеевич",
            "Фадеевна",
            "Фалалеевич",
            "Фалалеевна",
            "Фатьянович",
            "Фатьяновна",
            "Фёдорович",
            "Фёдоровна",
            "Федосеевич",
            "Федосеевна",
            "Федосиевич",
            "Федосиевна",
            "Федосович",
            "Федосовна",
            "Федосьевич",
            "Федосьевна",
            "Федотиевич",
            "Федотиевна",
            "Федотович",
            "Федотовна",
            "Федотьевич",
            "Федотьевна",
            "Федулович",
            "Федуловна",
            "Феликсович",
            "Феликсовна",
            "Феогностович",
            "Феогностовна",
            "Феоктистович",
            "Феоктистовна",
            "Феофанович",
            "Феофановна",
            "Феофилактович",
            "Феофилактовна",
            "Феофилович",
            "Феофиловна",
            "Ферапонтович",
            "Ферапонтовна",
            "Филаретович",
            "Филаретовна",
            "Филатович",
            "Филатовна",
            "Филимонович",
            "Филимоновна",
            "Филипиевич",
            "Филипиевна",
            "Филиппович",
            "Филипповна",
            "Филипьевич",
            "Филипьевна",
            "Филофеевич",
            "Филофеевна",
            "Фирсович",
            "Фирсовна",
            "Флегонтович",
            "Флегонтовна",
            "Флорентиевич",
            "Флорентиевна",
            "Флорентинович",
            "Флорентиновна",
            "Флорентьевич",
            "Флорентьевна",
            "Флорианович",
            "Флориановна",
            "Фокич",
            "Фокична",
            "Фоминична",
            "Фомич",
            "Фортунатович",
            "Фортунатовна",
            "Фотиевич",
            "Фотиевна",
            "Фотьевич",
            "Фотьевна",
            "Фридрихович",
            "Фридриховна",
            "Фролович",
            "Фроловна",
            "Харитониевич",
            "Харитониевна",
            "Харитонович",
            "Харитоновна",
            "Харитоньевич",
            "Харитоньевна",
            "Харламович",
            "Харламовна",
            "Харлампиевич",
            "Харлампиевна",
            "Харлампович",
            "Харламповна",
            "Харлампьевич",
            "Харлампьевна",
            "Хрисанфович",
            "Хрисанфовна",
            "Христофорович",
            "Христофоровна",
            "Эдуардович",
            "Эдуардовна",
            "Эльдарович",
            "Эльдаровна",
            "Эмилиевич",
            "Эмилиевна",
            "Эмильевич",
            "Эмильевна",
            "Эммануилович",
            "Эммануиловна",
            "Эразмович",
            "Эразмовна",
            "Эрастович",
            "Эрастовна",
            "Эрнестович",
            "Эрнестовна",
            "Эрнстович",
            "Эрнстовна",
            "Ювеналиевич",
            "Ювеналиевна",
            "Ювенальевич",
            "Ювенальевна",
            "Юлианович",
            "Юлиановна",
            "Юлиевич",
            "Юлиевна",
            "Юльевич",
            "Юльевна",
            "Юрьевич",
            "Юрьевна",
            "Юстинович",
            "Юстиновна",
            "Якимович",
            "Якимовна",
            "Яковлевич",
            "Яковлевна",
            "Якубович",
            "Якубовна",
            "Якунович",
            "Якуновна",
            "Янович",
            "Яновна",
            "Януариевич",
            "Януариевна",
            "Януарьевич",
            "Януарьевна",
            "Ярославич",
            "Ярославна",
            "Ярославович",
            "Ярославовна"});
            this.pers_PatronymicTextBox_txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pers_PatronymicTextBox_txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pers_PatronymicTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Patronymic", true));
            this.pers_PatronymicTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_PatronymicTextBox_txt.Location = new System.Drawing.Point(162, 100);
            this.pers_PatronymicTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.pers_PatronymicTextBox_txt.MaxLength = 50;
            this.pers_PatronymicTextBox_txt.Name = "pers_PatronymicTextBox_txt";
            this.pers_PatronymicTextBox_txt.ShortcutsEnabled = false;
            this.pers_PatronymicTextBox_txt.Size = new System.Drawing.Size(190, 27);
            this.pers_PatronymicTextBox_txt.TabIndex = 2;
            this.pers_PatronymicTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.pers_PatronymicTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_PatronymicTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_BirthdayDateTimePicker
            // 
            this.pers_BirthdayDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_BirthdayDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_Birthday", true));
            this.pers_BirthdayDateTimePicker.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_BirthdayDateTimePicker.Location = new System.Drawing.Point(162, 166);
            this.pers_BirthdayDateTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.pers_BirthdayDateTimePicker.Name = "pers_BirthdayDateTimePicker";
            this.pers_BirthdayDateTimePicker.Size = new System.Drawing.Size(190, 27);
            this.pers_BirthdayDateTimePicker.TabIndex = 4;
            // 
            // pers_DSTextBox_txt
            // 
            this.pers_DSTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_DSTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_DS", true));
            this.pers_DSTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_DSTextBox_txt.Location = new System.Drawing.Point(533, 67);
            this.pers_DSTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.pers_DSTextBox_txt.MaxLength = 5;
            this.pers_DSTextBox_txt.Name = "pers_DSTextBox_txt";
            this.pers_DSTextBox_txt.ShortcutsEnabled = false;
            this.pers_DSTextBox_txt.Size = new System.Drawing.Size(190, 27);
            this.pers_DSTextBox_txt.TabIndex = 7;
            this.pers_DSTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.pers_DSTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_DSTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_DNTextBox_num
            // 
            this.pers_DNTextBox_num.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_DNTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_DN", true));
            this.pers_DNTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_DNTextBox_num.Location = new System.Drawing.Point(532, 100);
            this.pers_DNTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.pers_DNTextBox_num.MaxLength = 15;
            this.pers_DNTextBox_num.Name = "pers_DNTextBox_num";
            this.pers_DNTextBox_num.ShortcutsEnabled = false;
            this.pers_DNTextBox_num.Size = new System.Drawing.Size(190, 27);
            this.pers_DNTextBox_num.TabIndex = 8;
            this.pers_DNTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_DNTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_DDateDateTimePicker
            // 
            this.pers_DDateDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_DDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.viewFormBindingSource, "Pers_DDate", true));
            this.pers_DDateDateTimePicker.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_DDateDateTimePicker.Location = new System.Drawing.Point(532, 133);
            this.pers_DDateDateTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.pers_DDateDateTimePicker.Name = "pers_DDateDateTimePicker";
            this.pers_DDateDateTimePicker.Size = new System.Drawing.Size(190, 27);
            this.pers_DDateDateTimePicker.TabIndex = 9;
            // 
            // DWhoTextBox_txt
            // 
            this.DWhoTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.DWhoTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_DWho", true));
            this.DWhoTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.DWhoTextBox_txt.Location = new System.Drawing.Point(533, 166);
            this.DWhoTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.DWhoTextBox_txt.MaxLength = 100;
            this.DWhoTextBox_txt.Name = "DWhoTextBox_txt";
            this.DWhoTextBox_txt.ShortcutsEnabled = false;
            this.DWhoTextBox_txt.Size = new System.Drawing.Size(190, 27);
            this.DWhoTextBox_txt.TabIndex = 10;
            this.DWhoTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.DWhoTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.DWhoTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // pers_INNTextBox_num
            // 
            this.pers_INNTextBox_num.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pers_INNTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Pers_INN", true));
            this.pers_INNTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.pers_INNTextBox_num.Location = new System.Drawing.Point(621, 199);
            this.pers_INNTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.pers_INNTextBox_num.MaxLength = 10;
            this.pers_INNTextBox_num.Name = "pers_INNTextBox_num";
            this.pers_INNTextBox_num.ShortcutsEnabled = false;
            this.pers_INNTextBox_num.Size = new System.Drawing.Size(102, 27);
            this.pers_INNTextBox_num.TabIndex = 11;
            this.pers_INNTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.pers_INNTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.Controls.Add(ad_CountryLabel);
            this.tabPage3.Controls.Add(this.CountryTextBox_txt);
            this.tabPage3.Controls.Add(ad_CityLabel);
            this.tabPage3.Controls.Add(this.CityTextBox_txt);
            this.tabPage3.Controls.Add(ad_IndexLabel);
            this.tabPage3.Controls.Add(this.ad_IndexTextBox_num);
            this.tabPage3.Controls.Add(ad_StreetLabel);
            this.tabPage3.Controls.Add(this.StreetTextBox_txt);
            this.tabPage3.Controls.Add(ad_HouseLabel);
            this.tabPage3.Controls.Add(this.ad_HouseTextBox_num);
            this.tabPage3.Controls.Add(ad_FlatLabel);
            this.tabPage3.Controls.Add(this.ad_FlatTextBox_num);
            this.tabPage3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.tabPage3.ForeColor = System.Drawing.Color.Gold;
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage3.Size = new System.Drawing.Size(758, 260);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Сведения о месте проживания";
            // 
            // CountryTextBox_txt
            // 
            this.CountryTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CountryTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_Country", true));
            this.CountryTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.CountryTextBox_txt.Location = new System.Drawing.Point(143, 84);
            this.CountryTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.CountryTextBox_txt.MaxLength = 25;
            this.CountryTextBox_txt.Name = "CountryTextBox_txt";
            this.CountryTextBox_txt.ShortcutsEnabled = false;
            this.CountryTextBox_txt.Size = new System.Drawing.Size(202, 27);
            this.CountryTextBox_txt.TabIndex = 0;
            this.CountryTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.CountryTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.CountryTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // CityTextBox_txt
            // 
            this.CityTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CityTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_City", true));
            this.CityTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.CityTextBox_txt.Location = new System.Drawing.Point(143, 117);
            this.CityTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.CityTextBox_txt.MaxLength = 25;
            this.CityTextBox_txt.Name = "CityTextBox_txt";
            this.CityTextBox_txt.ShortcutsEnabled = false;
            this.CityTextBox_txt.Size = new System.Drawing.Size(202, 27);
            this.CityTextBox_txt.TabIndex = 1;
            this.CityTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.CityTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.CityTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ad_IndexTextBox_num
            // 
            this.ad_IndexTextBox_num.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ad_IndexTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_Index", true));
            this.ad_IndexTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ad_IndexTextBox_num.Location = new System.Drawing.Point(143, 150);
            this.ad_IndexTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.ad_IndexTextBox_num.MaxLength = 10;
            this.ad_IndexTextBox_num.Name = "ad_IndexTextBox_num";
            this.ad_IndexTextBox_num.ShortcutsEnabled = false;
            this.ad_IndexTextBox_num.Size = new System.Drawing.Size(202, 27);
            this.ad_IndexTextBox_num.TabIndex = 2;
            this.ad_IndexTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ad_IndexTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // StreetTextBox_txt
            // 
            this.StreetTextBox_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.StreetTextBox_txt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_Street", true));
            this.StreetTextBox_txt.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.StreetTextBox_txt.Location = new System.Drawing.Point(492, 84);
            this.StreetTextBox_txt.Margin = new System.Windows.Forms.Padding(2);
            this.StreetTextBox_txt.MaxLength = 50;
            this.StreetTextBox_txt.Name = "StreetTextBox_txt";
            this.StreetTextBox_txt.ShortcutsEnabled = false;
            this.StreetTextBox_txt.Size = new System.Drawing.Size(202, 27);
            this.StreetTextBox_txt.TabIndex = 3;
            this.StreetTextBox_txt.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.StreetTextBox_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.StreetTextBox_txt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ad_HouseTextBox_num
            // 
            this.ad_HouseTextBox_num.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ad_HouseTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_House", true));
            this.ad_HouseTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ad_HouseTextBox_num.Location = new System.Drawing.Point(492, 117);
            this.ad_HouseTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.ad_HouseTextBox_num.MaxLength = 3;
            this.ad_HouseTextBox_num.Name = "ad_HouseTextBox_num";
            this.ad_HouseTextBox_num.ShortcutsEnabled = false;
            this.ad_HouseTextBox_num.Size = new System.Drawing.Size(202, 27);
            this.ad_HouseTextBox_num.TabIndex = 4;
            this.ad_HouseTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ad_HouseTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // ad_FlatTextBox_num
            // 
            this.ad_FlatTextBox_num.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ad_FlatTextBox_num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Ad_Flat", true));
            this.ad_FlatTextBox_num.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ad_FlatTextBox_num.Location = new System.Drawing.Point(492, 150);
            this.ad_FlatTextBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.ad_FlatTextBox_num.MaxLength = 3;
            this.ad_FlatTextBox_num.Name = "ad_FlatTextBox_num";
            this.ad_FlatTextBox_num.ShortcutsEnabled = false;
            this.ad_FlatTextBox_num.Size = new System.Drawing.Size(202, 27);
            this.ad_FlatTextBox_num.TabIndex = 5;
            this.ad_FlatTextBox_num.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.ad_FlatTextBox_num.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.tabPage4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage4.Controls.Add(this.btn_Prof);
            this.tabPage4.Controls.Add(this.btn_Comp);
            this.tabPage4.Controls.Add(label15);
            this.tabPage4.Controls.Add(this.ItogoLabel);
            this.tabPage4.Controls.Add(this.cs_Comp_scoreLabel);
            this.tabPage4.Controls.Add(label17);
            this.tabPage4.Controls.Add(label16);
            this.tabPage4.Controls.Add(label14);
            this.tabPage4.Controls.Add(label13);
            this.tabPage4.Controls.Add(label11);
            this.tabPage4.Controls.Add(label10);
            this.tabPage4.Controls.Add(this.cs_GPATextBox);
            this.tabPage4.Controls.Add(this.cs_Com_subComboBox);
            this.tabPage4.Controls.Add(this.cs_Com_sub_markTextBox);
            this.tabPage4.Controls.Add(this.cs_Prof_subComboBox);
            this.tabPage4.Controls.Add(this.cs_Prof_sub_markTextBox);
            this.tabPage4.Controls.Add(this.cs_Extra_pointsTextBox);
            this.tabPage4.Controls.Add(this.cs_TestTextBox);
            this.tabPage4.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.tabPage4.ForeColor = System.Drawing.Color.White;
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage4.Size = new System.Drawing.Size(758, 260);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Конкурсный балл";
            // 
            // btn_Prof
            // 
            this.btn_Prof.BackColor = System.Drawing.Color.White;
            this.btn_Prof.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Prof.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Prof.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic);
            this.btn_Prof.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.btn_Prof.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.edit;
            this.btn_Prof.Location = new System.Drawing.Point(427, 105);
            this.btn_Prof.Name = "btn_Prof";
            this.btn_Prof.Size = new System.Drawing.Size(16, 16);
            this.btn_Prof.TabIndex = 115;
            this.btn_Prof.TabStop = false;
            this.btn_Prof.UseVisualStyleBackColor = false;
            this.btn_Prof.Click += new System.EventHandler(this.btn_Prof_Click);
            // 
            // btn_Comp
            // 
            this.btn_Comp.BackColor = System.Drawing.Color.White;
            this.btn_Comp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Comp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Comp.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic);
            this.btn_Comp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.btn_Comp.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.edit;
            this.btn_Comp.Location = new System.Drawing.Point(427, 70);
            this.btn_Comp.Name = "btn_Comp";
            this.btn_Comp.Size = new System.Drawing.Size(16, 16);
            this.btn_Comp.TabIndex = 115;
            this.btn_Comp.TabStop = false;
            this.btn_Comp.UseVisualStyleBackColor = false;
            this.btn_Comp.Click += new System.EventHandler(this.btn_Comp_Click);
            // 
            // ItogoLabel
            // 
            this.ItogoLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ItogoLabel.AutoSize = true;
            this.ItogoLabel.BackColor = System.Drawing.Color.Transparent;
            this.ItogoLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.ItogoLabel.ForeColor = System.Drawing.Color.White;
            this.ItogoLabel.Location = new System.Drawing.Point(203, 173);
            this.ItogoLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ItogoLabel.Name = "ItogoLabel";
            this.ItogoLabel.Size = new System.Drawing.Size(63, 19);
            this.ItogoLabel.TabIndex = 113;
            this.ItogoLabel.Text = "Итого:";
            this.ItogoLabel.Visible = false;
            // 
            // cs_Comp_scoreLabel
            // 
            this.cs_Comp_scoreLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Comp_scoreLabel.AutoSize = true;
            this.cs_Comp_scoreLabel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Comp_score", true));
            this.cs_Comp_scoreLabel.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Comp_scoreLabel.ForeColor = System.Drawing.Color.White;
            this.cs_Comp_scoreLabel.Location = new System.Drawing.Point(270, 173);
            this.cs_Comp_scoreLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cs_Comp_scoreLabel.Name = "cs_Comp_scoreLabel";
            this.cs_Comp_scoreLabel.Size = new System.Drawing.Size(18, 19);
            this.cs_Comp_scoreLabel.TabIndex = 7;
            this.cs_Comp_scoreLabel.Text = "0";
            this.cs_Comp_scoreLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cs_Comp_scoreLabel.Visible = false;
            // 
            // cs_GPATextBox
            // 
            this.cs_GPATextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_GPATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_GPA", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.cs_GPATextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_GPATextBox.Location = new System.Drawing.Point(270, 134);
            this.cs_GPATextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_GPATextBox.MaxLength = 7;
            this.cs_GPATextBox.Name = "cs_GPATextBox";
            this.cs_GPATextBox.ShortcutsEnabled = false;
            this.cs_GPATextBox.Size = new System.Drawing.Size(78, 27);
            this.cs_GPATextBox.TabIndex = 4;
            this.cs_GPATextBox.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.cs_GPATextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.cs_GPATextBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // cs_Com_subComboBox
            // 
            this.cs_Com_subComboBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Com_subComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Com_sub", true));
            this.cs_Com_subComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cs_Com_subComboBox.DropDownWidth = 151;
            this.cs_Com_subComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cs_Com_subComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Com_subComboBox.FormattingEnabled = true;
            this.cs_Com_subComboBox.IntegralHeight = false;
            this.cs_Com_subComboBox.Location = new System.Drawing.Point(270, 65);
            this.cs_Com_subComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_Com_subComboBox.MaxDropDownItems = 4;
            this.cs_Com_subComboBox.Name = "cs_Com_subComboBox";
            this.cs_Com_subComboBox.Size = new System.Drawing.Size(152, 27);
            this.cs_Com_subComboBox.Sorted = true;
            this.cs_Com_subComboBox.TabIndex = 0;
            // 
            // cs_Com_sub_markTextBox
            // 
            this.cs_Com_sub_markTextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Com_sub_markTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Com_sub_mark", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.cs_Com_sub_markTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Com_sub_markTextBox.Location = new System.Drawing.Point(622, 65);
            this.cs_Com_sub_markTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_Com_sub_markTextBox.MaxLength = 7;
            this.cs_Com_sub_markTextBox.Name = "cs_Com_sub_markTextBox";
            this.cs_Com_sub_markTextBox.ShortcutsEnabled = false;
            this.cs_Com_sub_markTextBox.Size = new System.Drawing.Size(78, 27);
            this.cs_Com_sub_markTextBox.TabIndex = 1;
            this.cs_Com_sub_markTextBox.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.cs_Com_sub_markTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.cs_Com_sub_markTextBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // cs_Prof_subComboBox
            // 
            this.cs_Prof_subComboBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Prof_subComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Prof_sub", true));
            this.cs_Prof_subComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cs_Prof_subComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cs_Prof_subComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Prof_subComboBox.FormattingEnabled = true;
            this.cs_Prof_subComboBox.IntegralHeight = false;
            this.cs_Prof_subComboBox.Location = new System.Drawing.Point(270, 100);
            this.cs_Prof_subComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_Prof_subComboBox.MaxDropDownItems = 4;
            this.cs_Prof_subComboBox.Name = "cs_Prof_subComboBox";
            this.cs_Prof_subComboBox.Size = new System.Drawing.Size(152, 27);
            this.cs_Prof_subComboBox.TabIndex = 2;
            // 
            // cs_Prof_sub_markTextBox
            // 
            this.cs_Prof_sub_markTextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Prof_sub_markTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Prof_sub_mark", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.cs_Prof_sub_markTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Prof_sub_markTextBox.Location = new System.Drawing.Point(622, 100);
            this.cs_Prof_sub_markTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_Prof_sub_markTextBox.MaxLength = 7;
            this.cs_Prof_sub_markTextBox.Name = "cs_Prof_sub_markTextBox";
            this.cs_Prof_sub_markTextBox.ShortcutsEnabled = false;
            this.cs_Prof_sub_markTextBox.Size = new System.Drawing.Size(78, 27);
            this.cs_Prof_sub_markTextBox.TabIndex = 3;
            this.cs_Prof_sub_markTextBox.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.cs_Prof_sub_markTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.cs_Prof_sub_markTextBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // cs_Extra_pointsTextBox
            // 
            this.cs_Extra_pointsTextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_Extra_pointsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Extra_points", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.cs_Extra_pointsTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_Extra_pointsTextBox.Location = new System.Drawing.Point(622, 168);
            this.cs_Extra_pointsTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_Extra_pointsTextBox.MaxLength = 7;
            this.cs_Extra_pointsTextBox.Name = "cs_Extra_pointsTextBox";
            this.cs_Extra_pointsTextBox.ShortcutsEnabled = false;
            this.cs_Extra_pointsTextBox.Size = new System.Drawing.Size(78, 27);
            this.cs_Extra_pointsTextBox.TabIndex = 6;
            this.cs_Extra_pointsTextBox.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.cs_Extra_pointsTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.cs_Extra_pointsTextBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // cs_TestTextBox
            // 
            this.cs_TestTextBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cs_TestTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewFormBindingSource, "Cs_Test", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.cs_TestTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.cs_TestTextBox.Location = new System.Drawing.Point(622, 134);
            this.cs_TestTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cs_TestTextBox.MaxLength = 7;
            this.cs_TestTextBox.Name = "cs_TestTextBox";
            this.cs_TestTextBox.ShortcutsEnabled = false;
            this.cs_TestTextBox.Size = new System.Drawing.Size(78, 27);
            this.cs_TestTextBox.TabIndex = 5;
            this.cs_TestTextBox.TextChanged += new System.EventHandler(this.Control_of_symbols_TextChanged);
            this.cs_TestTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            this.cs_TestTextBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.TextBox_PreviewKeyDown);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(27)))), ((int)(((byte)(0)))));
            this.btn_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancel.Font = new System.Drawing.Font("Century Schoolbook", 12.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Cancel.ForeColor = System.Drawing.Color.White;
            this.btn_Cancel.Location = new System.Drawing.Point(575, 297);
            this.btn_Cancel.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(170, 28);
            this.btn_Cancel.TabIndex = 2;
            this.btn_Cancel.Text = "Отмена";
            this.btn_Cancel.UseVisualStyleBackColor = false;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // toolTip
            // 
            this.toolTip.Active = false;
            this.toolTip.AutoPopDelay = 5000;
            this.toolTip.InitialDelay = 1;
            this.toolTip.IsBalloon = true;
            this.toolTip.ReshowDelay = 100;
            this.toolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Warning;
            this.toolTip.ToolTipTitle = "Предупреждение";
            // 
            // btn_Confirm
            // 
            this.btn_Confirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.btn_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Confirm.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_Confirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Confirm.Font = new System.Drawing.Font("Century Schoolbook", 12.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Confirm.ForeColor = System.Drawing.Color.White;
            this.btn_Confirm.Location = new System.Drawing.Point(400, 297);
            this.btn_Confirm.Name = "btn_Confirm";
            this.btn_Confirm.Size = new System.Drawing.Size(170, 28);
            this.btn_Confirm.TabIndex = 1;
            this.btn_Confirm.Text = "Подтвердить";
            this.btn_Confirm.UseVisualStyleBackColor = false;
            this.btn_Confirm.Click += new System.EventHandler(this.btn_Confirm_Click);
            // 
            // timerShow
            // 
            this.timerShow.Tick += new System.EventHandler(this.Show);
            // 
            // view_FormTableAdapter
            // 
            this.view_FormTableAdapter.ClearBeforeFill = true;
            // 
            // timerHide
            // 
            this.timerHide.Tick += new System.EventHandler(this.Hide);
            // 
            // errorProvider
            // 
            this.errorProvider.BlinkRate = 75;
            this.errorProvider.ContainerControl = this;
            // 
            // Registration_form
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(766, 332);
            this.Controls.Add(this.btn_Confirm);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.tabControl);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Registration_form";
            this.Opacity = 0D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Анкета абитуриента";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Registration_form_FormClosing);
            this.Load += new System.EventHandler(this.Registration_form_Load);
            this.InputLanguageChanged += new System.Windows.Forms.InputLanguageChangedEventHandler(this.Registration_form_InputLanguageChanged);
            this.Shown += new System.EventHandler(this.Registration_form_Shown);
            this.Layout += new System.Windows.Forms.LayoutEventHandler(this.Registration_form_Layout);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewFormBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_AbiturientDataSet)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox pers_LastnameTextBox_txt;
        private System.Windows.Forms.TextBox pers_FirstnameTextBox_txt;
        private System.Windows.Forms.TextBox pers_PatronymicTextBox_txt;
        private System.Windows.Forms.DateTimePicker pers_BirthdayDateTimePicker;
        private System.Windows.Forms.TextBox pers_DSTextBox_txt;
        private System.Windows.Forms.TextBox pers_DNTextBox_num;
        private System.Windows.Forms.DateTimePicker pers_DDateDateTimePicker;
        private System.Windows.Forms.TextBox DWhoTextBox_txt;
        private System.Windows.Forms.TextBox pers_INNTextBox_num;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.ComboBox pers_SexComboBox;
        private System.Windows.Forms.ComboBox pers_DKComboBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox ab_EDKComboBox;
        private System.Windows.Forms.TextBox ab_EDNTextBox_num;
        private System.Windows.Forms.DateTimePicker ab_ED_DateDateTimePicker;
        private System.Windows.Forms.TextBox ED_WhoTextBox_txt;
        private System.Windows.Forms.ComboBox ab_ED_ExcComboBox;
        private System.Windows.Forms.ComboBox ab_ForLangComboBox;
        private System.Windows.Forms.ComboBox ab_MedCert1ComboBox;
        private System.Windows.Forms.ComboBox ab_MedCert2ComboBox;
        private System.Windows.Forms.ComboBox ab_MedCert3ComboBox;
        private System.Windows.Forms.ComboBox ab_Spec1ComboBox;
        private System.Windows.Forms.ComboBox ab_Spec2ComboBox;
        private System.Windows.Forms.ComboBox ab_Spec3ComboBox;
        private System.Windows.Forms.TextBox CountryTextBox_txt;
        private System.Windows.Forms.TextBox CityTextBox_txt;
        private System.Windows.Forms.TextBox ad_IndexTextBox_num;
        private System.Windows.Forms.TextBox StreetTextBox_txt;
        private System.Windows.Forms.TextBox ad_HouseTextBox_num;
        private System.Windows.Forms.TextBox ad_FlatTextBox_num;
        private System.Windows.Forms.TextBox cs_GPATextBox;
        private System.Windows.Forms.ComboBox cs_Com_subComboBox;
        private System.Windows.Forms.TextBox cs_Com_sub_markTextBox;
        private System.Windows.Forms.ComboBox cs_Prof_subComboBox;
        private System.Windows.Forms.TextBox cs_Prof_sub_markTextBox;
        private System.Windows.Forms.TextBox cs_Extra_pointsTextBox;
        private System.Windows.Forms.TextBox cs_TestTextBox;
        private System.Windows.Forms.Label cs_Comp_scoreLabel;
        private System.Windows.Forms.Label ItogoLabel;
        private System.Windows.Forms.MaskedTextBox pers_PhoneMaskedTextBox;
        private System.Windows.Forms.TextBox ab_EDSTextBox_txt;
        private System.Windows.Forms.TextBox PrivTextBox_txt;
        private System.Windows.Forms.TextBox IDTextBox_txt;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.ComboBox ab_EBComboBox;
        private System.Windows.Forms.ComboBox ab_EFComboBox;
        private System.Windows.Forms.ToolTip toolTip;
        private Database.BD_AbiturientDataSet bD_AbiturientDataSet;
        private System.Windows.Forms.BindingSource viewFormBindingSource;
        private Database.BD_AbiturientDataSetTableAdapters.View_FormTableAdapter view_FormTableAdapter;
        private System.Windows.Forms.Timer timerShow;
        private System.Windows.Forms.Button btn_Spec;
        private System.Windows.Forms.Button btn_Prof;
        private System.Windows.Forms.Button btn_Comp;
        private System.Windows.Forms.Timer timerHide;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btn_Confirm;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}