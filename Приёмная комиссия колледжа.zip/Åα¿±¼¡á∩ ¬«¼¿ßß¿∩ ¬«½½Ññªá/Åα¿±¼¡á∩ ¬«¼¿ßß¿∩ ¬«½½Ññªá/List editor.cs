﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Приёмная_комиссия_колледжа
{
    public partial class List_editor : Form
    {
        public Registration_form F2;            //Переменная класса для взаимодействия с родительской формой
        private bool for_lang;                  //Переменная иностранных языков (кроме Англ.(США))  
        private bool a;                         //Переменная корректного ввода

        //***********************************************
        // Блоки инициализации и предварительной загрузки
        //***********************************************
        public List_editor()
        {
            InitializeComponent();
        }

        private void Edit_list_Load(object sender, EventArgs e)
        {
            if (F2 != null)
            {
                if (F2.en_t == 1)
                {
                    textBox.CharacterCasing = CharacterCasing.Upper;
                    textBox.MaxLength = 5;
                    this.LoadFile(@"\Specialties.dat", "специальностей");
                }
                else if (F2.en_t == 2)
                    this.LoadFile(@"\Comp. subjects.dat", "обязательных предметов");
                else if (F2.en_t == 3)
                    this.LoadFile(@"\Prof. subjects.dat", "профильных предметов");
                a = true;
            }
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Edit_list_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //**************************
        // Блоки обработчиков кнопок
        //**************************
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            this.Add();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            this.Delete();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (F2 != null)
            {
                //Запись специальностей в файл
                if (F2.en_t == 1)
                    this.RecordingInFile(@"\Specialties.dat");
                //Запись обяз. предеметов в файл
                else if (F2.en_t == 2)
                    this.RecordingInFile(@"\Comp. subjects.dat");
                //Запись проф. предметов в файл
                else if (F2.en_t == 3)
                    this.RecordingInFile(@"\Prof. subjects.dat");
                this.Close();
            }
        }

        //************************************************
        // Обработчик активации/деактивации кнопки Удалить
        //************************************************
        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Convert.ToString(listBox.SelectedItem)))
                btn_Delete.Enabled = false;
            else
                btn_Delete.Enabled = true;
        }

        //************************************************
        // Блоки обработчиков анализа раскладки клавиатуры
        //************************************************
        private void Edit_list_Shown(object sender, EventArgs e)
        {
            this.Keyboard_Lang();
        }

        private void Edit_list_InputLanguageChanged(object sender, InputLanguageChangedEventArgs e)
        {
            this.Keyboard_Lang();
        }

        //**********************************
        // Блоки обработчиков нажатия клавиш
        //**********************************
        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (for_lang == true)
            {   //Подавляем передачу сигнала нажатой клавишы
                e.SuppressKeyPress = true;
            }
            else
            {   //Подавляем передачу сигнала нажатой клавишы
                e.SuppressKeyPress = true;
                //Разрешаем обработку всех клавиш с буквами
                if ((e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z) || (e.KeyCode == Keys.Oemtilde) || (e.KeyCode == Keys.OemSemicolon) || (e.KeyCode == Keys.OemQuotes) || (e.KeyCode == Keys.OemOpenBrackets) || (e.KeyCode == Keys.OemCloseBrackets) || (e.KeyCode == Keys.Oemcomma) || (e.KeyCode == Keys.OemPeriod))
                    e.SuppressKeyPress = false;
                //Разрешаем обработку клавиш Delete, Backspace, Home, End и перемещение стрелок вправо, влево
                if ((e.KeyCode == Keys.Delete) || (e.KeyCode == Keys.Back) || (e.KeyCode == Keys.Right) || (e.KeyCode == Keys.Left) || (e.KeyCode == Keys.Home) || (e.KeyCode == Keys.End))
                    e.SuppressKeyPress = false;
                //Разрешаем обработку клавишы Space
                if ((e.KeyCode == Keys.Space) && (F2 != null) && (F2.en_t != 1))
                    e.SuppressKeyPress = false;
                //Разрешаем обработку клавиши Enter
                if ((a == true) && (e.KeyCode == Keys.Enter) && (!String.IsNullOrEmpty(textBox.Text)))
                {
                    e.SuppressKeyPress = false;
                    this.Add();
                }
            }
        }

        private void listBox_KeyDown(object sender, KeyEventArgs e)
        {
            if ((listBox.Items.Count > 1) && (e.KeyCode == Keys.Delete) && (!String.IsNullOrEmpty(Convert.ToString(listBox.SelectedItem))))
                this.Delete();
        }

        //*****************************
        // Обработчик корректного ввода
        //*****************************
        private void textBox_TextChanged(object sender, EventArgs e)
        {
            //Если текста нет
            if (String.IsNullOrEmpty((sender as TextBox).Text))
            {
                errorProvider.Clear();
                toolTip.Active = false;
                (sender as TextBox).ForeColor = Color.Black;
                btn_Add.Enabled = false;
                return;
            }
            a = true; int l, t; bool b = true; bool el = false; String str;
            str = (sender as TextBox).Text;
            l = str.Length;
            //Индекс символа
            t = 0;
            //Проверка на совпадение введённого текста с элементами списка
            for (int i = 0; i < listBox.Items.Count; i++)
            {
                if (str == Convert.ToString(listBox.Items[i]))
                    el = true;
            }
            //Проверка стоят ли пробелы рядом
            for (int i = 0; i <= l - 1; i++)
            {
                if ((l >= 2) && (i != 0) && (str[i] == ' ') && (str[i] == str[i - 1]))
                { a = false; b = false; }
            }
            //Проверка стоит ли пробел в начале или в конце
            if ((str[t] == ' ') || (str[l - 1] == ' '))
                a = false;
            //Если есть некорректный ввод
            if (a == false)
            {
                errorProvider.SetError((sender as TextBox), "Внимание");
                //Активируем подсказку
                toolTip.Active = true;
                //Устанавливаем нужный текст во всплывающую подсказку
                if (b == true)
                    toolTip.SetToolTip((sender as TextBox), "Пробелы в начале или в конце недопустимы.");
                else
                    toolTip.SetToolTip((sender as TextBox), "Несколько пробелов обнаружены рядом.");
                (sender as TextBox).ForeColor = Color.Red;
                btn_Add.Enabled = false;
                (sender as TextBox).Focus();
            }
            else if (el == true)
            {
                errorProvider.SetError((sender as TextBox), "Внимание");
                //Активируем подсказку
                toolTip.Active = true;
                //Устанавливаем нужный текст во всплывающую подсказку
                toolTip.SetToolTip((sender as TextBox), "Такой элемент уже присутствует в списке.");
                (sender as TextBox).ForeColor = Color.Red;
                btn_Add.Enabled = false;
                (sender as TextBox).Focus();
            }
            else
            {
                errorProvider.Clear();
                //Деактивируем подсказку
                toolTip.Active = false;
                (sender as TextBox).ForeColor = Color.Black;
                btn_Add.Enabled = true;
            }
        }

        //*******************
        // Oбработчик таймерa
        //*******************
        private void Show(object sender, EventArgs e)
        {
            this.Show();
            if (!F2.F1.F0.chb_Main_menu.Checked)
            {
                this.Opacity += 0.15;
                if (this.Opacity == 1)
                {
                    timerShow.Stop();
                    timerShow.Dispose();
                }
            }
            else
            {
                this.Opacity = 1.0;
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        //*******************************
        // Обработчик закрытия этой формы
        //*******************************
        private void List_editor_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
        }

        //***************************************
        // Блоки обработчиков, оптимизирующих код
        //***************************************
        private void Add()
        {
            listBox.Items.Add(textBox.Text);
            textBox.Text = "";
            if (btn_Delete.Enabled == false)
                btn_Delete.Enabled = true;
            if (btn_Save.Enabled == false)
                btn_Save.Enabled = true;
        }

        private void Delete()
        {
            if (listBox.SelectedIndex >= 0)
            {
                //Удаляем из списка
                listBox.Items.RemoveAt(listBox.SelectedIndex);
                btn_Save.Enabled = true;
                //Если список пуст (пустая строка по умолчанию никуда не девается)
                if (listBox.Items.Count == 1)
                {
                    btn_Delete.Enabled = false;
                    btn_Save.Enabled = false;
                }
            }
        }

        private void LoadFile(string fileName, string txtMsg)
        {   //Проверяем существование файла
            if (File.Exists(Application.StartupPath + fileName))
                listBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + fileName));
            else
            {
                MessageBox.Show("Файл с перечнем '" + txtMsg + "' не был найден. Возможно, он был удалён, перемещён или переименован.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void RecordingInFile(string fileName)
        {
            using (StreamWriter sr = new StreamWriter(Application.StartupPath + fileName))
            {
                //Заносим в файл элементы списка
                for (int i = 0; i < listBox.Items.Count; i++)
                    sr.WriteLine(listBox.Items[i]);
            }
        }

        private void Keyboard_Lang()
        {
            //Анализируем текущую раскладку клавиатуры
            if (InputLanguage.CurrentInputLanguage.LayoutName != "Русская")
            {
                for_lang = true;
                MessageBox.Show("Ввод данных возможен только на раскладке клавиатуры \"Русский(Россия)\".", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
                for_lang = false;
        }
    }
}