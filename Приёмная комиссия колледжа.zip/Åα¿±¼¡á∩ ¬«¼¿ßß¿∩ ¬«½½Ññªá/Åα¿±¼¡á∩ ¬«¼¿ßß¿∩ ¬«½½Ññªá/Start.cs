﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Приёмная_комиссия_колледжа
{
    public partial class Start : Form
    {
        int tmpX;               //Переменная для хранения Х-ой временной координаты курсора
        int tmpY;               //Переменная для хранения У-ой временной координаты курсора
        bool flMove = false;    //Логическая переменная перемещения курсора

        public Start()
        {
            InitializeComponent();
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Start_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //*************************************
        // Блоки обработчиков перемещения формы
        //*************************************
        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            tmpX = Cursor.Position.X;
            tmpY = Cursor.Position.Y;
            flMove = true;
        }

        private void Start_MouseMove(object sender, MouseEventArgs e)
        {
            if (flMove)
            {
                this.Left = this.Left + (Cursor.Position.X - tmpX);
                this.Top = this.Top + (Cursor.Position.Y - tmpY);

                tmpX = Cursor.Position.X;
                tmpY = Cursor.Position.Y;
            }
        }

        private void Start_MouseUp(object sender, MouseEventArgs e)
        {
            flMove = false;
        }

        //****************************
        // Блоки обработчиков таймеров
        //****************************
        private void timerLoad_Tick(object sender, EventArgs e)
        {
            if (lb_Load.Width < 320)
                lb_Load.Width += 4;
            else
            {
                this.Hide();
                timerLoad.Stop();
                timerLoad.Dispose();
            }
        }

        private void timerShow_Tick(object sender, EventArgs e)
        {
            this.Show();
            this.Opacity += 0.15;
            if (this.Opacity == 1)
            {
                timerShow.Stop();
                timerShow.Dispose();
                timerLoad.Start();
            }
        }

        //***********************************
        // Обработчик появления главного окна
        //***********************************
        private void lb_Load_Resize(object sender, EventArgs e)
        {
            if (lb_Load.Width >= 320)
            {
                Main_menu M = new Main_menu();
                M.Show();
            }
        }
    }
}