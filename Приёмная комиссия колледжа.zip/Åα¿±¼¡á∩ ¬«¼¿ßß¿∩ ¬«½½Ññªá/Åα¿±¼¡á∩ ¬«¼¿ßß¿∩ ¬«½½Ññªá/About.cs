﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Приёмная_комиссия_колледжа
{
    partial class About : Form
    {
        private Main_menu F0;

        //**************************
        // Обработчики инициализации
        //**************************
        public About()
        {
            InitializeComponent();
        }

        public About(Main_menu F)
        {
            InitializeComponent();
            F0 = F;
        }

        //************************************
        // Обработчик предварительной загрузки
        //************************************
        private void About_Load(object sender, EventArgs e)
        {
            this.Text = String.Format("О программе {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("{0}" + "-rc", AssemblyVersion);
            this.labelCopyright.Text = AssemblyCopyright;
            this.textBoxDescription.Text = AssemblyDescription;
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void About_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //*******************
        // Обработчик таймера
        //*******************
        private void Show(object sender, EventArgs e)
        {
            this.Show();
            if (!F0.chb_Main_menu.Checked)
            {
                this.Opacity += 0.15;
                if (this.Opacity == 1)
                {
                    timerShow.Stop();
                    timerShow.Dispose();
                }
            }
            else
            {
                this.Opacity = 1.0;
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        //******************
        // Обработчик кнопки
        //******************
        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //*******************************
        // Обработчик закрытия этой формы
        //*******************************
        private void About_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
        }

        #region Методы доступа к атрибутам сборки

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }
        #endregion
    }
}