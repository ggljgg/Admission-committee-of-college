﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Управление общими сведениями о сборке осуществляется с помощью 
// набора атрибутов. Измените значения этих атрибутов, чтобы изменить сведения,
// связанные со сборкой.
[assembly: AssemblyTitle("Приёмная комиссия колледжа")]
[assembly: AssemblyDescription("Данное ПО является бесплатным для использование и распространения. Оно предназначено для ведения учёта данных абитуриентов, поступающих в колледж.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("S@g@Corpor@tion")]
[assembly: AssemblyProduct("Приёмная комиссия колледжа")]
[assembly: AssemblyCopyright("Copyright © 2017 Сагайдак Д. Р.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Параметр ComVisible со значением FALSE делает типы в сборке невидимыми 
// для COM-компонентов.  Если требуется обратиться к типу в этой сборке через 
// COM, задайте атрибуту ComVisible значение TRUE для этого типа.
[assembly: ComVisible(false)]

// Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
[assembly: Guid("c068dc02-e7f9-4c67-b6b0-c3b3b704c3f3")]

// Сведения о версии сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//      Номер построения
//      Редакция
//
// Можно задать все значения или принять номер построения и номер редакции по умолчанию, 
// используя "*", как показано ниже:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
