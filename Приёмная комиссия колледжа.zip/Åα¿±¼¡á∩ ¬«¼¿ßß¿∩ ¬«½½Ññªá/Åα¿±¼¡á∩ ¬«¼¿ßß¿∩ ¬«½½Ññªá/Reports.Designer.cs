﻿namespace Приёмная_комиссия_колледжа
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reports));
            this.View_ReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.BD_AbiturientDataSet = new Приёмная_комиссия_колледжа.BD_AbiturientDataSet();
            this.reportViewer = new Microsoft.Reporting.WinForms.ReportViewer();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.SpecComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.EFComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.EBComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.EDComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.ED_ExcComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.PrivComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.timerShow = new System.Windows.Forms.Timer(this.components);
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.BTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.btn_TOP = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Filter = new System.Windows.Forms.ToolStripButton();
            this.btn_Refresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.label = new System.Windows.Forms.Label();
            this.View_ReportTableAdapter = new Приёмная_комиссия_колледжа.BD_AbiturientDataSetTableAdapters.View_ReportTableAdapter();
            this.domainUpDown = new System.Windows.Forms.DomainUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.View_ReportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BD_AbiturientDataSet)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // View_ReportBindingSource
            // 
            this.View_ReportBindingSource.DataMember = "View_Report";
            this.View_ReportBindingSource.DataSource = this.BD_AbiturientDataSet;
            this.View_ReportBindingSource.Sort = "";
            // 
            // BD_AbiturientDataSet
            // 
            this.BD_AbiturientDataSet.DataSetName = "BD_AbiturientDataSet";
            this.BD_AbiturientDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer
            // 
            this.reportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.reportViewer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.reportViewer.DocumentMapWidth = 84;
            this.reportViewer.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            reportDataSource1.Name = "DataSet";
            reportDataSource1.Value = this.View_ReportBindingSource;
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer.LocalReport.ReportEmbeddedResource = "Приёмная_комиссия_колледжа.GeneralReport.rdlc";
            this.reportViewer.Location = new System.Drawing.Point(14, 74);
            this.reportViewer.Name = "reportViewer";
            this.reportViewer.ShowBackButton = false;
            this.reportViewer.ShowPrintButton = false;
            this.reportViewer.ShowRefreshButton = false;
            this.reportViewer.ShowStopButton = false;
            this.reportViewer.Size = new System.Drawing.Size(576, 313);
            this.reportViewer.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AllowItemReorder = true;
            this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip1.Enabled = false;
            this.toolStrip1.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.SpecComboBox,
            this.toolStripLabel4,
            this.EFComboBox,
            this.toolStripLabel5,
            this.EBComboBox,
            this.toolStripLabel2,
            this.EDComboBox,
            this.toolStripLabel3,
            this.ED_ExcComboBox,
            this.toolStripLabel6,
            this.PrivComboBox});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(604, 31);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel1.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(118, 28);
            this.toolStripLabel1.Text = "Специальность:";
            // 
            // SpecComboBox
            // 
            this.SpecComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SpecComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SpecComboBox.IntegralHeight = false;
            this.SpecComboBox.MaxDropDownItems = 4;
            this.SpecComboBox.Name = "SpecComboBox";
            this.SpecComboBox.Size = new System.Drawing.Size(121, 31);
            this.SpecComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel4.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(124, 28);
            this.toolStripLabel4.Text = "Форма обучения:";
            // 
            // EFComboBox
            // 
            this.EFComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EFComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EFComboBox.Items.AddRange(new object[] {
            "",
            "Дневная",
            "Заочная"});
            this.EFComboBox.Name = "EFComboBox";
            this.EFComboBox.Size = new System.Drawing.Size(121, 31);
            this.EFComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel5.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(128, 17);
            this.toolStripLabel5.Text = "Финансирование:";
            // 
            // EBComboBox
            // 
            this.EBComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EBComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EBComboBox.Items.AddRange(new object[] {
            "",
            "Бюджет",
            "Контракт"});
            this.EBComboBox.Name = "EBComboBox";
            this.EBComboBox.Size = new System.Drawing.Size(121, 27);
            this.EBComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel2.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(193, 17);
            this.toolStripLabel2.Text = "Документ об образовании:";
            // 
            // EDComboBox
            // 
            this.EDComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EDComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EDComboBox.Items.AddRange(new object[] {
            "",
            "Аттестат",
            "Диплом",
            "Свидетельство"});
            this.EDComboBox.Name = "EDComboBox";
            this.EDComboBox.Size = new System.Drawing.Size(121, 27);
            this.EDComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel3.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(97, 17);
            this.toolStripLabel3.Text = "С отличием:";
            // 
            // ED_ExcComboBox
            // 
            this.ED_ExcComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ED_ExcComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ED_ExcComboBox.Items.AddRange(new object[] {
            "",
            "Да",
            "Нет"});
            this.ED_ExcComboBox.Name = "ED_ExcComboBox";
            this.ED_ExcComboBox.Size = new System.Drawing.Size(121, 27);
            this.ED_ExcComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(127, 17);
            this.toolStripLabel6.Text = "Наличие льготы:";
            // 
            // PrivComboBox
            // 
            this.PrivComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PrivComboBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PrivComboBox.Items.AddRange(new object[] {
            "",
            "Да",
            "Нет"});
            this.PrivComboBox.Name = "PrivComboBox";
            this.PrivComboBox.Size = new System.Drawing.Size(121, 27);
            this.PrivComboBox.SelectedIndexChanged += new System.EventHandler(this.ToolStripComboBox_SelectedIndexChanged);
            // 
            // timerShow
            // 
            this.timerShow.Tick += new System.EventHandler(this.Show);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.toolStrip2.AutoSize = false;
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel7,
            this.BTextBox,
            this.btn_TOP,
            this.toolStripSeparator1,
            this.btn_Filter,
            this.btn_Refresh,
            this.toolStripSeparator2,
            this.toolStripLabel9});
            this.toolStrip2.Location = new System.Drawing.Point(0, 32);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip2.Size = new System.Drawing.Size(604, 27);
            this.toolStrip2.TabIndex = 2;
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripLabel7.Enabled = false;
            this.toolStripLabel7.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel7.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(143, 24);
            this.toolStripLabel7.Text = "Бюджетные места:";
            // 
            // BTextBox
            // 
            this.BTextBox.Enabled = false;
            this.BTextBox.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTextBox.MaxLength = 2;
            this.BTextBox.Name = "BTextBox";
            this.BTextBox.ShortcutsEnabled = false;
            this.BTextBox.Size = new System.Drawing.Size(50, 27);
            this.BTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BTextBox_KeyDown);
            this.BTextBox.TextChanged += new System.EventHandler(this.ToolStripTextBox_TextChanged);
            // 
            // btn_TOP
            // 
            this.btn_TOP.AutoSize = false;
            this.btn_TOP.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_TOP.Enabled = false;
            this.btn_TOP.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_TOP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_TOP.Image = ((System.Drawing.Image)(resources.GetObject("btn_TOP.Image")));
            this.btn_TOP.Name = "btn_TOP";
            this.btn_TOP.Size = new System.Drawing.Size(36, 24);
            this.btn_TOP.Text = "TOP";
            this.btn_TOP.Click += new System.EventHandler(this.btn_TOP_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // btn_Filter
            // 
            this.btn_Filter.AutoSize = false;
            this.btn_Filter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_Filter.Enabled = false;
            this.btn_Filter.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.Filter;
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(24, 24);
            this.btn_Filter.ToolTipText = "Фильтровать";
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.AutoSize = false;
            this.btn_Refresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_Refresh.Enabled = false;
            this.btn_Refresh.Image = global::Приёмная_комиссия_колледжа.Properties.Resources.Refresh;
            this.btn_Refresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(24, 24);
            this.btn_Refresh.Text = "toolStripButton3";
            this.btn_Refresh.ToolTipText = "Обновить данные";
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.BackColor = System.Drawing.Color.Transparent;
            this.toolStripLabel9.Font = new System.Drawing.Font("Century Schoolbook", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(69, 24);
            this.toolStripLabel9.Text = "Шаблон:";
            // 
            // label
            // 
            this.label.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label.Location = new System.Drawing.Point(-8, 30);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(620, 3);
            this.label.TabIndex = 3;
            // 
            // View_ReportTableAdapter
            // 
            this.View_ReportTableAdapter.ClearBeforeFill = true;
            // 
            // domainUpDown
            // 
            this.domainUpDown.BackColor = System.Drawing.Color.White;
            this.domainUpDown.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.domainUpDown.Items.Add("1");
            this.domainUpDown.Items.Add("2");
            this.domainUpDown.Location = new System.Drawing.Point(366, 32);
            this.domainUpDown.Name = "domainUpDown";
            this.domainUpDown.ReadOnly = true;
            this.domainUpDown.Size = new System.Drawing.Size(36, 27);
            this.domainUpDown.TabIndex = 4;
            this.domainUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.domainUpDown.Wrap = true;
            this.domainUpDown.SelectedItemChanged += new System.EventHandler(this.domainUpDown_SelectedItemChanged);
            // 
            // Reports
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(604, 402);
            this.Controls.Add(this.domainUpDown);
            this.Controls.Add(this.label);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.reportViewer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(620, 440);
            this.Name = "Reports";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отчёты";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Reports_FormClosing);
            this.Load += new System.EventHandler(this.Reports_Load);
            this.Shown += new System.EventHandler(this.Reports_Shown);
            this.Layout += new System.Windows.Forms.LayoutEventHandler(this.Reports_Layout);
            ((System.ComponentModel.ISupportInitialize)(this.View_ReportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BD_AbiturientDataSet)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripComboBox SpecComboBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox EDComboBox;
        private System.Windows.Forms.ToolStripComboBox ED_ExcComboBox;
        private System.Windows.Forms.ToolStripComboBox EFComboBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripComboBox EBComboBox;
        private System.Windows.Forms.Timer timerShow;
        private System.Windows.Forms.ToolStripComboBox PrivComboBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel6;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripTextBox BTextBox;
        private System.Windows.Forms.ToolStripButton btn_TOP;
        private System.Windows.Forms.ToolStripButton btn_Filter;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.ToolStripButton btn_Refresh;
        private System.Windows.Forms.BindingSource View_ReportBindingSource;
        private BD_AbiturientDataSet BD_AbiturientDataSet;
        private BD_AbiturientDataSetTableAdapters.View_ReportTableAdapter View_ReportTableAdapter;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel9;
        private System.Windows.Forms.DomainUpDown domainUpDown;
    }
}