﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Data.SqlClient;

namespace Приёмная_комиссия_колледжа
{
    public partial class Reports : Form
    {
        private Main_menu F0;                                   //Переменная класса для взаимодействия с родительской формой
        private ArrayList filteringFields = new ArrayList();    //Список для хранения условий и работы с фильтром
        private string filter;                                  //Переменная для хранения комбинированного условия фильтра
        private bool var = false;                               //Переменная наличия файла специальностей и специальности ЗЧС в перечне этого файла

        //**************************
        // Обработчики инициализации
        //**************************
        public Reports()
        {
            InitializeComponent();
        }

        public Reports(Main_menu F)
        {
            try
            {
                InitializeComponent();
                //Избавляемся от встроенного контекстного меню
                domainUpDown.ContextMenuStrip = new ContextMenuStrip();
                F0 = F;
            }
            catch (IOException e)
            {
                MessageBox.Show("Нарушена целостность данного ПО! Обратитесь в техподдержку или переустановите данное ПО.\n" + e.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        //******************************
        // Блок предварительной загрузки
        //******************************
        private void Reports_Load(object sender, EventArgs e)
        {
            try
            {
                if (SpecComboBox.Items.Count == 0)
                {
                    //Проверяем существование файла
                    if (File.Exists(Application.StartupPath + @"\Specialties.dat"))
                    {
                        //Очищаем списoк от старых данных
                        SpecComboBox.Items.Clear();
                        //Загружаем новые данные
                        SpecComboBox.Items.AddRange(File.ReadAllLines(Application.StartupPath + @"\Specialties.dat"));
                        var = true;
                    }
                }
                this.View_ReportTableAdapter.FillDataTable(this.BD_AbiturientDataSet.View_Report);
            }
            catch (SqlException)
            {
                MessageBox.Show("Процедура загрузки данных не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.View_ReportTableAdapter.Dispose(); GC.SuppressFinalize(View_ReportTableAdapter); }
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Reports_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //***************************
        // Обработчик проверки списка
        //***************************
        private void Reports_Shown(object sender, EventArgs e)
        {
            if (!var)
            {
                domainUpDown.Enabled = false;
                MessageBox.Show("Вы пока что не можете работать с отчётами, так как у Вас ещё не создан файл с перечнем специальностей.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                for (int i = 0; i < SpecComboBox.Items.Count; i++)
                    if (SpecComboBox.Items[i].ToString() == "ЗЧС")
                        var = true;
                    else
                        var = false;
            }
        }

        //*******************
        // Обработчик таймера
        //*******************
        private void Show(object sender, EventArgs e)
        {
            this.Show();
            if (!F0.chb_Main_menu.Checked)
            {
                this.Opacity += 0.15;
                if (this.Opacity == 1)
                {
                    timerShow.Stop();
                    timerShow.Dispose();
                }
            }
            else
            {
                this.Opacity = 1.0;
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        //**************************
        // Блоки обработчиков кнопок
        //**************************
        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            SpecComboBox.Text = String.Empty;
            EFComboBox.Text = String.Empty;
            EBComboBox.Text = String.Empty;
            EDComboBox.Text = String.Empty;
            ED_ExcComboBox.Text = String.Empty;
            PrivComboBox.Text = String.Empty;
            BTextBox.Text = String.Empty;
            this.View_ReportBindingSource.RemoveFilter();
            try
            {
                this.View_ReportTableAdapter.FillDataTable(this.BD_AbiturientDataSet.View_Report);
                this.reportViewer.RefreshReport();
            }
            catch (SqlException)
            {
                MessageBox.Show("Процедура обновления данных не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.View_ReportTableAdapter.Dispose(); GC.SuppressFinalize(View_ReportTableAdapter); }
        }

        private void btn_TOP_Click(object sender, EventArgs e)
        {
            try
            {
                this.View_ReportTableAdapter.TOP(this.BD_AbiturientDataSet.View_Report, Convert.ToInt16(BTextBox.Text), SpecComboBox.Text, EFComboBox.Text, EBComboBox.Text, EDComboBox.Text, PrivComboBox.Text);
                this.reportViewer.RefreshReport();
            }
            catch (SqlException)
            {
                MessageBox.Show("Процедура отбора данных не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.View_ReportTableAdapter.Dispose(); GC.SuppressFinalize(View_ReportTableAdapter); }
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            //Очищаем фильтр
            View_ReportBindingSource.RemoveFilter(); filter = "";
            //Очищаем список условий
            filteringFields.Clear();
            //Записываем условия для фильтра
            if (!String.IsNullOrEmpty(SpecComboBox.Text))
                filteringFields.Add("Ab_Spec1 LIKE '" + SpecComboBox.Text + "'");
            if (!String.IsNullOrEmpty(EFComboBox.Text))
                filteringFields.Add("Ab_EF LIKE '" + EFComboBox.Text + "'");
            if (!String.IsNullOrEmpty(EBComboBox.Text))
                filteringFields.Add("Ab_EB LIKE '" + EBComboBox.Text + "'");
            if (!String.IsNullOrEmpty(EDComboBox.Text))
                filteringFields.Add("Ab_EDK LIKE '" + EDComboBox.Text + "'");
            if (!String.IsNullOrEmpty(ED_ExcComboBox.Text))
                filteringFields.Add("Ab_ED_Exc LIKE '" + ED_ExcComboBox.Text + "'");
            if (!String.IsNullOrEmpty(PrivComboBox.Text))
            {
                if (PrivComboBox.Text == "Нет")
                    filteringFields.Add("Ab_Priv LIKE '" + PrivComboBox.Text + "'");
                else
                    filteringFields.Add("Ab_Priv NOT LIKE 'Нет'");
            }
            //Создаём комбинированный фильтр
            if (filteringFields.Count == 1)
                filter = filteringFields[0].ToString();
            else if (filteringFields.Count > 1)
            {
                for (int i = 0; i < filteringFields.Count - 1; i++)
                    filter += filteringFields[i].ToString() + " AND ";
                //Дописываем последний элемент списка без "AND"
                filter += filteringFields[filteringFields.Count - 1].ToString();
            }
            else
            {
                MessageBox.Show("Для фильтрации данных необходимо указать хотя бы один критерий.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            this.View_ReportBindingSource.Filter = filter;  //Применяем фильтр
            reportViewer.RefreshReport();
        }

        //*********************************************
        // Блоки обработчиков, контролирующие изменения
        //*********************************************
        private void ToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((!String.IsNullOrEmpty(SpecComboBox.Text)) && (!String.IsNullOrEmpty(EFComboBox.Text)) && (!String.IsNullOrEmpty(EBComboBox.Text)) && (!String.IsNullOrEmpty(EDComboBox.Text)) && (String.IsNullOrEmpty(ED_ExcComboBox.Text)) && (!String.IsNullOrEmpty(PrivComboBox.Text)))
            {
                toolStripLabel7.Enabled = true;
                BTextBox.Enabled = true;
            }
            else
            {
                toolStripLabel7.Enabled = false;
                BTextBox.Enabled = false;
            }
        }

        private void ToolStripTextBox_TextChanged(object sender, EventArgs e)
        {
            if ((String.IsNullOrEmpty(BTextBox.Text)) || (BTextBox.Text[0] == '0'))
                btn_TOP.Enabled = false;
            else
                btn_TOP.Enabled = true;
        }

        private void domainUpDown_SelectedItemChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(domainUpDown.Text))
            {
                btn_Refresh.Enabled = true;
                if (domainUpDown.Text == "1")
                {
                    if (File.Exists(Application.StartupPath + @"\Reports\GeneralReport.rdlc"))
                    {
                        this.reportViewer.LocalReport.ReportPath = Application.StartupPath + @"\Reports\GeneralReport.rdlc";
                        this.reportViewer.RefreshReport();
                        if (!toolStrip1.Enabled)
                            toolStrip1.Enabled = true;
                        SpecComboBox.Text = "";
                        SpecComboBox.Enabled = true;
                        EBComboBox.Enabled = true;
                        ED_ExcComboBox.Enabled = true;
                        PrivComboBox.Enabled = true;
                        btn_Filter.Enabled = true;
                    }
                    else
                        MessageBox.Show("Шаблон отчёта не найден. Возможно, он был удалён, перемещён или переименован.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if ((var) && (File.Exists(Application.StartupPath + @"\Reports\ExamReport.rdlc")))
                    {
                        this.reportViewer.LocalReport.ReportPath = Application.StartupPath + @"\Reports\ExamReport.rdlc";
                        this.reportViewer.RefreshReport();
                        SpecComboBox.Text = "ЗЧС";
                        SpecComboBox.Enabled = false;
                        EBComboBox.Enabled = false;
                        ED_ExcComboBox.Enabled = false;
                        PrivComboBox.Enabled = false;
                        btn_Filter.Enabled = true;
                    }
                    else if (!var)
                    {
                        MessageBox.Show("Вы не можете использовать шаблон отчёта № 2, так как в списке специальностей отсутствует специальность \"ЗЧС\".", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        domainUpDown.Text = "1";
                    }
                    else
                        MessageBox.Show("Шаблон отчёта не найден. Возможно, он был удалён, перемещён или переименован.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //**************************
        // Обработчик нажатия клавиш
        //**************************
        private void BTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            //Подавляем передачу сигнала нажатой клавишы
            e.SuppressKeyPress = true;
            //Разрешаем обработку циферного блока клавиш Numpad
            if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
                e.SuppressKeyPress = false;
            //Разрешаем обработку цифер, если клавиша Shift не нажата
            if (e.Shift != true)
            {
                if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
                    e.SuppressKeyPress = false;
            }
            //Разрешаем обработку клавиш Delete, Backspace, Home, End и перемещение стрелок вправо, влево
            if ((e.KeyCode == Keys.Delete) || (e.KeyCode == Keys.Back) || (e.KeyCode == Keys.Right) || (e.KeyCode == Keys.Left) || (e.KeyCode == Keys.Home) || (e.KeyCode == Keys.End))
                e.SuppressKeyPress = false;
        }

        //*******************************
        // Обработчик закрытия этой формы
        //*******************************
        private void Reports_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
        }
    }
}