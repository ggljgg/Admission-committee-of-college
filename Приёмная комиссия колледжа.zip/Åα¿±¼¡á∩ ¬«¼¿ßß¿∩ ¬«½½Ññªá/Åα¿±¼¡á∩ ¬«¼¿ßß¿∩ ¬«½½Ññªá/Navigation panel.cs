﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Search;
using System.Data.SqlClient;
using System.IO;

namespace Приёмная_комиссия_колледжа
{
    public partial class Navigation_panel : Form
    {
        private Registration_form F2;           //Переменная класса для взаимодействия с дочерней формой
        public Main_menu F0;                    //Переменная класса для взаимодействия с родительской формой
        private bool status_fl;                 //Переменная нажатой кнопки (Добавить/Изментиь)
        private bool logic = false;             //Переменная для одноразового использвания свойств объектов
        private byte time;                      //Переменная-счётчик для отключения анимации загрузки данных
        public DataGridView dg { get { return this.dataGridView; } }
        public Boolean st_fl { get { return this.status_fl; } }

        //**************************
        // Обработчики инициализации
        //**************************
        public Navigation_panel()
        {
            InitializeComponent();
        }

        public Navigation_panel(Main_menu F)
        {
            try
            {
                InitializeComponent();
                F0 = F;
            }
            catch (IOException e)
            {
                MessageBox.Show("Нарушена целостность данного ПО! Обратитесь в техподдержку или переустановите данное ПО.\n" + e.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Navigation_panel_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //*****************************************
        // Блоки обработчиков кнопок редактирования 
        //*****************************************
        private void btn_Add_Click(object sender, EventArgs e)
        {
            this.Load_Reg(false);
        }

        private void btn_Change_Click(object sender, EventArgs e)
        {
            this.Change();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            this.Delete();
        }

        //************************************************************
        // Обработчики навигационных кнопок и их активации/деактивации
        //************************************************************
        private void btn_First_Click(object sender, EventArgs e)
        {
            this.viewBindingSource.MoveFirst();
        }

        private void btn_Previous_Click(object sender, EventArgs e)
        {
            this.viewBindingSource.MovePrevious();
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            viewBindingSource.MoveNext();
        }

        private void btn_Last_Click(object sender, EventArgs e)
        {
            viewBindingSource.MoveLast();
        }

        private void dataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //Настраиваем активацию навигационных кнопок
            if (viewBindingSource.Count <= 1)
            {
                this.Navigation_En_F(); //Деактивируем все кнопки навигации
            }
            //Находимся в начале
            else if (viewBindingSource.Position == viewBindingSource.Count - viewBindingSource.Count)
            {
                this.Navigation_First();
            }
            //Находимся в конце
            else if (viewBindingSource.Position == viewBindingSource.Count - 1)
            {
                this.Navigation_Last();
            }
            else
            {
                btn_First.Enabled = true;
                btn_Previous.Enabled = true;
                btn_Next.Enabled = true;
                btn_Last.Enabled = true;
            }
        }

        //**********************************
        // Блоки обработчиков боковой панели
        //**********************************
        private void btn_Sidebar_Click(object sender, EventArgs e)
        {
            //Настраиваем видимость боковой панели и смещение таблицы с данными
            if (this.splitContainer2.Panel1Collapsed == false)
            {
                btn_Sidebar.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);
                this.splitContainer2.Panel1Collapsed = true;
                this.dataGridView.Left = this.dataGridView.Left - 100;
            }
            else
            {
                btn_Sidebar.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);
                this.splitContainer2.Panel1Collapsed = false;
                this.dataGridView.Left = this.dataGridView.Left + 100;
            }
        }

        private void btn_Connection_Click(object sender, EventArgs e)
        {
            if (logic) dataGridView.Hide();
            //Отображаем анимацию загрузки
            time = 0;
            pictureBox.Show();
            splitContainer1.Cursor = Cursors.WaitCursor;
            //Деактивируем элементы
            if (btn_Add.Enabled)
            {
                this.Navigation_En_F();
                btn_Add.Enabled = false;
                btn_Sidebar.Enabled = false;
                this.El_en_false();
            }
            btn_Connection.Enabled = false;
            timerConnect.Start();
        }

        private void chb_Clear_CheckedChanged(object sender, EventArgs e)
        {   //Активируем/деактивируем кнопку очистки БД
            btn_ClearDB.Enabled = chb_Clear.Checked;
        }

        private void btn_ClearDB_Click(object sender, EventArgs e)
        {
            if (viewBindingSource.Count != 0)
            {//необходимо будет немного изменить проверку на пустоту БД, когда будет реализована клиент-серверная архитектура
                try
                {
                    DialogResult r = MessageBox.Show("Внимание! Будет произведена полная очистка базы данных. Вы подтверждаете данную операцию?", "Очистка базы данных", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (r == DialogResult.Yes)
                    {
                        this.viewTableAdapter.ClearDB();
                        this.Update_info();
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Процедура очистки не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server. Также это сообщение могло возникнуть в том случае, если у Вас нет разрешения \"Полный доступ\" для папки с приложением.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch(Exception err)
                {
                    MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }
            }
            else
                MessageBox.Show("База данных уже пуста!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            //Если поля для поиска активны
            if ((sb_Code.SearchEnabled) || (sb_LFP.SearchEnabled))
            {   //Настраиваем поиск в зависимости от активных полей
                if ((sb_LFP.SearchEnabled) && (sb_Code.SearchEnabled))
                {   //Проверка на пустоту (пробел тоже считается пустотой)
                    if (((!String.IsNullOrWhiteSpace(sb_LFP.SearchValue)) && (!String.IsNullOrWhiteSpace(sb_Code.SearchValue))))
                    {
                        if (rb_Filter1.Checked)
                            viewBindingSource.Filter = "LFP LIKE '" + sb_LFP.SearchValue + "%' OR Pers_ID LIKE '" + sb_Code.SearchValue + "%'";
                        else if (rb_Filter2.Checked)
                            viewBindingSource.Filter = "LFP LIKE '%" + sb_LFP.SearchValue + "%' OR Pers_ID LIKE '%" + sb_Code.SearchValue + "%'";
                    }
                    else
                        MessageBox.Show("Поля для поиска должны быть заполнены!", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (sb_LFP.SearchEnabled)
                {   //Проверка на пустоту
                    if (!String.IsNullOrWhiteSpace(sb_LFP.SearchValue))
                    {
                        if (rb_Filter1.Checked)
                            viewBindingSource.Filter = "LFP LIKE '" + sb_LFP.SearchValue + "%'";
                        else if (rb_Filter2.Checked)
                            viewBindingSource.Filter = "LFP LIKE '%" + sb_LFP.SearchValue + "%'";
                    }
                    else
                        MessageBox.Show("Поле \"Поиск по ФИО\" должно быть заполнено!", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {   //Проверка на пустоту
                    if (!String.IsNullOrWhiteSpace(sb_Code.SearchValue))
                    {
                        if (rb_Filter1.Checked)
                            viewBindingSource.Filter = "Pers_ID LIKE '" + sb_Code.SearchValue + "%'";
                        else if (rb_Filter2.Checked)
                            viewBindingSource.Filter = "Pers_ID LIKE '%" + sb_Code.SearchValue + "%'";
                    }
                    else
                        MessageBox.Show("Поле \"Поиск по коду\" должно быть заполнено!", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
                MessageBox.Show("Для того, чтобы начать поиск активируйте хотя бы одно из поисковых полей и введите в него текст.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            sb_LFP.SearchEnabled = false;
            sb_Code.SearchEnabled = false;
            viewBindingSource.RemoveFilter();
        }

        //***************************************
        // Обработчики альтернативного управления
        //***************************************
        private void dataGridView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //Если есть данные
            if ((viewBindingSource.Count != 0) && (e.Button == MouseButtons.Left))
                this.Change();
        }

        private void Navigation_panel_KeyDown(object sender, KeyEventArgs e)
        {
            //Если перед этим нажали кнопку "Обновить данные"
            if ((e.KeyCode == Keys.Insert) && (btn_Add.Enabled == true))
                this.Load_Reg(false);
            if (viewBindingSource.Count > 1)
            {
                if ((!sb_LFP.Focused) && (!sb_Code.Focused) && (e.KeyCode == Keys.Home))
                    this.viewBindingSource.MoveFirst();
                else if (e.KeyCode == Keys.PageUp)
                    this.viewBindingSource.MovePrevious();
                else if (e.KeyCode == Keys.PageDown)
                    this.viewBindingSource.MoveNext();
                else if ((!sb_LFP.Focused) && (!sb_Code.Focused) && (e.KeyCode == Keys.End))
                    this.viewBindingSource.MoveLast();
            }
            if ((!sb_LFP.Focused) && (!sb_Code.Focused) && (e.KeyCode == Keys.Delete) && (viewBindingSource.Count > 0))
                this.Delete();
        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            //Отключаем внедрённую обработку клавиш Up и Down    
            e.Handled = true;
        }

        //****************************
        // Блоки обработчиков таймеров
        //****************************
        private void Show(object sender, EventArgs e)
        {
            this.Enabled = true;
            this.Show();
            if (!F0.chb_Main_menu.Checked)
            {
                this.Opacity += 0.15;
                if (this.Opacity == 1)
                {
                    timerShow.Stop();
                    timerShow.Dispose();
                }
            }
            else
            {
                this.Opacity = 1.0;
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        private void Hide(object sender, EventArgs e)
        {
            this.Enabled = false;
            if (!F0.chb_Main_menu.Checked)
            {
                this.Opacity -= 0.15;
                if (this.Opacity == 0.7)
                {
                    timerHide.Stop();
                    timerHide.Dispose();

                }
            }
            else
            {
                timerHide.Stop();
                timerHide.Dispose();
            }
        }

        private void Connect(object sender, EventArgs e)
        {
            if (time != 10)
                time += 1;
            else
            {
                timerConnect.Stop();
                timerConnect.Dispose();
                try
                {
                    //Загружаем данные
                    this.viewTableAdapter.FillDataTable(this.bD_AbiturientDataSet.View);
                    btn_Sidebar.Enabled = true;
                    btn_Add.Enabled = true;
                    //Если данные есть
                    if (viewBindingSource.Count != 0)
                    {
                        this.LoadCounters();
                        this.El_en_true();
                    }
                    pictureBox.Hide();
                    dataGridView.Show();
                    splitContainer1.Cursor = Cursors.Default;
                    btn_Connection.Enabled = true;
                    logic = true;
                }
                catch (SqlException)
                {
                    MessageBox.Show("Процедура загрузки данных не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }
            }
        }

        //***************************************
        // Обработчик закрытия Анкеты абитуриента
        //***************************************
        private void F2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (F2.DialogResult == DialogResult.OK) //|| (F2.Update_err == true)) расскоментировать после реализации клиент-серверной архитектуры
                this.Update_info();
            this.Activate();
            timerShow.Start();
        }

        //*******************************
        // Обработчик закрытия этой формы
        //*******************************
        private void Navigation_panel_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
        }

        //***************************************
        // Блоки обработчиков, оптимизирующих код
        //***************************************
        private void Load_Reg(bool value)
        {
            timerHide.Start();
            status_fl = value;
            if ((F2 == null) || (F2.IsDisposed))
                F2 = new Registration_form();
            F2.FormClosing += new FormClosingEventHandler(F2_FormClosing);
            F2.Show(F2.F1 = this);
        }

        private void Change()
        {
            /*try   //расскоментировать после реализации клиент-серверной архитектуры
            {
                if (Convert.ToUInt16(viewTableAdapter.Exists(Convert.ToString(dataGridView[1, dataGridView.CurrentRow.Index].Value))) != 0)*/
            this.Load_Reg(true);
            /*else
            {
                MessageBox.Show("Данные с кодом \"" + dataGridView[1, dataGridView.CurrentRow.Index].Value + "\" не обнаружены в базе данных. Возможно, они были изменены или удалены другим пользователем.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Update_info();
            }
        }
        finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }*/
        }

        private void Delete()
        {
            try
            {
                DialogResult r = MessageBox.Show("Вы действительно хотите удалить выбранные данные?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (r == DialogResult.Yes)
                {
                    //if (Convert.ToUInt16(viewTableAdapter.Exists(Convert.ToString(dataGridView[1, dataGridView.CurrentRow.Index].Value))) != 0)
                    //{
                    this.viewTableAdapter.DeleteData(Convert.ToString(dataGridView[1, dataGridView.CurrentRow.Index].Value));
                    this.Update_info();
                    if (viewBindingSource.Count == 0)
                        chb_Clear.Enabled = false;
                    //}
                    /*else  //расскоментировать после реализации клиент-серверной архитектуры
                    {
                        MessageBox.Show("Данные с кодом \"" + dataGridView[1, dataGridView.CurrentRow.Index].Value + "\" не обнаружены в базе данных. Возможно, они были изменены или удалены другим пользователем.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Update_info();
                    }*/
                }
            }
            catch (SqlException) { MessageBox.Show("Процедура удаления не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server. Также это сообщение могло возникнуть в том случае, если у Вас нет разрешения \"Полный доступ\" для папки с приложением.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }
        }

        private void LoadCounters()
        {
            try
            {
                //Обновляем счётчики
                this.lbGeneralCount.Text = Convert.ToString(viewTableAdapter.GeneralCount());
                this.lbDF.Text = Convert.ToString(viewTableAdapter.DCount());
                this.lbEF.Text = Convert.ToString(viewTableAdapter.ECount());
                this.lbBudgetCount.Text = Convert.ToString(viewTableAdapter.BudgetCount());
                this.lbContractCount.Text = Convert.ToString(viewTableAdapter.ContractCount());
            }
            catch (SqlException)
            {
                MessageBox.Show("Процедура обновления счётчиков не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }
        }

        private void Update_info()
        {
            try
            {
                this.LoadCounters();
                //Запоминаем позицию
                int pos = this.viewBindingSource.Position;
                //Обновляем таблицу с данными
                this.viewTableAdapter.FillDataTable(this.bD_AbiturientDataSet.View);
                //Задаём позицию
                this.viewBindingSource.Position = pos;
                if (viewBindingSource.Count == 0)
                    this.El_en_false();
                if ((F2 != null) && (F2.DialogResult == System.Windows.Forms.DialogResult.OK) && (btn_Change.Enabled == false))
                    this.El_en_true();
            }
            catch (SqlException)
            {
                MessageBox.Show("Процедура обновления данных не была выполнена из-за нестабильного соединения с базой данных или из-за отсутствия на данном устройстве РСУБД MS SQL Server.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Возникла непредвиденная ошибка. Приложение будет закрыто. Обратитесь за помощью к разработчику данного ПО, подробно описав Ваши действия. Информация о необработанном исключении:\n" + err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally { this.viewTableAdapter.Dispose(); GC.SuppressFinalize(viewTableAdapter); }
        }

        private void Navigation_First()
        {
            btn_First.Enabled = false;
            btn_Previous.Enabled = false;
            btn_Next.Enabled = true;
            btn_Last.Enabled = true;
        }

        private void Navigation_Last()
        {
            btn_First.Enabled = true;
            btn_Previous.Enabled = true;
            btn_Next.Enabled = false;
            btn_Last.Enabled = false;
        }

        private void Navigation_En_F()
        {
            btn_First.Enabled = false;
            btn_Previous.Enabled = false;
            btn_Next.Enabled = false;
            btn_Last.Enabled = false;
        }

        private void El_en_true()
        {
            btn_Change.Enabled = true;
            btn_Delete.Enabled = true;
            grbSearch.Enabled = true;   //Активируем панель поиска
            chb_Clear.Enabled = true;
        }

        private void El_en_false()
        {
            btn_Change.Enabled = false;
            btn_Delete.Enabled = false;
            grbSearch.Enabled = false;
            chb_Clear.Enabled = false;
        }
    }
}