﻿/*
 * Admission committee of college.
 * This software is designed to process the data of enrollees the college.
 * Copyright (C) 2017 Sagaydak Danil
 * E-mail: luidjy75@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;

namespace Приёмная_комиссия_колледжа
{
    public partial class Main_menu : Form
    {
        private Navigation_panel reg;        //Переменная класса для взаимодействия с дочерней формой
        public Reports rp;                  //Переменная класса для взаимодействия с дочерней формой
        private About ab;                    //Переменная класса для взаимодействия с дочерней формой
        object Sender;                       //Переменная для идентификации кнопки, текст которой нужно анимировать
        public CheckBox chb_Main_menu { get { return this.chb_Anim; } }

        //*************************
        // Обработчик инициализации
        //*************************
        public Main_menu()
        {
            InitializeComponent();
        }

        //************************************
        // Блок предварительной загрузки формы
        //************************************
        private void Main_menu_Load(object sender, EventArgs e)
        {
            this.WindowState = Properties.Settings.Default.Form_State;
            chb_Anim.Checked = Properties.Settings.Default.chb_Anim;
        }

        //*************************************
        // Обработчик рисования овальных кнопок
        //*************************************
        private void btns_Paint(object sender, PaintEventArgs e)
        {
            //Создадим новый прямоугольник с размерами кнопки
            Rectangle smallRectangle = (sender as Button).ClientRectangle;
            //Уменьшаем размеры прямоугольника
            smallRectangle.Inflate(-3, -3);
            //Создадём эллипс, используя полученные размеры
            GraphicsPath gp = new GraphicsPath();
            gp.AddEllipse(smallRectangle);
            (sender as Button).Region = new Region(gp);
            //Рисуем окантовоку для круглой кнопки
            Graphics g = CreateGraphics();
            g.DrawEllipse(new Pen(Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(154)))), ((int)(((byte)(154))))), 1F), (sender as Button).Left + 3, (sender as Button).Top + 3, (sender as Button).Width - 6, (sender as Button).Height - 6);
            //Освобождаем ресурсы
            g.Dispose();
        }

        //***************************
        // Обработчик появления формы
        //***************************
        private void Main_menu_Layout(object sender, LayoutEventArgs e)
        {
            timerShow.Start();
        }

        //**************************
        // Блоки обработчиков кнопок
        //**************************
        private void btn_Reg_Click(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Регистрация ");
            this.El_en_false(sender);
            this.Reg_Open();
        }

        private void btn_Rp_Click(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Отчёты ");
            if (Application.OpenForms["List_editor"] == null)
            {
                this.El_en_false(sender);
                this.Rp_Open();
            }
            else
                MessageBox.Show("Окно \"Отчёты\" не может быть открыто пока открыто окно \"Редактор списка\".", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_Help_Click(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Справка ");
            this.El_en_false(sender);
            this.Close();
            Help.ShowHelp(this, "Help.chm");
        }

        private void btn_About_Click(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " О программе ");
            this.El_en_false(sender);
            this.TopMost = false;
            ab = new About(this);
            ab.FormClosing += new FormClosingEventHandler(ab_FormClosing);
            ab.ShowDialog();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Выход ");
            this.El_en_false(sender);
            timerClose.Start();
        }

        //**********************************************
        // Блоки обработчиков значка и контекстного меню
        //**********************************************
        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if ((!this.Visible) && (e.Button == MouseButtons.Left) && (Application.OpenForms["About"] == null))
            {
                this.El_en_true();
                timerShow.Start();
            }
            else if (Application.OpenForms["About"] != null)
                ab.Activate();
        }

        private void показатьМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((!this.Visible) && (Application.OpenForms["About"] == null))
            {
                this.El_en_true();
                timerShow.Start();
            }
            else
                ab.Activate();
        }

        private void регистрацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["About"] == null)
                this.Reg_Open();
            else
                ab.Activate();
        }

        private void отчётыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["List_editor"] != null)
                MessageBox.Show("Окно \"Отчёты\" не может быть открыто пока открыто окно \"Редактор списка\".", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else if ((Application.OpenForms["About"] == null) && (Application.OpenForms["List editor"] == null))
                this.Rp_Open();
            else if (Application.OpenForms["About"] != null)
                ab.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (Visible)
                    timerClose.Start();
                else
                {
                    this.notifyIcon.Dispose();
                    Application.Exit();
                }
            }
            catch (InvalidOperationException) { Application.Exit(); }
        }

        //*********************************************************
        // Блоки обработчиков активации/деактивации анимации текста
        //*********************************************************
        private void btn_Reg_MouseHover(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                timerText.Start();
                this.Sender = sender;
            }
        }

        private void btn_Reg_MouseLeave(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Регистрация ");
        }

        private void btn_Rp_MouseHover(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                timerText.Start();
                this.Sender = sender;
            }
        }

        private void btn_Rp_MouseLeave(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Отчёты ");
        }

        private void btn_Help_MouseHover(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                timerText.Start();
                this.Sender = sender;
            }
        }

        private void btn_Help_MouseLeave(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Справка ");
        }

        private void btn_About_MouseHover(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                timerText.Start();
                this.Sender = sender;
            }
        }

        private void btn_About_MouseLeave(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " О программе ");
        }

        private void btn_Exit_MouseHover(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                timerText.Start();
                this.Sender = sender;
            }
        }

        private void btn_Exit_MouseLeave(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
                this.TextStop(sender, " Выход ");
        }

        //****************************
        // Блоки обработчиков таймеров
        //****************************
        private void Close(object sender, EventArgs e)
        {
            try
            {
                if (!chb_Anim.Checked)
                {
                    this.Opacity -= 0.15;
                    if (this.Opacity == 0)
                    {
                        timerClose.Stop();
                        timerClose.Dispose();
                        this.notifyIcon.Dispose();
                        Application.Exit();
                    }
                }
                else
                {
                    timerClose.Stop();
                    timerClose.Dispose();
                    this.notifyIcon.Dispose();
                    Application.Exit();
                }
            }
            catch (InvalidOperationException) { Application.Exit(); }
        }

        private void Hide(object sender, EventArgs e)
        {
            if (!chb_Anim.Checked)
            {
                this.Opacity -= 0.15;
                if (this.Opacity <= 0.1)
                {
                    timerHide.Stop();
                    timerHide.Dispose();
                    this.Hide();
                }
            }
            else
            {
                this.Hide();
                timerHide.Stop();
                timerHide.Dispose();
            }
        }

        private void Show(object sender, EventArgs e)
        {
            this.Show();
            if (!chb_Anim.Checked)
            {
                this.Opacity += 0.15;
                if (this.Opacity == 1)
                {
                    timerShow.Stop();
                    timerShow.Dispose();
                }
            }
            else
            {
                this.Opacity = 1.0;
                timerShow.Stop();
                timerShow.Dispose();
            }
        }

        private void timerText_Tick(object sender, EventArgs e)
        {
            this.AnimateText(Sender, (Sender as Button).Text);
        }

        //****************************
        // Блоки обработчиков закрытия
        //****************************
        private void reg_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((!this.Visible) && (Program.GetVisibleForms().Count == 0))
            {
                this.El_en_true();
                timerShow.Start();
            }
        }

        private void rp_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((!this.Visible) && (Program.GetVisibleForms().Count == 0))
            {
                this.El_en_true();
                timerShow.Start();
            }
        }

        private void ab_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.El_en_true();
            this.TopMost = true;
        }

        private void Main_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                timerHide.Start();
                notifyIcon.ShowBalloonTip(5);
            }
            else if (e.CloseReason == CloseReason.ApplicationExitCall)
            {
                Properties.Settings.Default.chb_Anim = chb_Anim.Checked;
                Properties.Settings.Default.Save();
            }
        }

        //***************************************
        // Блоки обработчиков, оптимизирующих код
        //***************************************
        private void Reg_Open()
        {
            timerHide.Start();
            if ((reg == null) || (reg.IsDisposed))
            {
                reg = new Navigation_panel(this);
                reg.FormClosing += new FormClosingEventHandler(reg_FormClosing);
                reg.Show();
            }
            else
            {
                if (reg.WindowState == FormWindowState.Minimized)
                    reg.WindowState = FormWindowState.Normal;
                if (!reg.Visible)
                {
                    reg.Show();
                }
                reg.Activate();
            }
        }

        private void Rp_Open()
        {
            timerHide.Start();
            if ((rp == null) || (rp.IsDisposed))
            {
                rp = new Reports(this);
                rp.FormClosing += new FormClosingEventHandler(rp_FormClosing);
                rp.Show();
            }
            else
            {
                if (rp.WindowState == FormWindowState.Minimized)
                    rp.WindowState = FormWindowState.Normal;
                if (!rp.Visible)
                {
                    rp.Show();
                }
                rp.Activate();
            }
        }

        private void AnimateText(object sender, string text)
        {
            text = (sender as Button).Text.Substring(1, ((sender as Button).Text.Length - 1)) + (sender as Button).Text.Substring(0, 1);
            (sender as Button).Text = text;
        }

        private void TextStop(object sender, string text)
        {
            timerText.Stop();
            timerText.Dispose();
            this.Sender = null;
            (sender as Button).Text = text;
        }

        private void El_en_false(object sender)
        {
            if ((sender as Button).Name.Contains("Reg"))
            {
                btn_Rp.Enabled = false;
                btn_Help.Enabled = false;
                btn_About.Enabled = false;
                btn_Exit.Enabled = false;
            }
            else if ((sender as Button).Name.Contains("Rp"))
            {
                btn_Reg.Enabled = false;
                btn_Help.Enabled = false;
                btn_About.Enabled = false;
                btn_Exit.Enabled = false;
            }
            else if ((sender as Button).Name.Contains("Help"))
            {
                btn_Reg.Enabled = false;
                btn_Rp.Enabled = false;
                btn_About.Enabled = false;
                btn_Exit.Enabled = false;
            }
            else if ((sender as Button).Name.Contains("About"))
            {
                btn_Reg.Enabled = false;
                btn_Rp.Enabled = false;
                btn_Help.Enabled = false;
                btn_Exit.Enabled = false;
            }
            else
            {
                btn_Reg.Enabled = false;
                btn_Rp.Enabled = false;
                btn_Help.Enabled = false;
                btn_About.Enabled = false;
            }
        }

        private void El_en_true()
        {
            btn_Reg.Enabled = true;
            btn_Rp.Enabled = true;
            btn_Help.Enabled = true;
            btn_About.Enabled = true;
            btn_Exit.Enabled = true;
        }
    }
}